/* Import > ... */
#include <csignal>  // --> std::signal(…)
#include <cstddef>  // --> std::size_t
#include <cstdio>   // --> std::fclose(…), std::fgetc(…), std::fopen(…), std::fprintf(…), std::fputc(…), std::fputs(…), std::setbuf(…)
#include <cstdlib>  // --> std::calloc(…), std::free(…)
#include <ctime>    // --> std::time(…), std::time_t
#include <new>      // --> std::launder(…), new (…) T{…}
#include <stdint.h> // --> uint_least32_t

#if defined(__APPLE__) || defined(__gnu_linux__) || defined(linux) || defined(__linux) || defined(__linux__) || defined(__MACH__) || defined(__unix) || defined(__unix__)
# include <conio.h>
#elif defined(__NT__) || defined(__TOS_WIN__) || defined(_WIN16) || defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(_WIN32_WCE) || defined(_WIN64) || defined(__WINDOWS__)
# ifndef _WIN32_WINNT
#   define _WIN32_WINNT 0x0500
# endif
# include <windows.h>
#endif

/* Definition > Title */
#define TITLE "Snake"

/* Namespace > Game */
namespace Game {
  class Fruit;
  class Object;
  class Snake;
  class Wall;
  typedef char const (Asset)[8]; // ->> Bounds should not necessary, but multi-dimensional arrays disagree
  typedef unsigned DrawInformation;
  typedef char     Pixel;

  void draw (void (*)(Pixel[], Pixel, Game::DrawInformation));
  void input(char const);
  void put  (Pixel[], Pixel const, Game::DrawInformation const);
  void quit ();
  void quit (int const);
  std::size_t         maximum (std::size_t const, std::size_t const);
  std::size_t         randint (std::size_t const);
  std::size_t const (&randseed(std::size_t const = 0u))[4];
  template <typename type> inline type* launder(type* const);

  // ...
  namespace Assets {
    inline void draw(void (*)(Pixel[], Pixel, Game::DrawInformation), Asset, std::size_t const, std::size_t const, std::size_t const, std::size_t, Game::DrawInformation const = static_cast<Game::DrawInformation>(0x0u));
    inline std::size_t getHeight(Asset);
    inline std::size_t getWidth (Asset);
  }
}

namespace Game {
  static std::size_t   COLUMN_COUNT     = 48u;
  static std::size_t   CURRENT_SCORE    = 0u;
  static Pixel        *DISPLAY          = NULL;
  static std::size_t   DISPLAY_CAPACITY = 0u;
  static std::size_t   FRUIT_CAPACITY   = 0u;
  static std::size_t   FRUIT_COUNT      = 0u;
  static Fruit        *FRUITS           = NULL;
  static std::size_t   HIGH_SCORE       = 0u;
  static std::size_t   ROW_COUNT        = 12u;
  static std::FILE    *SCORE_FILE       = NULL;
  static Snake const  *SNAKE            = NULL;
  static std::size_t   WALL_COUNT       = 0u;
  static Wall         *WALLS            = NULL;

  namespace Assets {
    Pixel const BACKGROUND          = ' ';
    Asset const BONUS_FRUIT         = "BB" "\0" "BB" "\0";
    Asset const BORDER_BOTTOM       = "_" "\0";
    Asset const BORDER_LEFT         = "|" "\0";
    Asset const BORDER_RIGHT        = "|" "\0";
    Asset const BORDER_TOP          = "-" "\0";
    Asset const CORNERS[]           = {"/" "\0", "\\" "\0", "\\" "\0", "/" "\0"};
    Pixel const FLOOR               = BACKGROUND;
    Asset const FRUIT               = "FF" "\0" "FF" "\0";
    Asset const GRASS[]             = {"." "\0", "^" "\0", "`" "\0"};
    Asset const INVINCIBLE_FRUIT    = "II" "\0" "II" "\0";
    Asset const SNAKE_EAST_TO_NORTH = "S " "\0" "ss" "\0";
    Asset const SNAKE_EAST_TO_SOUTH = "ss" "\0" "S " "\0";
    Asset const SNAKE_HEAD          = "SS" "\0" "SS" "\0";
    Asset const SNAKE_NORTH_TO_EAST = "s " "\0" "sS" "\0";
    Asset const SNAKE_NORTH_TO_WEST = " s" "\0" "Ss" "\0";
    Asset const SNAKE_SOUTH_TO_EAST = "sS" "\0" "s " "\0";
    Asset const SNAKE_SOUTH_TO_WEST = "Ss" "\0" " s" "\0";
    Asset const SNAKE_TAIL          = "ss" "\0" "ss" "\0";
    Asset const SNAKE_WEST_TO_NORTH = " S" "\0" "ss" "\0";
    Asset const SNAKE_WEST_TO_SOUTH = "ss" "\0" " S" "\0";
    Asset const WALL                = "##" "\0" "##" "\0";
  }
}

/* Utilization > ... */
using Game::Asset;
using Game::Fruit;
using Game::Object;
using Game::Pixel;
using Game::Snake;
using Game::Wall;

using Game::launder;
using Game::maximum;
using Game::randint;

/* Class */
class Object {
  private:
    template <std::size_t (*accessor)(std::size_t), std::size_t (*mutator)(std::size_t, std::size_t)>
    union coordinate_t {
      inline coordinate_t& operator =(std::size_t const coordinate) { this -> coordinates = (*mutator)(this -> coordinates, coordinate); return *this; }
      inline operator std::size_t() const { return (*accessor)(this -> coordinates); }

      private: std::size_t coordinates;
    };

    template <std::size_t (*accessor)(Asset)>
    union size_t {
      inline operator std::size_t() const {
        static std::size_t size = 0u;

        if (0u == size) {
          for (Asset const *const assets[] = {&Game::Assets::BONUS_FRUIT, &Game::Assets::FRUIT, &Game::Assets::INVINCIBLE_FRUIT, &Game::Assets::SNAKE_EAST_TO_NORTH, &Game::Assets::SNAKE_EAST_TO_SOUTH, &Game::Assets::SNAKE_HEAD, &Game::Assets::SNAKE_NORTH_TO_EAST, &Game::Assets::SNAKE_NORTH_TO_WEST, &Game::Assets::SNAKE_SOUTH_TO_EAST, &Game::Assets::SNAKE_SOUTH_TO_WEST, &Game::Assets::SNAKE_TAIL, &Game::Assets::SNAKE_WEST_TO_NORTH, &Game::Assets::SNAKE_WEST_TO_SOUTH, &Game::Assets::WALL}, *const *asset = assets + (sizeof(assets) / sizeof(Asset const*)); assets != asset; )
          size = maximum(size, (*accessor)(*--asset));

          for (Asset const *asset = Game::Assets::GRASS + (sizeof(Game::Assets::GRASS) / sizeof(Asset)); Game::Assets::GRASS != asset; )
          size = maximum(size, (*accessor)(*--asset));
        }

        return value;
      }
    };

    // ...
    inline static std::size_t getColumn(std::size_t const coordinates) { return coordinates % Game::COLUMN_COUNT; }
    inline static std::size_t getRow   (std::size_t const coordinates) { return coordinates / Game::COLUMN_COUNT; }
    inline static std::size_t setColumn(std::size_t const coordinates, std::size_t const column) { return column + (Game::COLUMN_COUNT * Object::getRow(coordinates)); }
    inline static std::size_t setRow   (std::size_t const coordinates, std::size_t const row)    { return Object::getColumn(coordinates) + (Game::COLUMN_COUNT * row); }

  public:
    enum Type { FRUIT = 0x1u, FRUIT_BONUS, FRUIT_INVINCIBLE, SNAKE, SNAKE_BODY, SNAKE_TAIL, WALL };

    static size_t<&Game::Assets::getHeight> const HEIGHT;
    static size_t<&Game::Assets::getWidth>  const WIDTH;

    // ... --- WARN (Lapys) -> Direct member function access is undefined behavior
    union {
      coordinate_t<&Object::getColumn, &Object::setColumn> column;
      coordinate_t<&Object::getRow,    &Object::setRow>    row;
    };
};
  Object::size_t<&Game::Assets::getHeight> const Object::HEIGHT = Object::size_t<&Game::Assets::getHeight>();
  Object::size_t<&Game::Assets::getWidth>  const Object::WIDTH  = Object::size_t<&Game::Assets::getWidth>();

  // ...
  class Fruit : public Object { public: enum { BONUS = 0x1u, INVINCIBLE } type; };
  class Wall  : public Object {};

  class Snake : public Object {
    public:
      class Tail : public Object {};

    private:
      union TailCollection {
        union {
          friend union TailCollection;

          private: void *value;
          public: inline operator std::size_t() const { return NULL != this -> value ? *launder(static_cast<std::size_t*>(this -> value)) : 0u; }
        } length;

        inline operator Tail*() const {
          if (NULL == this -> length.value)
          return NULL;

          for (Tail *tails = static_cast<Tail*>(this -> length.value); ; ++tails) {
            if (tails > static_cast<std::size_t*>(this -> length.value) + 1)
            return launder(tails);
          }
        }
      };

    // ...
    public:
      TailCollection tail;
  };

/* Function */
void Game::Assets::draw(void (*renderer)(Pixel[], Pixel, Game::DrawInformation), Asset asset, std::size_t const x, std::size_t const y, std::size_t const width, std::size_t height, Game::DrawInformation const information) {
  static std::size_t const borderRightWidth = Game::Assets::getWidth(Game::Assets::BORDER_RIGHT);
  static std::size_t const borderLeftWidth  = Game::Assets::getWidth(Game::Assets::BORDER_LEFT);
  static std::size_t const boardWidth       = Game::COLUMN_COUNT * Object::WIDTH;
  static Pixel *const      boardDisplay = Game::DISPLAY + (2u + borderRightWidth + boardWidth + (2u * borderLeftWidth));

  // ...
  if (NULL == renderer)
  renderer = &Game::put;

  for (Pixel *display = boardDisplay + x + (y * boardWidth) + (y * (2u + borderLeftWidth + borderRightWidth)); height--; ++asset, display += 2u + borderLeftWidth + borderRightWidth + (boardWidth - width))
  for (std::size_t count = width; count; --count) (*renderer)(display++, *(asset++), information);
}

// ... --- MINIFY (Lapys)
std::size_t Game::Assets::getHeight(Asset asset) { for (std::size_t height = 0u; ; ) if ('\0' == *(asset++)) { ++height; if ('\0' == *asset) return height; } }
std::size_t Game::Assets::getWidth (Asset asset) { for (std::size_t count = 0u, width = 0u; ; ) { if ('\0' == *(asset++)) { width = maximum(count, width); count = 0u; if ('\0' == *asset) { return width; } continue; } ++count; } }

// ...
void Game::draw(void (*renderer)(Pixel[], Pixel, Game::DrawInformation)) {
  static bool wallsRendered = false;

  // ...
  if (NULL == renderer)
  renderer = &Game::put;

  // ...
  if (false == wallsRendered) {
    std::size_t const height = Game::Assets::getHeight(Game::Assets::WALL);
    std::size_t const width  = Game::Assets::getWidth(Game::Assets::WALL);

    // ...
    wallsRendered = true;

    for (Wall const *wall = Game::WALLS; wall != Game::WALLS + Game::WALL_COUNT; ++wall)
    Game::Assets::draw(renderer, Game::Assets::WALL, Object::WIDTH * launder(wall) -> column, Object::HEIGHT * launder(wall) -> row, width, height, static_cast<DrawInformation>(Object::WALL));
  }
}

// ...
void Game::input(char const input) {
  std::printf("[" TITLE "] '%c'" "\r\n", input);
  switch (input) {
    case 'A': break;
    case 'D': break;
    case 'S': break;
    case 'W': break;

    case 'Q': std::exit(EXIT_SUCCESS); break;
  }
}

// ...
template <typename type>
type* Game::launder(type* const pointer) {
  #ifdef __cpp_lib_launder
    return std::launder(pointer);
  #else
    return pointer;
  #endif
}

// ...
std::size_t Game::maximum(std::size_t const integerA, std::size_t const integerB) {
  return integerA > integerB ? integerA : integerB;
}

// ...
void Game::quit() {
  std::free(Game::DISPLAY);
  std::free(Game::WALLS);
  if (NULL != Game::SCORE_FILE) std::fclose(Game::SCORE_FILE);

  // ...
  std::fputs("\r\n" "[" TITLE "] Game terminating", stderr);
  std::exit(EXIT_SUCCESS);
}

void Game::quit(int const signal) {
  switch (signal) {
    case SIGINT : std::fputs("\r\n" "[" TITLE "] Game interrupted",                stderr); break;
    case SIGSEGV: std::fputs("\r\n" "[" TITLE "] Game requested unpermitted data", stderr); break;
    default: break;
  }

  Game::quit();
}

// ...
std::size_t Game::randint(std::size_t const range) {
  std::size_t (&seeds)[4] = const_cast<std::size_t (&)[4]>(Game::randseed());
  std::size_t const control = seeds[1] << 17u;
  std::size_t const random  = seeds[0] + seeds[3];

  // ...
  seeds[2] ^= seeds[0];
  seeds[3] ^= seeds[1];
  seeds[1] ^= seeds[2];
  seeds[0] ^= seeds[3];

  seeds[2] ^= control;
  seeds[3]  = (seeds[3] << 45u) | (seeds[3] >> 19u);

  return random % range;
}

std::size_t const (&Game::randseed(std::size_t const reseed))[4] {
  static std::size_t seeds[4] = {0u, 0x2A430C43u, 0u, 0xDE83A17u}; // ->> pre-seeded to `0u`

  // ...
  for (std::size_t *seed = seeds + 4, state; 0u != reseed && seed != seeds; ) {
    state  = reseed + (0x9E3779B9u * ((seed - seeds) >> 1u));
    state ^= state >> 15u; state *= 0x85EBCA6Bu;
    state ^= state >> 13u; state *= 0xC2B2AE35u;
    state ^= state >> 16u;

    *--seed = state;
    *--seed = state >> sizeof(uint_least32_t);
  }

  return seeds;
}

/* Main */
int main(int, char* arguments[]) /* noexcept */ {
  bool              pendingBoardSize = true;
  std::time_t const time             = std::time(static_cast<std::time_t*>(NULL));

  // ...
  std::atexit(static_cast<void (*)()>(&Game::quit));
  std::setbuf(stderr, NULL);
  std::signal(SIGINT,  static_cast<void (*)()>(&Game::quit));
  std::signal(SIGSEGV, static_cast<void (*)()>(&Game::quit));

  randseed(time == static_cast<std::time_t>(-1) ? 0u : static_cast<std::size_t>(time));

  // ...
  if (NULL != arguments[1]) {
    if (NULL == arguments[2]) {
      std::fputs("[" TITLE "] Expected both width then height to be specified", stderr);
      return EXIT_SUCCESS;
    }

    for (std::size_t *const counts[] = {&Game::COLUMN_COUNT, &Game::ROW_COUNT}, *const *count = counts; count != counts + (sizeof(counts) / sizeof(std::size_t*)); ++count) {
      bool        invalid = false;
      std::size_t value   = 0u;

      // ...
      for (char *argument = *++arguments; '\0' != *argument; ++argument) {
        unsigned char digit;

        // ...
        switch (*argument) {
          case '0': digit = 0u; break;
          case '1': digit = 1u; break;
          case '2': digit = 2u; break;
          case '3': digit = 3u; break;
          case '4': digit = 4u; break;
          case '5': digit = 5u; break;
          case '6': digit = 6u; break;
          case '7': digit = 7u; break;
          case '8': digit = 8u; break;
          case '9': digit = 9u; break;
          default: invalid = true; break;
        }

        if (invalid || value > SIZE_MAX / 10u) {
          std::fprintf(stderr, invalid ? "[" TITLE "] Invalid %5.6s specified: `" : "[" TITLE "] The %5.6s specified is too large: `", &Game::COLUMN_COUNT == *count ? "width" : "height");

          for (argument = *arguments; '\0' != *argument; std::fputc(*argument++, stderr))
          switch (*argument) {
            case '\\': std::fputc('\\',  stderr); break;
            case '`' : std::fputs("\\`", stderr); break;
            case '\b': std::fputs("\\b", stderr); break;
            case '\f': std::fputs("\\f", stderr); break;
            case '\n': std::fputs("\\n", stderr); break;
            case '\r': std::fputs("\\r", stderr); break;
            case '\t': std::fputs("\\t", stderr); break;
            case '\v': std::fputs("\\v", stderr); break;
            case '\0':  case '\1':  case '\2':  case '\3':  case '\4':  case '\5':  case '\6':  case '\7':
            case '\16': case '\17': case '\20': case '\21': case '\22': case '\23': case '\24': case '\25': case '\26': case '\27': case '\30': case '\31': {
              value = 0u;

              for (unsigned char index = static_cast<unsigned char>(*argument); index; index /= 10u) value = (index % 10u) + (value * 10u);
              for (; value; value /= 10u) std::fputc("0123456789"[value % 10u], stderr);
            } break;
          }

          std::fprintf(stderr, invalid ? "` (expected a contiguous collection of digits between 0-9)" : "` (value should be smaller than `%lu%2s`)", static_cast<unsigned long>(SIZE_MAX), "zu");
          return EXIT_SUCCESS;
        }

        value = digit + (value * 10u);
      }

      **count = value;
    }

    pendingBoardSize = false;
  }

  if (pendingBoardSize) {
    #if defined(__APPLE__) || defined(__gnu_linux__) || defined(linux) || defined(__linux) || defined(__linux__) || defined(__MACH__) || defined(__unix) || defined(__unix__)
      /* ... */
    #elif defined(__NT__) || defined(__TOS_WIN__) || defined(_WIN16) || defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(_WIN32_WCE) || defined(_WIN64) || defined(__WINDOWS__)
      HANDLE consoleHandle = INVALID_HANDLE_VALUE;

      // ...
      if (INVALID_HANDLE_VALUE == consoleHandle) consoleHandle = ::CreateFileW(L"CONOUT$", GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, static_cast<LPSECURITY_ATTRIBUTES>(NULL), CREATE_NEW | OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_NO_BUFFERING, static_cast<HANDLE>(NULL));
      if (INVALID_HANDLE_VALUE == consoleHandle) consoleHandle = ::GetStdHandle(STD_OUTPUT_HANDLE);

      if (INVALID_HANDLE_VALUE != consoleHandle) {
        CONSOLE_FONT_INFO          consoleFontInformation;
        CONSOLE_SCREEN_BUFFER_INFO consoleScreenBufferInformation;
        int                        systemHeight;
        int                        systemWidth;

        // ...
        if (FALSE != ::GetCurrentConsoleFont(consoleHandle, FALSE, &consoleFontInformation) && FALSE != ::GetConsoleScreenBufferInfo(consoleHandle, &consoleScreenBufferInformation)) {
          ::SetProcessDPIAware();
          systemHeight = ::GetSystemMetrics(SM_CYSCREEN);
          systemWidth  = ::GetSystemMetrics(SM_CXSCREEN);

          if (0 != systemHeight && 0 != systemWidth) {
            std::size_t const consoleHeight = ((consoleFontInformation.dwFontSize.Y * consoleScreenBufferInformation.dwSize.Y) * 7u) / 10u;
            std::size_t const consoleWidth  = ((consoleFontInformation.dwFontSize.X * consoleScreenBufferInformation.dwSize.X) * 7u) / 10u;

            // ...
            systemWidth  = (systemWidth  * 7u) / 10u;
            systemHeight = (systemHeight * 7u) / 10u;
            Game::ROW_COUNT    = (consoleHeight < static_cast<unsigned>(systemHeight) ? consoleHeight : systemHeight) / (Object::HEIGHT * consoleFontInformation.dwFontSize.Y);
            Game::COLUMN_COUNT = (consoleWidth  < static_cast<unsigned>(systemWidth)  ? consoleWidth  : systemWidth)  / (Object::WIDTH  * consoleFontInformation.dwFontSize.X);
          }
        }

        ::CloseHandle(consoleHandle);
      }
    #endif
  }

  Game::DISPLAY_CAPACITY = (
    // ->> CRLF newlines
    (2u * (Game::ROW_COUNT * Object::HEIGHT)) +
    (2u * maximum(Game::Assets::getHeight(Game::Assets::BORDER_BOTTOM), maximum(Game::Assets::getHeight(Game::Assets::CORNERS[2]), Game::Assets::getHeight(Game::Assets::CORNERS[3])))) +
    (2u * maximum(Game::Assets::getHeight(Game::Assets::BORDER_TOP),    maximum(Game::Assets::getHeight(Game::Assets::CORNERS[0]), Game::Assets::getHeight(Game::Assets::CORNERS[1])))) +

    // ->> Left & right borders
    (Game::ROW_COUNT * maximum(Object::HEIGHT, Game::Assets::getHeight(Game::Assets::BORDER_LEFT))) +
    (Game::ROW_COUNT * maximum(Object::HEIGHT, Game::Assets::getHeight(Game::Assets::BORDER_RIGHT))) +

    // ->> Top & left borders
    (Game::COLUMN_COUNT * maximum(Object::WIDTH, Game::Assets::getWidth(Game::Assets::BORDER_BOTTOM)) * maximum(Game::Assets::getHeight(Game::Assets::BORDER_BOTTOM), maximum(Game::Assets::getHeight(Game::Assets::CORNERS[2]), Game::Assets::getHeight(Game::Assets::CORNERS[3])))) +
    (Game::COLUMN_COUNT * maximum(Object::WIDTH, Game::Assets::getWidth(Game::Assets::BORDER_TOP))    * maximum(Game::Assets::getHeight(Game::Assets::BORDER_TOP),    maximum(Game::Assets::getHeight(Game::Assets::CORNERS[0]), Game::Assets::getHeight(Game::Assets::CORNERS[1])))) +

    (Game::ROW_COUNT * Object::SIZE * 2u) +                                 // ->> CRLF newlines
    (((Game::COLUMN_COUNT * Object::WIDTH)  + 2u) * 2u) +                   // ->> Bottom & top borders
    (((Game::ROW_COUNT    * Object::HEIGHT) + 2u) * 2u) +                   // ->> Left & right borders
    (Game::COLUMN_COUNT * Game::ROW_COUNT * Object::HEIGHT * Object::WIDTH) // ->> Board
  );

  static std::size_t const borderLeftWidth  = Game::Assets::getWidth(Game::Assets::BORDER_LEFT);
  static std::size_t const borderRightWidth = Game::Assets::getWidth(Game::Assets::BORDER_RIGHT);
  static std::size_t const boardWidth       = Game::COLUMN_COUNT * Object::WIDTH;
}
