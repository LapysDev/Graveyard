/* Import */
#include <iostream> // Input-Output Stream
#include "src/lapys.hpp" // Lapys

/* Main */
void Lapys::Main(...) {
    /* [Begin] ... */
    std::cout.write("[PROGRAM INITIATED]\n\r", 21u);

    /* [End] ... */
    std::cout.write("[PROGRAM TERMINATED]\0", 21u);
}
