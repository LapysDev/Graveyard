/* ... --- NOTE (Lapys) -> Guard against re-implementing this source into the same environment. */
#ifndef LAPYS
    /* Namespace > iPhone */
    namespace iOS {}
#endif
