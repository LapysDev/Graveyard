/* ... --- NOTE (Lapys) -> Guard against re-implementing this source into the same environment. */
#ifndef LAPYS
    /* Definition */
    class Array;
    class BigNumber;
    class Context;
    class Function;
    class Number;
    class Object;
    class String;
    class Symbol;

    struct var;
#endif
