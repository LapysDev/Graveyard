/* ... --- NOTE (Lapys) -> Guard against re-implementing this source into the same environment. */
#ifndef LAPYS
    /* Utilization */
    using Lapys::LapysDevelopmentKit::Constants::Infinity;
    using Lapys::LapysDevelopmentKit::Constants::null;
    using Lapys::LapysDevelopmentKit::Constants::NaN;
#endif
