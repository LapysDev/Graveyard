/* Modification > Character > [Constructor] */
constexpr inline character_t::character_t(unsigned int const value) : value{value} {}
