/* Modification > Boolean > [Constructor] */
constexpr inline boolean_t::boolean_t(bool const value) : value{value} {}
