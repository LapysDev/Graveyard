/* Import > Lapys */
#include "lapys.hpp"

int main(void) {}
// /* Main */
// void Main(ArgumentList const arguments[]) {
//     console.log("Hello, World!");
// }
