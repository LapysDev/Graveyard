/* Constants > ... */
const Console console;
const null_pointer null;
const var undefined;
