/* Class > ... */
class Console;
class File;
class Stream;
class Window;
