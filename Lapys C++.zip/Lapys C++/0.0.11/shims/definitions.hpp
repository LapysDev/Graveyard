/* Definition > ... */
typedef ClampedArray Arguments;
