/* Class > ... */
class Array;
class BigNumber;
class Boolean;
class ClampedArray;
class ClampedNumber;
class Function;
class Number;
class Object;
class RegularExpression;
class String;
class Symbol;

struct var;
