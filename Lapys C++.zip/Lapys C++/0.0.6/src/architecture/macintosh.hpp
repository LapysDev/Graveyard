/* Namespace > Macintosh */
namespace Macintosh {}
