/* Namespace > System */
namespace System {
        // Method > ...
        constexpr size_t getPageSize(void) noexcept;
}

/* Import > System */
#include "system.cpp"
