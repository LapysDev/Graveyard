Console::BINARY
Console::DECIMAL
Console::FIXED
Console::FORMAT
Console::HEX
Console::OCTAL
Console::PRETTY
Console::SCIENTIFIC

Console::HORIZONTAL_TAB '\t'
Console::FORMFEED '\f'
Console::LINEFEED '\n'
Console::NEWLINE "\r\n" or Console::LINEFEED
Console::RETURN '\r'
Console::TAB Console::HORIZONTAL_TAB
Console::TERMINATOR '\0'
Console::VERTICAL_TAB '\v'
