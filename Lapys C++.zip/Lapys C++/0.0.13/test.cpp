/* Utilization > Lapys */
using Lapys;

/* Main */
void Lapys::Main(Process::Arguments const[]) {}
