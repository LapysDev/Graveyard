/* Class > Symbol */
class Symbol {};
