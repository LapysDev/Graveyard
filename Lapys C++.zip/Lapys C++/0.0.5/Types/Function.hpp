/* Class > Function */
class Function {};
