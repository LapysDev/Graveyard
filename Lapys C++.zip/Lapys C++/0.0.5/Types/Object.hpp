/* Class > Object */
class Object {};
