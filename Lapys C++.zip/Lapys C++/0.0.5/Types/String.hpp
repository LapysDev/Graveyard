/* Class > String --- NOTE (Lapys) -> Array of `wchar_t``s. */
class String {};
