/* Class > Array --- NOTE (Lapys) -> Base: `void*`.  */
class Array {};
