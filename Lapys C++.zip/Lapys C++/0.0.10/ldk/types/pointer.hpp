/* Class > Pointer */
struct pointer {
    // [...]
    private:
        // Definition > Value
        void *value;

    // [...]
    public:
};
