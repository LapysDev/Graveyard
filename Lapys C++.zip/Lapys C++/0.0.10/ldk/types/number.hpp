/* Class > Number */
struct number {};
