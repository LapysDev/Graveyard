/* Class > Stream */
class Stream {};
