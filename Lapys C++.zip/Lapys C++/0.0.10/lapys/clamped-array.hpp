/* Class > Clamped Array */
class ClampedArray {};
