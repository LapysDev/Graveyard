/* Import > ... */
#include "src/lapys.hpp" // Lapys

/* Main */
int main(void) { return EXIT_SUCCESS; }
