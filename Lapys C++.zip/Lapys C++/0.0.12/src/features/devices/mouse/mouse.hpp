/* Class > Mouse */
class Mouse;
