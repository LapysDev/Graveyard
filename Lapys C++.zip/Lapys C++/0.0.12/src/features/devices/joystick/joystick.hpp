/* Class > Joy Stick */
class JoyStick;
