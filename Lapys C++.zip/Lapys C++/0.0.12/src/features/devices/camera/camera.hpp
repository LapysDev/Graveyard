/* Class > Camera */
class Camera;
