/* Class > Device */
class Device;
