/* Class > Speaker */
class Speaker;
