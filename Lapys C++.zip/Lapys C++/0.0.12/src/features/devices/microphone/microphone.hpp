/* Class > Microphone */
class Microphone;
