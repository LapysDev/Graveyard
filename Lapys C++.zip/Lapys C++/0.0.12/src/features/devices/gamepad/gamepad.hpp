/* Class > Gamepad */
class Gamepad;
