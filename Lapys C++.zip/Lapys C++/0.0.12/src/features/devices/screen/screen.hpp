/* Class > Screen */
class Screen;
