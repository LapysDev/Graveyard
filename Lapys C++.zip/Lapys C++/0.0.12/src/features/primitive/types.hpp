/* Class > ... --- NOTE (Lapys) -> Generalized wrappers over C++ POD/ primitive/ scalar types */
struct boolean;
struct character;
struct fraction;
struct integer;
struct null_pointer;
struct number;
struct pointer;
struct raw_pointer;
struct string;
