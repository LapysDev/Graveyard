/* Declaration > ... */
void alert(...);
void print(...);
void prompt(...);
void scan(...);

/* Namespace > Program --- NOTE (Lapys) -> Global namespace. */
namespace Program {
    /* Declaration > ... */
    Arguments getArguments(...);
    void getArgumentsCount(...);
    void getArgumentsVector(...);
}
