/* Function > Serve */
function serve(action, url, promise, data, configuration) {
    // Constant > (Request, Response, ...)
    var request = {"body": null, "method": null, "url": null, "value": null};
    var response = {"text": null, "type": null, "value": null, "xml": null};

    var status = {"text": null, "value": null};

    // Update > ...
    (data !== null && typeof data == "object") || (data = {});
    (configuration !== null && typeof configuration == "object") || (configuration = {});
    (promise !== null && typeof promise == "function") || (promise = function() {});

    // Modification
        // Request > ...
        request["body"] = new FormData;
        request["method"] = action == "CONNECT" || action == "DELETE" || action == "GET" || action == "HEAD" || action == "OPTIONS" || action == "PATCH" || action == "POST" || action == "PUT" || action == "TRACE" ? action : null;
        request["url"] = url === null || url === undefined ? "" : String(url);

        Object.defineProperty(request, "implementsBody", {configurable: true, enumerable: true, value: function implementsBody() { return request["method"] != "GET" && request["method"] != "HEAD" }, writable: true});
        Object.defineProperty(request, "toString", {configurable: true, enumerable: false, value: function toString() { return request["value"] === null ? "" : String(request["value"]) }, writable: true});
        Object.defineProperty(request, "valueOf", {configurable: true, enumerable: false, value: function valueOf() { return request["value"] }, writable: true});

        // Response > ...
        Object.defineProperty(response, "toString", {configurable: true, enumerable: false, value: function toString() { return response["text"] }, writable: true});
        Object.defineProperty(response, "valueOf", {configurable: true, enumerable: false, value: function valueOf() { return response["value"] }, writable: true});

        // Status > ...
        Object.defineProperty(status, "toString", {configurable: true, enumerable: false, value: function toString() { return status["text"] }, writable: true});
        Object.defineProperty(status, "valueOf", {configurable: true, enumerable: false, value: function valueOf() { return status["value"] }, writable: true});

        // ...
        if ("async" in configuration) try { configuration["async"] = !!configuration["async"] } catch (error) {} else configuration["async"] = true; // NOTE (Lapys) -> Synchronous requests are deprecated.
        try { configuration["json"] = !!configuration["json"] } catch (error) {}

    // ...; Loop > Insertion
    var dataLabel;
    for (dataLabel in data) request["body"].append(dataLabel, data[dataLabel]);

    // Logic
    if (typeof fetch == "function") {
        // Constant > Request Configuration
        var requestConfiguration = {"method": request["method"]};

        // Modification > Request Configuration > ...
        request.implementsBody() && (requestConfiguration["body"] = request["body"]);
        ("cache" in configuration) && (requestConfiguration["cache"] = configuration["cache"]); // -> "default" | "force-cache" | "no-cache" | "only-if-cached" | "reload"
        ("credentials" in configuration) && (requestConfiguration["credentials"] = configuration["credentials"]); // -> "include" | "omit" | "same-origin"
        ("headers" in configuration) && (requestConfiguration["headers"] = configuration["headers"]);
        ("mode" in configuration) && (requestConfiguration["mode"] = configuration["mode"]); // -> "cors" | "no-cors" | "same-origin"
        ("redirect" in configuration) && (requestConfiguration["redirect"] = configuration["redirect"]); // -> "error" | "follow" | "manual"
        ("referrer" in configuration) && (requestConfiguration["referrer"] = configuration["referrer"]); // -> "client" | "no-referrer"

        // Update > Request -> `[object Promise]`
        request["value"] = fetch(request["url"], requestConfiguration);

        // ...
        request["value"].then(function sent(argument) {
            // Modification > (Response, ...) > ...
            response["type"] = argument.type;

            status["text"] = argument.statusText;
            status["value"] = argument.status;

            // Return
            return configuration["json"] ? argument.json() : argument.text()
        }).then(function sent(argument) {
            // Modification > (Response, ...) > ...
            response["text"] = configuration["json"] ? JSON.stringify(argument) : String(argument);
            response["value"] = argument;

            // ...
            promise(response, status)
        })
    }

    else {
        // Update > Request -> `[object XMLHttpRequest]`
        request["value"] = new XMLHttpRequest;

        // Event > Request > Load End
        request["value"].addEventListener("loadend", function sent() {
            // Modification > (Response, ...) > ...
            response["text"] = request["value"].responseText;
            response["type"] = request["value"].responseType || "basic";
            response["value"] = request["value"].response;
            response["xml"] = request["value"].responseXML;

            status["text"] = request["value"].statusText;
            status["value"] = request["value"].status;

            // Deletion
            request["value"].removeEventListener("loadend", sent);

            // ...
            promise(response, status)
        });

        /* Logic --- NOTE (Lapys) -> Normally, `XMLHttpRequest` objects generate an appropriate `Content-Type`.
                Manually determining the `Content-Type` removes the `boundary` attribute PHP requires to assert the request.
        */
        if ("headers" in configuration) { var headers = configuration["headers"]; if (typeof headers == "object") { var header; for (header in headers) request["value"].setRequestHeader(header, headers[header]) } }

        // Request > ...
        request["value"].open(request["method"], request["url"], FLAG = configuration["async"]);
        request.implementsBody() ? request["value"].send(request["body"]) : request["value"].send()
    }

    // Return
    return request
}
