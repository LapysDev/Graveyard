<?php
    /* Import > ... */
    include "connect-to-database.php";

    /* Constant > Record */
    $record = (object) array(
         "name" => $_POST["record-name"],
         "age" => $_POST["record-age"]
    );

    // Logic > Exception Handling
    if (count($database_connection -> query("SELECT name, age FROM " . $database_primary_table -> name . " WHERE (name = '" . $record -> name . "' AND age = " . $record -> age . ") LIMIT 1") -> fetchAll()) > 0)
    try {
        // Deletion
        $database_connection -> query("DELETE FROM " . $database_primary_table -> name . " WHERE (name = '" . $record -> name . "' AND age = " . $record -> age . ")");
    } catch (PDOException $error) {
        // Terminate
        die($error -> getMessage());
    }

    /* Import > ... */
    include "disconnect-from-database.php";
?>
