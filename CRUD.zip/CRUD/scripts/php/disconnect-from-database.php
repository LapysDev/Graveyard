<?php
    // {Terminate} Update > Database Connection
    $database_connection = null;
?>
