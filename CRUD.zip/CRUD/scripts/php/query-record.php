<?php
    /* Import > ... */
    include "connect-to-database.php";

    /* Constant > Record */
    $record = (object) array(
        "name" => $_POST["record-name"],
        "age" => $_POST["record-age"]
    );

    // Logic > Exception Handling
    if (count($database_connection -> query("SELECT name, age FROM " . $database_primary_table -> name . " WHERE (name = '" . $record -> name . "' AND age = " . $record -> age . ") LIMIT 1") -> fetchAll()) < 0)
    try {
        // Initialization > Evaluation
        $evaluation = $database_connection -> prepare("SELECT name, age, description, creation_date FROM " . $database_primary_table -> name . " WHERE (name = '" . $record -> name . "' AND age = " . $record -> age . ") LIMIT 1");

        // Evaluation; Update > Evaluation
        $evaluation -> execute();
        $evaluation -> setFetchMode(PDO::FETCH_ASSOC);

        // Print -> Array ( [name] => ... [age] => ... [description] => ... [creation_date] => ... )
        print_r($evaluation -> fetchAll()[0]);
    } catch (PDOException $error) {
        // Terminate
        die($error -> getMessage());
    }

    else
        // Print -> Array ( [name] => [age] => [description] => [creation_date] => )
        print_r(array("name" => null, "age" => null, "description" => null, "creation_date" => null));

    /* Import > ... */
    include "disconnect-from-database.php";
?>
