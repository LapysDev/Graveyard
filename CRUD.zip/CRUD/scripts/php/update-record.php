<?php
    /* Import > ... */
    include "connect-to-database.php";

    /* Constant > Record */
    $record = (object) array(
        "name" => $_POST["record-name"],
        "age" => $_POST["record-age"],
        "description" => $_POST["record-description"],
        "creation_date" => $_POST["record-creation_date"]
    );

    // Logic > Exception Handling
    if (count($database_connection -> query("SELECT name, age FROM " . $database_primary_table -> name . " WHERE (name = '" . $record -> name . "' AND age = " . $record -> age . ") LIMIT 1") -> fetchAll()) > 0)
    try {
        // Evaluation
        $database_connection -> prepare("UPDATE " . $database_primary_table -> name . " SET description = '" . $record -> description . "', creation_date = '" . $record -> creation_date . "' WHERE (name = '" . $record -> name . "' AND age = " . $record -> age . ')') -> execute();
    } catch (PDOException $error) {
        // Terminate
        die($error -> getMessage());
    }

    /* Import > ... */
    include "disconnect-from-database.php";
?>
