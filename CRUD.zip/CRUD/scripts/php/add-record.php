<?php
    /* Import > ... */
    include "connect-to-database.php";

    /* Constant > Record */
    $record = (object) array(
        "name" => $_POST["record-name"],
        "age" => $_POST["record-age"],
        "description" => $_POST["record-description"],
        "creation_date" => $_POST["record-creation_date"]
    );

    // Logic > Exception Handling
    if ($database_connection -> query("SELECT name, age FROM " . $database_primary_table -> name . " WHERE (name = '" . $record -> name . "' AND age = " . $record -> age . ") LIMIT 1") -> fetchColumn() <= 0)
    try {
        // Evaluation
        $database_connection -> exec("INSERT INTO " . $database_primary_table -> name . " (name, age, description, creation_date) VALUES ('" . $record -> name . "', " . $record -> age . ", '" . $record -> description . "', '" . $record -> creation_date . "')");
    } catch (PDOException $error) {
        // Terminate
        die($error -> getMessage());
    }

    /* Import > ... */
    include "disconnect-from-database.php";
?>
