<?php
    /* Global > (..., Password, Username) */
    $database_primary_table = (object) array("name" => "Records");
    $password = "";
    $username = "root";

    // Error Handling
    try {
        /* Constant > Database Connection */
        $database_connection = new PDO("mysql:host=localhost;dbname=CRUD", $username, $password);

        // Modification > Database Connection > Attribute : Error Mode
        $database_connection -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $error) {
        // Terminate
        die("Connection to database failed: " . $error -> getMessage());
    }
?>
