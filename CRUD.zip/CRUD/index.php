<!DOCTYPE html>
<html dir=ltr lang=en-US>
    <head>
        <!-- Document Script -->
        <script language=javascript src=scripts/js/serve.js type=text/javascript> </script>

        <!-- Document Stylesheet -->
        <style media=all type=text/css>
            /* DOM Elements */
                /* All */
                * { box-sizing: inherit }
                    /* States > Selection */
                    ::selection { background-color: transparent }

                /* <a> */
                a { text-decoration: none }

                /* <a>, <button>, <input> */
                a, button, input[type=button], input[type=reset], input[type=submit] { cursor: pointer }

                /* <body> */
                body {
                    font-size: 16px;
                    font-size: 1em;
                    margin: 0
                }

                /* <body>, <html>, <main> */
                body, html, main { height: 100%; width: 100% }

                /* <button>, <input> */
                button, input[type=button], input[type=reset], input[type=submit] { vertical-align: middle }

                /* <html> */
                html { box-sizing: content- box }

                /* <textarea> */
                textarea { resize: none }

            /* Components > Background Polygon */
            .background-polygon {
                animation: polygon__fade_in 1000ms 0s 1, polygon__spin 50s linear 0s infinite;
                border: 50px solid rgba(0, 0, 0, .05);
                border-right-color: transparent;
                border-top-color: transparent;
                height: 0;
                opacity: 1;
                position: relative;
                transform: rotate(0deg);
                width: 0
            }
                /* @keyframes > (Fade In, Spin) */
                @keyframes polygon__fade_in {
                    0% { opacity: 0 }
                    to { opacity: 1 }
                }

                @keyframes polygon__spin {
                    0% { transform: rotate(0deg) }
                    50% { transform: rotate(360deg) }
                    to { transform: rotate(0deg) }
                }

            /* Assets */
                /* Aside */
                #aside {
                    background-color: #F9F9F9;
                    height: 100%;
                    left: 0;
                    overflow: hidden;
                    position: fixed;
                    top: 0;
                    width: 100%;
                    z-index: -1
                }

                /* Main */
                #main {
                    background-color: transparent;
                    overflow: hidden
                }

                /* Record Information */
                #record-information {
                    /*background-color: #F9F9F9;*/
                    color: #333333;
                    font-family: sans-serif;
                    font-size: 133.333%;
                    height: 90%;
                    padding: 5%;
                    width: 90%
                }
                    /* <fieldset> */
                    #record-information fieldset[role=container] {
                        border: none;
                        margin: 2.5% 0
                    }
                        /* <input>, <textarea> */
                        #record-information fieldset[role=container] input,
                        #record-information fieldset[role=container] textarea {
                            background-color: transparent;
                            border: none;
                            border-bottom: 3px solid #666666;
                            border-radius: 0;
                            color: #333333;
                            float: right;
                            font-family: sans-serif;
                            margin: 0;
                            margin-right: 5%;
                            padding: 6.5px 1%;
                            outline: 1px solid rgba(0, 0, 0, .025);
                            transition: border-color 300ms ease-out;
                            width: 55%
                        }
                            /* Quasi > Placeholder */
                            #record-information fieldset[role=container] input::placeholder,
                            #record-information fieldset[role=container] textarea::placeholder {
                                opacity: .5;
                                transition: 300ms ease-out
                            }

                            /* States > Focus */
                            #record-information fieldset[role=container] input:focus,
                            #record-information fieldset[role=container] textarea:focus {
                                background-color: rgba(0, 0, 0, .025);
                                border-color: #0069FF
                            }
                                /* Quasi > Placeholder */
                                #record-information fieldset[role=container] input:focus::placeholder,
                                #record-information fieldset[role=container] textarea:focus::placeholder { opacity: 0 }

                        /* <label> */
                        #record-information fieldset[role=container] label {
                            color: #666666;
                            font-weight: bold;
                            padding-left: 10%;
                            width: 20%
                        }

                    /* Header */
                    #record-information [role=header] {
                        background-color: #0069FF;
                        border: 1px solid #0069FF;
                        border-bottom-width: 0;
                        border-radius: 9px;
                        border-bottom-left-radius: 0;
                        border-bottom-right-radius: 0;
                        box-shadow: 12.5px 0 0 0 rgba(0, 0, 0, .125), 75px 0 0 0 rgba(0, 0, 0, .375);
                        color: #FFFFFF;
                        cursor: default;
                        font-size: 200%;
                        font-weight: bolder;
                        padding-bottom: 1%;
                        padding-left: 5%;
                        padding-top: 1%;
                        width: 250px
                    }

                    /* Confirmation */
                    #record-information-confirmation {
                        background-color: #F0F0F0;
                        overflow: hidden;
                        padding: 1% 0;
                        text-align: center
                    }
                        /* Button */
                        #record-information-confirmation [role~=button] {
                            appearance: none;
                            background-color: #FFFFFF;
                            border: 1px solid #CCCCCC;
                            bottom: 0;
                            box-shadow: 0 0 0 1px rgba(255, 255, 255, .5);
                            color: #666666;
                            font-family: sans-serif;
                            font-size: 20px;
                            font-weight: normal;
                            margin: 0 10px;
                            padding: 1% 0;
                            position: relative;
                            transition: 300ms ease-out;
                            transition-property: border-color, bottom, box-shadow, left, right, top;
                            white-space: nowrap;
                            width: 100px;
                            -moz-appearance: none;
                            -webkit-appearance: none
                        }
                            /* States > (Active, Focus, Hover) */
                            #record-information-confirmation [role~=button]:focus,
                            #record-information-confirmation [role~=button]:hover { bottom: 5px }

                            #record-information-confirmation [role~=button]:active { top: 2.5px }
                            #record-information-confirmation [role~=button]:focus { border-color: #0069FF; outline: none; }
                            #record-information-confirmation [role~=button]:hover { box-shadow: 0 7.5px 0 2.5px rgba(0, 0, 0, .033333) }

                        /* Reset */
                        #record-information-confirmation [role~=reset] {
                            background-color: #CC0000;
                            box-shadow: 0 0 0 5000px transparent;
                            border-color: #FFFFFF;
                            color: #FFFFFF;
                            margin-right: 5%;
                            transition: all 300ms ease-out, box-shadow 150ms ease-out
                        }
                            /* States > (Active, Hover) */
                            #record-information-confirmation [role~=reset]:focus { background-color: #AA0000; border-color: #FFFFFF }
                            #record-information-confirmation [role~=reset]:hover { box-shadow: 0 0 0 5000px rgba(255, 0, 0, .25) }

                    /* Entry */
                    #record-information-entry {
                        /*background-color: #F9F9F9;*/
                        border: 1px solid #CCCCCC;
                        border-radius: 9px;
                        border-top-left-radius: 0;
                        border-top-right-radius: 0
                    }

                    /* Prompt */
                        /* Message */
                        #record-information-prompt [role=message] {
                            background-color: #CCCCCC;
                            border: 1px solid #999999;
                            border-radius: 3px;
                            color: #333333;
                            display: block;
                            font-weight: normal;
                            padding: 15px 0;
                            margin-left: auto;
                            margin-right: auto;
                            text-align: center;
                            vertical-align: middle;
                            width: 100%
                        }

                        #record-information-prompt [role=message][state=error] {
                            background-color: #FF9999;
                            border-color: #AA0000;
                            color: #CC0000
                        }

                        #record-information-prompt [role=message][state=info] {
                            background-color: #9999FF;
                            border-color: #0000FF;
                            color: #0000FF
                        }

                        #record-information-prompt [role=message][state=success] {
                            background-color: #99FF99;
                            border-color: #00AA00;
                            color: #009900
                        }

                        #record-information-prompt [role=message][state=warn] {
                            background-color: #FFFF99;
                            border-color: #CCCC00;
                            color: #666600
                        }
        </style>

        <!-- Document Title -->
        <title> CRUD </title>
    </head>

    <body>
        <!-- Aside -->
        <aside id=aside>
            <!-- Document Script -->
            <script language=javascript type=text/javascript>
                /* Main */
                +(void function Main() {
                    /* Constant > Aside */
                    var aside = document.getElementById("aside") || document.getElementsByTagName("aside").item(0);

                    /* Function > (Spawn Polygon, ...) */
                    function spawnPolygon() {
                        // Loop
                        for (var spawnCount = Number.parseInt(Math.random() * 3) + 1; spawnCount; spawnCount--) {
                            // Constant > Polygon
                            var polygon = document.createElement("div");

                            // Modification > Polygon > (Class, Style)
                            polygon.setAttribute("class", "background-polygon");
                            polygon.setAttribute("style", "left: " + Number.parseInt(Math.random() * (innerWidth - 100)) + "px; top: 0px")

                            // Insertion
                            aside.appendChild(polygon)
                            console.log("[DEBUG]")
                        }

                        // [Spawn Polygon]
                        setTimeout(spawnPolygon, requestPolygonSpawnInterval())
                    }
                    function requestPolygonSpawnInterval() { return Number.parseInt(Math.random() * 500) + 1e3 }
                    void function updatePolygons() {
                        // Constant > (Garbage, Polygons)
                        var garbage = [];
                        var polygons = aside.childNodes;

                        // Loop
                        for (var polygonsIterator = 0, polygonsLength = polygons.length; polygonsIterator ^ polygonsLength; polygonsIterator++) {
                            // Constant > Polygon
                            let polygon = polygons.item(polygonsIterator);

                            // Logic
                            if (typeof Element == "function" ? polygon instanceof Element : typeof HTMLElement == "function" ? polygon instanceof HTMLElement : true) {
                                // Style > Polygon > Top; ...
                                polygon.style.top = (Number.parseFloat(polygon.style.top.replace("px", "")) + Math.random()) + "px";
                                (polygon.getBoundingClientRect().top >= innerHeight) && garbage.push(polygon)
                            }
                        }

                        // Loop > Deletion
                        garbage.forEach(function(item) {
                            (typeof Element == "function" ? item instanceof Element : typeof HTMLElement == "function" ? item instanceof HTMLElement : true) &&
                            item.parentNode.removeChild(item)
                        });

                        // [Update Polygons]
                        (typeof requestAnimationFrame == "function" ? requestAnimationFrame : setTimeout)(updatePolygons)
                    }();

                    // [Spawn Polygon]; Deletion
                    setTimeout(spawnPolygon, requestPolygonSpawnInterval() * 2);
                    document.currentScript.parentNode.removeChild(document.currentScript)
                }());
            </script>
        </aside>

        <!-- Main -->
        <main id=main>
            <!-- [Specify] Record Information -->
            <form enctype=multipart/form-data id=record-information method="" name=record-information role=container>
                <!-- Header -->
                <legend role=header> Record </legend>

                <!-- Specifiers -->
                <div id=record-information-entry role=container>
                    <!-- Name, Age -->
                    <fieldset role=container state=required> <label for=record-name role=label> Name </label> <input id=record-name name=record-name placeholder="Name of the Record" role=field type="text"/> </fieldset>
                    <fieldset role=container state=required> <label for=record-age role=label> Age </label> <input id=record-age max=100 min=0 name=record-age placeholder="Age of the Record (in years)" role=field style="font-family: monospace; font-size: 120%; text-indent: 1%" type=number value="0"/> </fieldset>

                    <!-- Description -->
                    <fieldset role=container> <label for=record-description role=label> Description </label> <textarea id=record-description name=record-description placeholder="Description of the Record's contents" role=field rows=0></textarea> </fieldset>
                </div>

                <!-- Prompters -->
                <div id=record-information-prompt role=container>
                    <!-- Message -->
                    <p role=message> Welcome </p>
                </div>

                <!-- Confirmers -->
                <div id=record-information-confirmation role=container>
                    <!-- ... -->
                    <input role="button reset" type=reset value="Clear"/>

                    <input role="add button" type=submit value="Add"/>
                    <input role="button remove" type=submit value="Delete"/>
                    <input role="button query" type=submit value="Search"/>
                    <input role="button update" type=submit value="Update"/>

                    <!-- Document Script -->
                    <script language=javascript type=text/javascript>
                        /* Main */
                        +(void function Main() {
                            /* Constant > ((Add, Query, Remove, Reset, Update) Button, ...) */
                            var addButton = document.querySelector("[role~=add]");
                            var queryButton = document.querySelector("[role~=query]");
                            var removeButton = document.querySelector("[role~=remove]");
                            var resetButton = document.querySelector("[role~=reset]");
                            var updateButton = document.querySelector("[role~=update]");

                            var promptMessageTextbox = document.querySelector("[role~=message]") || document.getElementsByTagName('p').item(0);
                            var promptMessageTypes = {"ERROR": 0, "INFORMATION": 1, "SUCCESS": 2, "WARNING": 3};

                            var recordActions = {"ADD": 0, "QUERY": 1, "REMOVE": 2, "UPDATE": 3};

                            /* Initialization > Record (Action, Information Form, Script URL, ... Field) */
                            var recordAction = null;
                            var recordAgeField = document.getElementById("record-age") || document.querySelector("[name=record-age]");
                            var recordDescriptionField = document.getElementById("record-description") || document.querySelector("[name=record-description]");
                            var recordInformationForm = document.getElementById("record-information") || document.getElementsByTagName("form").item(0) || document.querySelector("form[name=record-information]");
                            var recordNameField = document.getElementById("record-name") || document.querySelector("[name=record-name]");
                            var recordScriptURL = "";

                            /* Function */
                                // (Add, Query, Remove, Update) Record
                                function addRecord() { recordAction = recordActions["ADD"]; recordInformationForm.setAttribute("method", "POST"); recordScriptURL = "scripts/php/add-record.php" }
                                function queryRecord() { recordAction = recordActions["QUERY"]; recordInformationForm.setAttribute("method", "POST"); recordScriptURL = "scripts/php/query-record.php" }
                                function removeRecord() { recordAction = recordActions["REMOVE"]; recordInformationForm.setAttribute("method", "POST"); recordScriptURL = "scripts/php/remove-record.php" }
                                function updateRecord() { recordAction = recordActions["UPDATE"]; recordInformationForm.setAttribute("method", "POST"); recordScriptURL = "scripts/php/update-record.php" }

                                // Prompt Message
                                function promptMessage(content, messageType) {
                                    // Modification > Prompt Message Text Box > ...
                                    switch (arguments.length ? messageType : promptMessageTypes["INFORMATION"]) {
                                        case promptMessageTypes["ERROR"]: promptMessageTextbox.setAttribute("state", "error"); break;
                                        case promptMessageTypes["INFORMATION"]: promptMessageTextbox.setAttribute("state", "info"); break;
                                        case promptMessageTypes["SUCCESS"]: promptMessageTextbox.setAttribute("state", "success"); break;
                                        case promptMessageTypes["WARNING"]: promptMessageTextbox.setAttribute("state", "warn"); break;
                                    }

                                    promptMessageTextbox.innerText = ' ' + content.trim() + ' '
                                }

                                // (Reset, Submit) Record Information Form
                                function resetRecordInformationForm() { recordAction = null; recordInformationForm.removeAttribute("method"); recordScriptURL = ""; promptMessage("Cleared the form\u2026") }
                                function submitRecordInformationForm(event) {
                                    // Initialization > Record
                                    var record = {
                                        // [...]
                                        "age": Number.parseInt(recordAgeField.value),
                                        "description": recordDescriptionField.value.replace(/'/g, "\\'"),
                                        "name": recordNameField.value,

                                        // [Miscellaneous]
                                        "creation_date": (new Date).toString()
                                    };

                                    // {Exception Handling} ...
                                    Number.isNaN(record["age"]) && promptMessage("Invalid age specified");

                                    // Loop > Modification > Record
                                    for (var recordAttribute in record) { record["record-" + recordAttribute] = record[recordAttribute]; delete record[recordAttribute] }

                                    // ...
                                    event.preventDefault();
                                    event.stopPropagation();
                                    serve(recordInformationForm.getAttribute("method"), recordScriptURL, function(response, status) {
                                        // Logic
                                        if (status.value > 199 && status.value < 300) {
                                            // Constant > Source
                                            var source = response.text.trim();

                                            // Logic
                                            switch (recordAction) {
                                                // [Add [Record]]
                                                case recordActions["ADD"]: {
                                                    // Print
                                                    source ?
                                                        promptMessage("Unable to add record: \"" + source + "\"", promptMessageTypes["ERROR"]) :
                                                        promptMessage("Record successfully added", promptMessageTypes["SUCCESS"])
                                                } break;

                                                // [Query [Record]]
                                                case recordActions["QUERY"]: {
                                                    // Print
                                                    source ?
                                                        promptMessage("Unable to retrieve record: \"" + source + "\"", promptMessageTypes["ERROR"]) :
                                                        promptMessage("Record successfully retrieved", promptMessageTypes["SUCCESS"])

                                                    /* UPDATE (Lapys) -> Some code here... */
                                                } break;

                                                // [Remove [Record]]
                                                case recordActions["REMOVE"]: {
                                                    // Print
                                                    source ?
                                                        promptMessage("Unable to remove record: \"" + source + "\"", promptMessageTypes["ERROR"]) :
                                                        promptMessage("Record successfully removed", promptMessageTypes["SUCCESS"])
                                                } break;

                                                // [Update [Record]]
                                                case recordActions["UPDATE"]: {
                                                    // Print
                                                    source ?
                                                        promptMessage("Unable to update record: \"" + source + "\"", promptMessageTypes["ERROR"]) :
                                                        promptMessage("Record successfully updated", promptMessageTypes["SUCCESS"])
                                                } break;
                                            }
                                        }

                                        else
                                            // ...
                                            promptMessage("There seems to be an issue serving your request")
                                    }, record, {"async": true})
                                }

                            /* Event */
                                // (Add, Query, Remove, Reset, Update) Button
                                addButton.addEventListener("click", addButton.onclick = addRecord);
                                queryButton.addEventListener("click", queryButton.onclick = queryRecord);
                                removeButton.addEventListener("click", removeButton.onclick = removeRecord);
                                resetButton.addEventListener("click", resetButton.onclick = resetRecordInformationForm);
                                updateButton.addEventListener("click", updateButton.onclick = updateRecord);

                                /* Record Information Form > Submit */
                                recordInformationForm.addEventListener("submit", recordInformationForm.onsubmit = submitRecordInformationForm)
                        }());
                    </script>
                </div>
            </form>
        </main>
    </body>
</html>
