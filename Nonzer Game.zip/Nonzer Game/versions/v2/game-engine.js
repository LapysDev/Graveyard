/* Game --- WARN (Lapys) -> Assertion (or exception handling) is minimal due to JavaScript's design. */
; void function Game(GLOBAL) {
    /* [Utility] Class > ... --- REDACT (Lapys) --- NOTE (Lapys) -> Class syntax seem to suffer from an excessive `this.` syndrome.

        Function classes (functions used as classes) can subvert this using the `with` statement.
        So function classes may be used in some cases to avoid code redundancy.
    */
    class Context { // NOTE (Lapys) -> Provide access to an object through public interfaces. Used for derived classes to access the instance of their base class.
        static getContext() { return this.prototype.context }
        static Initiate(context) { Object.defineProperty(this.prototype, "context", {configurable: false, enumerable: false, value: context, writable: false}) }
    };

    class Enumerable extends Number { constructor(value) { super(Math.trunc(Number(value))) } }; // NOTE (Lapys) -> Integer values only.
    class Enumeration {
        constructor() { for (let length = arguments.length, index = BigInt(length > 16), iterator = length - 1; ~iterator; --iterator) this[arguments[iterator]] = (index ? (length > 16 ? ++index : index <<= 1n) : index = 1n) }
        of(constructor) { for (let enumerable in this) this[enumerable] = new constructor(this[enumerable]); return this } // NOTE (Lapys) -> Reconstructs all its enumerable values using a specified constructor.
    };

    function ImmutableObject(object) { if (this instanceof ImmutableObject) throw new TypeError("`ImmutableObject` is not a constructor"); else { for (let key in object) { if ("object" == typeof(object[key])) object[key] = ImmutableObject(object[key]) } ImmutableReference(object); return object } }
    function ImmutableReference(object) { if (this instanceof ImmutableReference) throw new TypeError("`ImmutableReference` is not a constructor"); else { Object.freeze(object); return object } }
    class List extends Array {
        add() { Array.prototype.push.apply(this, arguments) }

        get first() { return this.length ? this[0] : undefined }
        set first(value) { this.length && (this[0] = value); return undefined }
        foreach() { Array.prototype.forEach.apply(this, arguments) }
        get last() { return this.length ? this[this.length - 1] : undefined }
        set last(value) { this.length && (this[this.length - 1] = value); return value }
        remove() { for (let iterator = +0, length = arguments.length; iterator ^ length; ++iterator) { const index = this.indexOf(arguments[iterator]); ~index && this.splice(index, 1) } }
        removeLast() { for (let iterator = +0, length = arguments.length; iterator ^ length; ++iterator) { const index = this.lastIndexOf(arguments[iterator]); ~index && this.splice(index, 1) } }
    };

    /* Global */
        /* Game --- NOTE (Lapys) -> General, utility features. */
        const Game = new class Game {
            // Initialization > Pending Tasks
            #pendingTasks = 0n;
            get pendingTasks() { return this.#pendingTasks }

            /* Function */
                // ... Pend
                isPending() { return 0n == this.#pendingTasks }
                #pend() { return ++this.#pendingTasks }
                #unpend() { return 0n == (this.#pendingTasks ? --this.#pendingTasks : this.#pendingTasks) }

                // Preload --- NOTE (Lapys) -> Load up resources in the background processes.
                preload = ("undefined" == typeof(XMLHttpRequest) ?
                    function preload(url) {
                        // Constant > Request
                        const request = new Request(url, {cache: "force-cache", method: "GET", mode: "cors"});

                        // ...; Fetch
                        this.#pend();
                        fetch(request, {
                            cache: request.cache,
                            credentials: request.credentials,
                            headers: request.headers,
                            integrity: request.integrity,
                            keepalive: request.keepalive,
                            method: request.method,
                            mode: request.mode,
                            redirect: request.redirect,
                            referrer: request.referrer,
                            referrerPolicy: request.referrerPolicy,
                            signal: request.signal
                        }).then(this.#unpend)
                    } : function preload(url) {
                        // Constant > (..., Request)
                        let unpend = function unpend() { this.#unpend() };
                        const request = new XMLHttpRequest;

                        // ...; Event > Request > (Error, Load End, Timeout)
                        this.#pend();

                        request.addEventListener("error", function() { (null === unpend) || unpend(); unpend = null });
                        request.addEventListener("loadend", function() { (null === unpend) || unpend(); unpend = null });
                        request.addEventListener("timeout", function() { (null === unpend) || unpend(); unpend = null });

                        // Request > (Open, Send)
                        request.open("GET", url, true, null, null);
                        request.send(null)
                    }
                );

                // Tick
                tick = ("undefined" == typeof(requestAnimationFrame) ?
                    function tick(handler) { GLOBAL.setTimeout(handler, +0) } :
                    function tick(handler) { GLOBAL.requestAnimationFrame(handler) }
                );
        };

        /* Events --- WARN (Lapys) -> Event listeners shall not be revoked. */
        const Events = new class Events {
            constructor() { Events.#EventsObject.Initiate(this) }

            /* Class > Event ... --- REDACT (Lapys) */
            static Event = class Event {};
                static KeyEvent = class KeyEvent extends Events.Event {
                    static #Key = class Key extends Enumerable {
                        toString() { switch (this) {
                            case KeyEvent.#Keys.ADD: return '+';
                            case KeyEvent.#Keys.AMPERSAND: return '&';
                            case KeyEvent.#Keys.AT: return '@';
                            case KeyEvent.#Keys.BACKQUOTE: return '`';
                            case KeyEvent.#Keys.BACKSLASH: return '\\';
                            case KeyEvent.#Keys.BACKSPACE: return '\b';
                            case KeyEvent.#Keys.CARET: return '^';
                            case KeyEvent.#Keys.COLON: return ':';
                            case KeyEvent.#Keys.COMMA: return ',';
                            case KeyEvent.#Keys.DECIMAL: case KeyEvent.#Keys.PERIOD: return '.';
                            case KeyEvent.#Keys.DIGIT0: return '0';
                            case KeyEvent.#Keys.DIGIT1: return '1';
                            case KeyEvent.#Keys.DIGIT2: return '2';
                            case KeyEvent.#Keys.DIGIT3: return '3';
                            case KeyEvent.#Keys.DIGIT4: return '4';
                            case KeyEvent.#Keys.DIGIT5: return '5';
                            case KeyEvent.#Keys.DIGIT6: return '6';
                            case KeyEvent.#Keys.DIGIT7: return '7';
                            case KeyEvent.#Keys.DIGIT8: return '8';
                            case KeyEvent.#Keys.DIGIT9: return '9';
                            case KeyEvent.#Keys.DIVIDE: return '/';
                            case KeyEvent.#Keys.DOLLAR: return '$';
                            case KeyEvent.#Keys.DOUBLE_QUOTE: return '"';
                            case KeyEvent.#Keys.ENTER: return '\n';
                            case KeyEvent.#Keys.EQUAL: return '=';
                            case KeyEvent.#Keys.ESCAPE: return '\r';
                            case KeyEvent.#Keys.EXCLAMATION: return '!';
                            case KeyEvent.#Keys.GREATER_THAN: return '>';
                            case KeyEvent.#Keys.HASH: return '#';
                            case KeyEvent.#Keys.LEFT_BRACE: return '{';
                            case KeyEvent.#Keys.LEFT_BRACKET: return '[';
                            case KeyEvent.#Keys.LEFT_PARENTHESIS: return '(';
                            case KeyEvent.#Keys.LESSER_THAN: return '<';
                            case KeyEvent.#Keys.LOWERCASE_A: return 'a';
                            case KeyEvent.#Keys.LOWERCASE_B: return 'b';
                            case KeyEvent.#Keys.LOWERCASE_C: return 'c';
                            case KeyEvent.#Keys.LOWERCASE_D: return 'd';
                            case KeyEvent.#Keys.LOWERCASE_E: return 'e';
                            case KeyEvent.#Keys.LOWERCASE_F: return 'f';
                            case KeyEvent.#Keys.LOWERCASE_G: return 'g';
                            case KeyEvent.#Keys.LOWERCASE_H: return 'h';
                            case KeyEvent.#Keys.LOWERCASE_I: return 'i';
                            case KeyEvent.#Keys.LOWERCASE_J: return 'j';
                            case KeyEvent.#Keys.LOWERCASE_K: return 'k';
                            case KeyEvent.#Keys.LOWERCASE_L: return 'l';
                            case KeyEvent.#Keys.LOWERCASE_M: return 'm';
                            case KeyEvent.#Keys.LOWERCASE_N: return 'n';
                            case KeyEvent.#Keys.LOWERCASE_O: return 'o';
                            case KeyEvent.#Keys.LOWERCASE_P: return 'p';
                            case KeyEvent.#Keys.LOWERCASE_Q: return 'q';
                            case KeyEvent.#Keys.LOWERCASE_R: return 'r';
                            case KeyEvent.#Keys.LOWERCASE_S: return 's';
                            case KeyEvent.#Keys.LOWERCASE_T: return 't';
                            case KeyEvent.#Keys.LOWERCASE_U: return 'u';
                            case KeyEvent.#Keys.LOWERCASE_W: return 'w';
                            case KeyEvent.#Keys.LOWERCASE_X: return 'x';
                            case KeyEvent.#Keys.LOWERCASE_Y: return 'y';
                            case KeyEvent.#Keys.LOWERCASE_Z: return 'z';
                            case KeyEvent.#Keys.MULTIPLY: return '*';
                            case KeyEvent.#Keys.NUMBER_PAD0: return '0';
                            case KeyEvent.#Keys.NUMBER_PAD1: return '1';
                            case KeyEvent.#Keys.NUMBER_PAD2: return '2';
                            case KeyEvent.#Keys.NUMBER_PAD3: return '3';
                            case KeyEvent.#Keys.NUMBER_PAD4: return '4';
                            case KeyEvent.#Keys.NUMBER_PAD5: return '5';
                            case KeyEvent.#Keys.NUMBER_PAD6: return '6';
                            case KeyEvent.#Keys.NUMBER_PAD7: return '7';
                            case KeyEvent.#Keys.NUMBER_PAD8: return '8';
                            case KeyEvent.#Keys.NUMBER_PAD9: return '9';
                            case KeyEvent.#Keys.PERCENTAGE: return '%';
                            case KeyEvent.#Keys.QUESTION: return '?';
                            case KeyEvent.#Keys.QUOTE: return '\'';
                            case KeyEvent.#Keys.RIGHT_BRACE: return '}';
                            case KeyEvent.#Keys.RIGHT_BRACKET: return ']';
                            case KeyEvent.#Keys.RIGHT_PARENTHESIS: return ')';
                            case KeyEvent.#Keys.SEMICOLON: return ';';
                            case KeyEvent.#Keys.SINGLE_QUOTE: return '\'';
                            case KeyEvent.#Keys.SLASH: return '/';
                            case KeyEvent.#Keys.SPACEBAR: return ' ';
                            case KeyEvent.#Keys.SUBTRACT: return '-';
                            case KeyEvent.#Keys.TAB: return '\t';
                            case KeyEvent.#Keys.TILDE: return '`';
                            case KeyEvent.#Keys.UNDERSCORE: return '_';
                            case KeyEvent.#Keys.UPPERCASE_A: return 'A';
                            case KeyEvent.#Keys.UPPERCASE_B: return 'B';
                            case KeyEvent.#Keys.UPPERCASE_C: return 'C';
                            case KeyEvent.#Keys.UPPERCASE_D: return 'D';
                            case KeyEvent.#Keys.UPPERCASE_E: return 'E';
                            case KeyEvent.#Keys.UPPERCASE_F: return 'F';
                            case KeyEvent.#Keys.UPPERCASE_G: return 'G';
                            case KeyEvent.#Keys.UPPERCASE_H: return 'H';
                            case KeyEvent.#Keys.UPPERCASE_I: return 'I';
                            case KeyEvent.#Keys.UPPERCASE_J: return 'J';
                            case KeyEvent.#Keys.UPPERCASE_K: return 'K';
                            case KeyEvent.#Keys.UPPERCASE_L: return 'L';
                            case KeyEvent.#Keys.UPPERCASE_M: return 'M';
                            case KeyEvent.#Keys.UPPERCASE_N: return 'N';
                            case KeyEvent.#Keys.UPPERCASE_O: return 'O';
                            case KeyEvent.#Keys.UPPERCASE_P: return 'P';
                            case KeyEvent.#Keys.UPPERCASE_Q: return 'Q';
                            case KeyEvent.#Keys.UPPERCASE_R: return 'R';
                            case KeyEvent.#Keys.UPPERCASE_S: return 'S';
                            case KeyEvent.#Keys.UPPERCASE_T: return 'T';
                            case KeyEvent.#Keys.UPPERCASE_U: return 'U';
                            case KeyEvent.#Keys.UPPERCASE_W: return 'W';
                            case KeyEvent.#Keys.UPPERCASE_X: return 'X';
                            case KeyEvent.#Keys.UPPERCASE_Y: return 'Y';
                            case KeyEvent.#Keys.UPPERCASE_Z: return 'Z';
                            case KeyEvent.#Keys.VERTICAL_BAR: return '|';
                            default: return ""
                        } }
                    };
                    static #Keys = ImmutableReference(new class KeyEnumeration extends Enumeration {}(
                        // [Application Selector]
                        "LAUNCH_CALCULATOR", "LAUNCH_CALENDER", "LAUNCH_CONTACTS",
                        "LAUNCH_MAIL", "LAUNCH_MEDIA_PLAYER", "LAUNCH_MUSIC_PLAYER", "LAUNCH_MY_COMPUTER",
                        "LAUNCH_PHONE",
                        "LAUNCH_SCREEN_SAVER", "LAUNCH_SPREADSHEET",
                        "LAUNCH_WEB_BROWSER", "LAUNCH_WEB_CAMERA", "LAUNCH_WORD_PROCESSOR",
                        "LAUNCH_APPLICATION1", "LAUNCH_APPLICATION2", "LAUNCH_APPLICATION3", "LAUNCH_APPLICATION4", "LAUNCH_APPLICATION5", "LAUNCH_APPLICATION6", "LAUNCH_APPLICATION7", "LAUNCH_APPLICATION8", "LAUNCH_APPLICATION9", "LAUNCH_APPLICATION10", "LAUNCH_APPLICATION11", "LAUNCH_APPLICATION12", "LAUNCH_APPLICATION13", "LAUNCH_APPLICATION14", "LAUNCH_APPLICATION15", "LAUNCH_APPLICATION16",

                        // [Audio Control]
                        "AUDIO_BALANCE_LEFT", "AUDIO_BALANCE_RIGHT",
                        "AUDIO_BASS_DOWN", "AUDIO_BASS_BOOST_DOWN", "AUDIO_BASS_BOOST_TOGGLE", "AUDIO_BASS_BOOST_UP", "AUDIO_BASS_UP",
                        "AUDIO_FADER_FRONT", "AUDIO_FADER_REAR",
                        "AUDIO_SURROUND_MODE_NEXT",
                        "AUDIO_TREBLE_DOWN", "AUDIO_TREBLE_UP",
                        "AUDIO_VOLUME_DOWN", "AUDIO_VOLUME_MUTE", "AUDIO_VOLUME_UP",
                        "MICROPHONE_TOGGLE",
                        "MICROPHONE_VOLUME_DOWN", "MICROPHONE_VOLUME_MUTE", "MICROPHONE_VOLUME_UP",

                        // [Browser Control]
                        "BROWSER_BACK",
                        "BROWSER_FAVORITES", "BROWSER_FORWARD",
                        "BROWSER_HOME", "BROWSER_REFRESH",
                        "BROWSER_SEARCH", "BROWSER_STOP",

                        // [Composition & Input Method Editing]
                        "ALL_CANDIDATES", "ALPHANUMERIC",
                        "CODE_INPUT", "COMPOSE", "CONVERT",
                        "DEAD", "EISU", "FINAL_MODE",
                        "GROUP_FIRST", "GROUP_LAST", "GROUP_NEXT", "GROUP_PREVIOUS",
                        "HANGUL_MODE", "HANKAKU", "HANJA_MODE", "HIRAGANA", "HIRAGANA_KATAKANA",
                        "JUNJA_MODE",
                        "KANA_MODE", "KANJI_MODE", "KATAKANA",
                        "MODE_CHANGE",
                        "NEXT_CANDIDATE", "NON_CONVERT",
                        "PREVIOUS_CANDIDATE", "PROCESS",
                        "ROMAJI", "SINGLE_CANDIDATE",
                        "ZENKAKU", "ZENKAKU_HANAKU",

                        // [Control]
                        "ALT_GRAPH", "CAPS_LOCK",
                        "FUNCTION", "FUNCTION_LOCK",
                        "HYPER",
                        "LEFT_ALT", "LEFT_CONTROL", "LEFT_SHIFT",
                        "META", "NUMBER_LOCK",
                        "RIGHT_ALT", "RIGHT_CONTROL", "RIGHT_SHIFT",
                        "SCROLL_LOCK", "SUPER", "SYMBOL", "SYMBOL_LOCK",

                        // [Device]
                        "BRIGHTNESS_DOWN", "BRIGHTNESS_UP",
                        "EJECT", "HIBERNATE", "LOG_OFF",
                        "POWER", "POWER_OFF", "PRINT_SCREEN",
                        "STANDBY", "WAKE_UP",

                        // [Document]
                        "CLOSE",
                        "MAIL_FORWARD", "MAIL_REPLY", "MAIL_SEND",
                        "NEW", "OPEN", "PRINT",
                        "SAVE", "SPELL_CHECK",

                        // [Edit]
                        "BACKSPACE",
                        "CLEAR", "COPY", "CURSOR_SELECT", "CUT",
                        "DELETE",
                        "ERASE_END_OF_FIELD", "EXTEND_SELECT",
                        "INSERT", "PASTE", "REDO", "UNDO",

                        // [Function]
                        "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24",
                        "SOFT1", "SOFT2", "SOFT3", "SOFT4",

                        // [Media Controller]
                        "AVR_INPUT", "AVR_POWER",
                        "COLOR_F0_RED", "COLOR_F1_GREEN", "COLOR_F2_YELLOW", "COLOR_F3_BLUE", "COLOR_F4_GRAY", "COLOR_F5_BROWN",
                        "CLOSED_CAPTION_TOGGLE", "DIMMER", "DISPLAY_SWAP", "DVR", "EXIT",
                        "FAVORITE_CLEAR0", "FAVORITE_CLEAR1", "FAVORITE_CLEAR2", "FAVORITE_CLEAR3",
                        "FAVORITE_RECALL0", "FAVORITE_RECALL1", "FAVORITE_RECALL2", "FAVORITE_RECALL3",
                        "FAVORITE_STORE0", "FAVORITE_STORE1", "FAVORITE_STORE2", "FAVORITE_STORE3",
                        "GUIDE", "GUIDE_NEXT_DAY", "GUIDE_PREVIOUS_DAY",
                        "INFORMATION", "INSTANT_REPLAY",
                        "LINK", "LIST_PROGRAM", "LIVE_CONTENT", "LOCK",
                        "MEDIA_APPLICATIONS", "MEDIA_AUDIO_TRACK",
                        "MEDIA_LAST",
                        "MEDIA_SKIP_BACKWARD", "MEDIA_SKIP_FORWARD",
                        "MEDIA_STEP_BACKWARD", "MEDIA_STEP_FORWARD",
                        "MEDIA_TOP_MENU",
                        "NAVIGATE_IN", "NAVIGATE_NEXT", "NAVIGATE_OUT", "NAVIGATE_PREVIOUS",
                        "NEXT_FAVORITE_CHANNEL", "NEXT_USER_PROFILE",
                        "ON_DEMAND", "PAIRING",
                        "PIN_P_DOWN", "PIN_P_MOVE", "PIN_P_TOGGLE", "PIN_P_UP",
                        "PLAY_SPEED_DOWN", "PLAY_SPEED_RESET", "PLAY_SPEED_UP",
                        "RANDOM_TOGGLE", "RECORD_SPEED_NEXT", "REMOTE_CONTROL_LOW_BATTERY", "RADIO_FREQUENCY_BYPASS",
                        "SCAN_CHANNELS_TOGGLE", "SCREEN_MODE_NEXT", "SETTINGS", "SPLIT_SCREEN_TOGGLE",
                        "SET_TOP_BOX_INPUT", "SET_TOP_BOX_POWER",
                        "SUBTITLE", "TELETEXT", "VIDEO_MODE_NEXT", "WINK", "ZOOM_TOGGLE",

                        // [Multimedia Keys]
                        "CHANNEL_DOWN", "CHANNEL_UP",
                        "MEDIA_FAST_FORWARD", "MEDIA_PAUSE", "MEDIA_PLAY", "MEDIA_PLAY_PAUSE", "MEDIA_RECORD", "MEDIA_REWIND", "MEDIA_STOP", "MEDIA_TRACK_NEXT", "MEDIA_TRACK_PREVIOUS",

                        // [Navigation]
                        "ARROW_DOWN", "ARROW_LEFT", "ARROW_RIGHT", "ARROW_UP",
                        "END", "HOME",
                        "PAGE_DOWN", "PAGE_UP",

                        // [Numeric]
                        "ADD", "CLEAR",
                        "DECIMAL", "DIVIDE", "EQUAL",
                        "KEY11", "KEY12",
                        "MULTIPLY",
                        "NUMBER_PAD0", "NUMBER_PAD1", "NUMBER_PAD2", "NUMBER_PAD3", "NUMBER_PAD4", "NUMBER_PAD5", "NUMBER_PAD6", "NUMBER_PAD7", "NUMBER_PAD8", "NUMBER_PAD9",
                        "SEPARATOR", "SUBTRACT",

                        // [Phone]
                        "APP_SWITCH",
                        "CALL", "CAMERA", "CAMERA_FOCUS",
                        "END_CALL",
                        "GO_BACK", "GO_HOME",
                        "HEADSET_HOOK", "LAST_NUMBER_REDIAL", "NOTIFICATION", "MANNER_MODE", "VOICE_DIAL",

                        // [Special]
                        "UNIDENTIFIED",

                        // [Speech Recognition]
                        "SPEECH_CORRECTION_LIST", "SPEECH_INPUT_TOGGLE",

                        // [TV Control]
                        "TV", "TV_3D_MODE",
                        "TV_ANTENNA_CABLE",
                        "TV_AUDIO_DESCRIPTION", "TV_AUDIO_DESCRIPTION_MIX_DOWN", "TV_AUDIO_DESCRIPTION_MIX_UP",
                        "TV_CONTENTS_MENU", "TV_DATA_SERVICE",
                        "TV_INPUT",
                        "TV_INPUT_COMPONENT1", "TV_INPUT_COMPONENT2", "TV_INPUT_COMPOSITE1", "TV_INPUT_COMPOSITE2",
                        "TV_INPUT_HDMI1", "TV_INPUT_HDMI2", "TV_INPUT_HDMI3", "TV_INPUT_HDMI4",
                        "TV_INPUT_VGA1", "TV_MEDIA_CONTEXT", "TV_NETWORK", "TV_NUMBER_ENTRY", "TV_POWER", "TV_RADIO_SERVICE",
                        "TV_SATELLITE", "TV_SATELLITE_BROADCAST", "TV_SATELLITE_COMMUNICATION", "TV_SATELLITE_TOGGLE",
                        "TV_TERRESTRIAL_ANALOG", "TV_TERRESTRIAL_DIGITAL",
                        "TV_TIMER",

                        // [User Interface]
                        "ACCEPT", "AGAIN", "ATTENTION",
                        "CANCEL", "CONTEXT_MENU",
                        "ESCAPE", "EXECUTE",
                        "FIND", "FINISH",
                        "HELP",
                        "PAUSE", "PLAY", "PROPERTIES",
                        "SELECT",
                        "ZOOM_IN", "ZOOM_OUT",

                        // [Whitespace]
                        "ENTER", "SPACEBAR", "TAB",

                        // [...]
                        "AMPERSAND", "AT",
                        "BACKSLASH", "BACKQUOTE",
                        "CARET", "COLON", "COMMA",
                        "DIGIT0", "DIGIT1", "DIGIT2", "DIGIT3", "DIGIT4", "DIGIT5", "DIGIT6", "DIGIT7", "DIGIT8", "DIGIT9",
                        "DOLLAR",
                        "EJECT", "EXCLAMATION",
                        "GREATER_THAN", "HASH",
                        "LEFT_BRACE", "LEFT_BRACKET", "LEFT_PARENTHESIS",
                        "LESSER_THAN",
                        "LOWERCASE_A", "LOWERCASE_B", "LOWERCASE_C", "LOWERCASE_D", "LOWERCASE_E", "LOWERCASE_F", "LOWERCASE_G", "LOWERCASE_H", "LOWERCASE_I", "LOWERCASE_J", "LOWERCASE_K", "LOWERCASE_L", "LOWERCASE_M", "LOWERCASE_N", "LOWERCASE_O", "LOWERCASE_P", "LOWERCASE_Q", "LOWERCASE_R", "LOWERCASE_S", "LOWERCASE_T", "LOWERCASE_U", "LOWERCASE_W", "LOWERCASE_X", "LOWERCASE_Y", "LOWERCASE_Z",
                        "PERCENTAGE", "PERIOD",
                        "QUESTION", "QUOTE",
                        "RIGHT_BRACE", "RIGHT_BRACKET", "RIGHT_PARENTHESIS",
                        "SEMICOLON", "SLASH",
                        "TILDE", "UNDERSCORE",
                        "UPPERCASE_A", "UPPERCASE_B", "UPPERCASE_C", "UPPERCASE_D", "UPPERCASE_E", "UPPERCASE_F", "UPPERCASE_G", "UPPERCASE_H", "UPPERCASE_I", "UPPERCASE_J", "UPPERCASE_K", "UPPERCASE_L", "UPPERCASE_M", "UPPERCASE_N", "UPPERCASE_O", "UPPERCASE_P", "UPPERCASE_Q", "UPPERCASE_R", "UPPERCASE_S", "UPPERCASE_T", "UPPERCASE_U", "UPPERCASE_W", "UPPERCASE_X", "UPPERCASE_Y", "UPPERCASE_Z",
                        "VERTICAL_BAR"
                    ).of(KeyEvent.#Key));

                    key = new KeyEvent.#Key;

                    static getAssociatedKey(event) {
                        switch (event.code) {
                            case "AltLeft": return KeyEvent.#Keys.LEFT_ALT;
                            case "AltRight": return KeyEvent.#Keys.RIGHT_ALT;
                            case "Backquote": return KeyEvent.#Keys.BACKQUOTE;
                            case "Comma": return KeyEvent.#Keys.COMMA;
                            case "ControlLeft": return KeyEvent.#Keys.LEFT_CONTROL;
                            case "ControlRight": return KeyEvent.#Keys.RIGHT_CONTROL;
                            case "Eject": return KeyEvent.#Keys.EJECT;
                            case "Period": return KeyEvent.#Keys.PERIOD;
                            case "Quote": return KeyEvent.#Keys.Quote;
                            case "Semicolon": return KeyEvent.#Keys.SEMICOLON;
                            case "ShiftLeft": return KeyEvent.#Keys.LEFT_SHIFT;
                            case "ShiftRight": return KeyEvent.#Keys.RIGHT_SHIFT;
                            case "Slash": return KeyEvent.#Keys.SLASH;
                        }

                        switch (event.key) {
                            case '~': return KeyEvent.#Keys.TILDE;
                            case '!': return KeyEvent.#Keys.EXCLAMATION;
                            case '@': return KeyEvent.#Keys.AT;
                            case '#': return KeyEvent.#Keys.HASH;
                            case '$': return KeyEvent.#Keys.DOLLAR;
                            case '%': return KeyEvent.#Keys.PERCENTAGE;
                            case '^': return KeyEvent.#Keys.CARET;
                            case '&': return KeyEvent.#Keys.AMPERSAND;
                            case '_': return KeyEvent.#Keys.UNDERSCORE;
                            case '|': return KeyEvent.#Keys.VERTICAL_BAR;
                            case ':': return KeyEvent.#Keys.COLON;
                            case '<': return KeyEvent.#Keys.LESSER_THAN;
                            case '>': return KeyEvent.#Keys.GREATER_THAN;
                            case '?': return KeyEvent.#Keys.QUESTION;
                            case ',': return KeyEvent.#Keys.COMMA;
                            case '\\': return KeyEvent.#Keys.BACKSLASH;

                            case '{': return KeyEvent.#Keys.LEFT_BRACE;
                            case '[': return KeyEvent.#Keys.LEFT_BRACKET;
                            case '(': return KeyEvent.#Keys.LEFT_PARENTHESIS;
                            case '}': return KeyEvent.#Keys.RIGHT_BRACE;
                            case ']': return KeyEvent.#Keys.RIGHT_BRACKET;
                            case ')': return KeyEvent.#Keys.RIGHT_PARENTHESIS;
                            case ' ': return KeyEvent.#Keys.SPACEBAR;

                            case "AVRInput": return KeyEvent.#Keys.AVR_INPUT;
                            case "AVRPower": return KeyEvent.#Keys.AVR_POWER;
                            case "Accept": return KeyEvent.#Keys.ACCEPT;
                            case "Add": return KeyEvent.#Keys.ADD;
                            case "Again": return KeyEvent.#Keys.AGAIN;
                            case "AllCandidates": return KeyEvent.#Keys.ALL_CANDIDATES;
                            case "Alphanumeric": return KeyEvent.#Keys.ALPHANUMERIC;
                            case "AltGraph": return KeyEvent.#Keys.ALT_GRAPH;
                            case "AppSwitch": return KeyEvent.#Keys.APP_SWITCH;
                            case "ArrowDown": return KeyEvent.#Keys.ARROW_DOWN;
                            case "ArrowLeft": return KeyEvent.#Keys.ARROW_LEFT;
                            case "ArrowRight": return KeyEvent.#Keys.ARROW_RIGHT;
                            case "ArrowUp": return KeyEvent.#Keys.ARROW_UP;
                            case "Attn": return KeyEvent.#Keys.ATTENTION;
                            case "AudioBalanceLeft": return KeyEvent.#Keys.AUDIO_BALANCE_LEFT;
                            case "AudioBalanceRight": return KeyEvent.#Keys.AUDIO_BALANCE_RIGHT;
                            case "AudioBassBoostDown": return KeyEvent.#Keys.AUDIO_BASS_BOOST_DOWN;
                            case "AudioBassBoostToggle": return KeyEvent.#Keys.AUDIO_BASS_BOOST_TOGGLE;
                            case "AudioBassBoostUp": return KeyEvent.#Keys.AUDIO_BASS_BOOST_UP;
                            case "AudioBassDown": return KeyEvent.#Keys.AUDIO_BASS_DOWN;
                            case "AudioBassUp": return KeyEvent.#Keys.AUDIO_BASS_UP;
                            case "AudioFaderFront": return KeyEvent.#Keys.AUDIO_FADER_FRONT;
                            case "AudioFaderRear": return KeyEvent.#Keys.AUDIO_FADER_REAR;
                            case "AudioSurroundModeNext": return KeyEvent.#Keys.AUDIO_SURROUND_MODE_NEXT;
                            case "AudioTrebleDown": return KeyEvent.#Keys.AUDIO_TREBLE_DOWN;
                            case "AudioTrebleUp": return KeyEvent.#Keys.AUDIO_TREBLE_UP;
                            case "AudioVolumeDown": return KeyEvent.#Keys.AUDIO_VOLUME_DOWN;
                            case "AudioVolumeMute": return KeyEvent.#Keys.AUDIO_VOLUME_MUTE;
                            case "AudioVolumeUp": return KeyEvent.#Keys.AUDIO_VOLUME_UP;
                            case "Backspace": return KeyEvent.#Keys.BACKSPACE;
                            case "BrightnessDown": return KeyEvent.#Keys.BRIGHTNESS_DOWN;
                            case "BrightnessUp": return KeyEvent.#Keys.BRIGHTNESS_UP;
                            case "BrowserBack": return KeyEvent.#Keys.BROWSER_BACK;
                            case "BrowserFavorites": return KeyEvent.#Keys.BROWSER_FAVORITES;
                            case "BrowserForward": return KeyEvent.#Keys.BROWSER_FORWARD;
                            case "BrowserHome": return KeyEvent.#Keys.BROWSER_HOME;
                            case "BrowserRefresh": return KeyEvent.#Keys.BROWSER_REFRESH;
                            case "BrowserSearch": return KeyEvent.#Keys.BROWSER_SEARCH;
                            case "BrowserStop": return KeyEvent.#Keys.BROWSER_STOP;
                            case "Call": return KeyEvent.#Keys.CALL;
                            case "Camera": return KeyEvent.#Keys.CAMERA;
                            case "CameraFocus": return KeyEvent.#Keys.CAMERA_FOCUS;
                            case "Cancel": return KeyEvent.#Keys.CANCEL;
                            case "CapsLock": return KeyEvent.#Keys.CAPS_LOCK;
                            case "ChannelDown": return KeyEvent.#Keys.CHANNEL_DOWN;
                            case "ChannelUp": return KeyEvent.#Keys.CHANNEL_UP;
                            case "Clear": return KeyEvent.#Keys.CLEAR;
                            case "Clear": return KeyEvent.#Keys.CLEAR;
                            case "Close": return KeyEvent.#Keys.CLOSE;
                            case "ClosedCaptionToggle": return KeyEvent.#Keys.COLOR_F5_BROWN;
                            case "CodeInput": return KeyEvent.#Keys.CODE_INPUT;
                            case "ColorF0Red": return KeyEvent.#Keys.COLOR_F0_RED;
                            case "ColorF1Green": return KeyEvent.#Keys.COLOR_F1_GREEN;
                            case "ColorF2Yellow": return KeyEvent.#Keys.COLOR_F2_YELLOW;
                            case "ColorF3Blue": return KeyEvent.#Keys.COLOR_F3_BLUE;
                            case "ColorF4Grey": return KeyEvent.#Keys.COLOR_F4_GRAY;
                            case "ColorF5Brown": return KeyEvent.#Keys.COLOR_F5_BROWN;
                            case "Compose": return KeyEvent.#Keys.COMPOSE;
                            case "ContextMenu": return KeyEvent.#Keys.CONTEXT_MENU;
                            case "Convert": return KeyEvent.#Keys.CONVERT;
                            case "Copy": return KeyEvent.#Keys.COPY;
                            case "CrSel": return KeyEvent.#Keys.CURSOR_SELECT;
                            case "Cut": return KeyEvent.#Keys.CUT;
                            case "DVR": return KeyEvent.#Keys.DVR;
                            case "Dead": return KeyEvent.#Keys.DEAD;
                            case "Decimal": return KeyEvent.#Keys.DECIMAL;
                            case "Delete": return KeyEvent.#Keys.DELETE;
                            case "Dimmer": return KeyEvent.#Keys.DIMMER;
                            case "DisplaySwap": return KeyEvent.#Keys.DISPLAY_SWAP;
                            case "Divide": return KeyEvent.#Keys.DIVIDE;
                            case "Eisu": return KeyEvent.#Keys.EISU;
                            case "Eject": return KeyEvent.#Keys.EJECT;
                            case "End": return KeyEvent.#Keys.END;
                            case "EndCall": return KeyEvent.#Keys.END_CALL;
                            case "Enter": return KeyEvent.#Keys.ENTER;
                            case "EraseEof": return KeyEvent.#Keys.ERASE_END_OF_FIELD;
                            case "Escape": return KeyEvent.#Keys.ESCAPE;
                            case "ExSel": return KeyEvent.#Keys.EXTEND_SELECT;
                            case "Execute": return KeyEvent.#Keys.EXECUTE;
                            case "Exit": return KeyEvent.#Keys.EXIT;
                            case "F1": return KeyEvent.#Keys.F1;
                            case "F2": return KeyEvent.#Keys.F2;
                            case "F3": return KeyEvent.#Keys.F3;
                            case "F4": return KeyEvent.#Keys.F4;
                            case "F5": return KeyEvent.#Keys.F5;
                            case "F6": return KeyEvent.#Keys.F6;
                            case "F7": return KeyEvent.#Keys.F7;
                            case "F8": return KeyEvent.#Keys.F8;
                            case "F9": return KeyEvent.#Keys.F9;
                            case "F10": return KeyEvent.#Keys.F10;
                            case "F11": return KeyEvent.#Keys.F11;
                            case "F12": return KeyEvent.#Keys.F12;
                            case "F13": return KeyEvent.#Keys.F13;
                            case "F14": return KeyEvent.#Keys.F14;
                            case "F15": return KeyEvent.#Keys.F15;
                            case "F16": return KeyEvent.#Keys.F16;
                            case "F17": return KeyEvent.#Keys.F17;
                            case "F18": return KeyEvent.#Keys.F18;
                            case "F19": return KeyEvent.#Keys.F19;
                            case "F20": return KeyEvent.#Keys.F20;
                            case "F21": return KeyEvent.#Keys.F21;
                            case "F22": return KeyEvent.#Keys.F22;
                            case "F23": return KeyEvent.#Keys.F23;
                            case "F24": return KeyEvent.#Keys.F24;
                            case "FavoriteClear0": return KeyEvent.#Keys.FAVORITE_CLEAR0;
                            case "FavoriteClear1": return KeyEvent.#Keys.FAVORITE_CLEAR1;
                            case "FavoriteClear2": return KeyEvent.#Keys.FAVORITE_CLEAR2;
                            case "FavoriteClear3": return KeyEvent.#Keys.FAVORITE_CLEAR3;
                            case "FavoriteRecall0": return KeyEvent.#Keys.FAVORITE_RECALL0;
                            case "FavoriteRecall1": return KeyEvent.#Keys.FAVORITE_RECALL1;
                            case "FavoriteRecall2": return KeyEvent.#Keys.FAVORITE_RECALL2;
                            case "FavoriteRecall3": return KeyEvent.#Keys.FAVORITE_RECALL3;
                            case "FavoriteStore0": return KeyEvent.#Keys.FAVORITE_STORE0;
                            case "FavoriteStore1": return KeyEvent.#Keys.FAVORITE_STORE1;
                            case "FavoriteStore2": return KeyEvent.#Keys.FAVORITE_STORE2;
                            case "FavoriteStore3": return KeyEvent.#Keys.FAVORITE_STORE3;
                            case "FinalMode": return KeyEvent.#Keys.FINAL_MODE;
                            case "Find": return KeyEvent.#Keys.FIND;
                            case "Finish": return KeyEvent.#Keys.FINISH;
                            case "Fn": return KeyEvent.#Keys.FUNCTION;
                            case "FnLock": return KeyEvent.#Keys.FUNCTION_LOCK;
                            case "GoBack": return KeyEvent.#Keys.GO_BACK;
                            case "GoHome": return KeyEvent.#Keys.GO_HOME;
                            case "GroupFirst": return KeyEvent.#Keys.GROUP_FIRST;
                            case "GroupLast": return KeyEvent.#Keys.GROUP_LAST;
                            case "GroupNext": return KeyEvent.#Keys.GROUP_NEXT;
                            case "GroupPrevious": return KeyEvent.#Keys.GROUP_PREVIOUS;
                            case "Guide": return KeyEvent.#Keys.GUIDE;
                            case "GuideNextDay": return KeyEvent.#Keys.GUIDE_NEXT_DAY;
                            case "GuidePreviousDay": return KeyEvent.#Keys.GUIDE_PREVIOUS_DAY;
                            case "HangulMode": return KeyEvent.#Keys.HANGUL_MODE;
                            case "HanjaMode": return KeyEvent.#Keys.HANJA_MODE;
                            case "Hankaku": return KeyEvent.#Keys.HANKAKU;
                            case "HeadsetHook": return KeyEvent.#Keys.HEADSET_HOOK;
                            case "Help": return KeyEvent.#Keys.HELP;
                            case "Hibernate": return KeyEvent.#Keys.HIBERNATE;
                            case "Hiragana": return KeyEvent.#Keys.HIRAGANA;
                            case "HiraganaKatakana": return KeyEvent.#Keys.HIRAGANA_KATAKANA;
                            case "Home": return KeyEvent.#Keys.HOME;
                            case "Hyper": return KeyEvent.#Keys.HYPER;
                            case "Info": return KeyEvent.#Keys.INFORMATION;
                            case "Insert": return KeyEvent.#Keys.INSERT;
                            case "InstantReplay": return KeyEvent.#Keys.INSTANT_REPLAY;
                            case "JunjaMode": return KeyEvent.#Keys.JUNJA_MODE;
                            case "KanaMode": return KeyEvent.#Keys.KANA_MODE;
                            case "KanjiMode": return KeyEvent.#Keys.KANJI_MODE;
                            case "Katakana": return KeyEvent.#Keys.KATAKANA;
                            case "Key11": return KeyEvent.#Keys.KEY11;
                            case "Key12": return KeyEvent.#Keys.KEY12;
                            case "LastNumberRedial": return KeyEvent.#Keys.LAST_NUMBER_REDIAL;
                            case "LaunchApplication1": return KeyEvent.#Keys.LAUNCH_APPLICATION1;
                            case "LaunchApplication10": return KeyEvent.#Keys.LAUNCH_APPLICATION10;
                            case "LaunchApplication11": return KeyEvent.#Keys.LAUNCH_APPLICATION11;
                            case "LaunchApplication12": return KeyEvent.#Keys.LAUNCH_APPLICATION12;
                            case "LaunchApplication13": return KeyEvent.#Keys.LAUNCH_APPLICATION13;
                            case "LaunchApplication14": return KeyEvent.#Keys.LAUNCH_APPLICATION14;
                            case "LaunchApplication15": return KeyEvent.#Keys.LAUNCH_APPLICATION15;
                            case "LaunchApplication16": return KeyEvent.#Keys.LAUNCH_APPLICATION16;
                            case "LaunchApplication2": return KeyEvent.#Keys.LAUNCH_APPLICATION2;
                            case "LaunchApplication3": return KeyEvent.#Keys.LAUNCH_APPLICATION3;
                            case "LaunchApplication4": return KeyEvent.#Keys.LAUNCH_APPLICATION4;
                            case "LaunchApplication5": return KeyEvent.#Keys.LAUNCH_APPLICATION5;
                            case "LaunchApplication6": return KeyEvent.#Keys.LAUNCH_APPLICATION6;
                            case "LaunchApplication7": return KeyEvent.#Keys.LAUNCH_APPLICATION7;
                            case "LaunchApplication8": return KeyEvent.#Keys.LAUNCH_APPLICATION8;
                            case "LaunchApplication9": return KeyEvent.#Keys.LAUNCH_APPLICATION9;
                            case "LaunchCalculator": return KeyEvent.#Keys.LAUNCH_CALCULATOR;
                            case "LaunchContacts": return KeyEvent.#Keys.LAUNCH_CONTACTS;
                            case "LaunchMail": return KeyEvent.#Keys.LAUNCH_MAIL;
                            case "LaunchMediaPlayer": return KeyEvent.#Keys.LAUNCH_MEDIA_PLAYER;
                            case "LaunchMusicPlayer": return KeyEvent.#Keys.LAUNCH_MUSIC_PLAYER;
                            case "LaunchMyComputer": return KeyEvent.#Keys.LAUNCH_MY_COMPUTER;
                            case "LaunchPhone": return KeyEvent.#Keys.LAUNCH_PHONE;
                            case "LaunchScreenSaver": return KeyEvent.#Keys.LAUNCH_SCREEN_SAVER;
                            case "LaunchSpreadsheet": return KeyEvent.#Keys.LAUNCH_SPREADSHEET;
                            case "LaunchWebBrowser": return KeyEvent.#Keys.LAUNCH_WEB_BROWSER;
                            case "LaunchWebCam": return KeyEvent.#Keys.LAUNCH_WEB_CAMERA;
                            case "LaunchWordProcessor": return KeyEvent.#Keys.LAUNCH_WORD_PROCESSOR;
                            case "Link": return KeyEvent.#Keys.LINK;
                            case "ListProgram": return KeyEvent.#Keys.LIST_PROGRAM;
                            case "LiveContent": return KeyEvent.#Keys.LIVE_CONTENT;
                            case "Lock": return KeyEvent.#Keys.LOCK;
                            case "LogOff": return KeyEvent.#Keys.LOG_OFF;
                            case "MailForward": return KeyEvent.#Keys.MAIL_FORWARD;
                            case "MailReply": return KeyEvent.#Keys.MAIL_REPLY;
                            case "MailSend": return KeyEvent.#Keys.MAIL_SEND;
                            case "MannerMode": return KeyEvent.#Keys.MANNER_MODE;
                            case "MediaApps": return KeyEvent.#Keys.MEDIA_APPLICATIONS;
                            case "MediaAudioTrack": return KeyEvent.#Keys.MEDIA_AUDIO_TRACK;
                            case "MediaFastForward": return KeyEvent.#Keys.MEDIA_FAST_FORWARD;
                            case "MediaLast": return KeyEvent.#Keys.MEDIA_LAST;
                            case "MediaPlay": return KeyEvent.#Keys.MEDIA_PLAY;
                            case "MediaPlayPause": return KeyEvent.#Keys.MEDIA_PLAY_PAUSE;
                            case "MediaRecord": return KeyEvent.#Keys.MEDIA_RECORD;
                            case "MediaRewind": return KeyEvent.#Keys.MEDIA_REWIND;
                            case "MediaSkipBackward": return KeyEvent.#Keys.MEDIA_SKIP_BACKWARD;
                            case "MediaSkipForward": return KeyEvent.#Keys.MEDIA_SKIP_FORWARD;
                            case "MediaStepBackward": return KeyEvent.#Keys.MEDIA_STEP_BACKWARD;
                            case "MediaStepForward": return KeyEvent.#Keys.MEDIA_STEP_FORWARD;
                            case "MediaStop": return KeyEvent.#Keys.MEDIA_STOP;
                            case "MediaTopMenu": return KeyEvent.#Keys.MEDIA_TOP_MENU;
                            case "MediaTrackNext": return KeyEvent.#Keys.MEDIA_TRACK_NEXT;
                            case "MediaTrackPrevious": return KeyEvent.#Keys.MEDIA_TRACK_PREVIOUS;
                            case "Meta": return KeyEvent.#Keys.META;
                            case "MicrophoneToggle": return KeyEvent.#Keys.MICROPHONE_TOGGLE;
                            case "MicrophoneVolumeDown": return KeyEvent.#Keys.MICROPHONE_VOLUME_DOWN;
                            case "MicrophoneVolumeMute": return KeyEvent.#Keys.MICROPHONE_VOLUME_MUTE;
                            case "MicrophoneVolumeUp": return KeyEvent.#Keys.MICROPHONE_VOLUME_UP;
                            case "ModeChange": return KeyEvent.#Keys.MODE_CHANGE;
                            case "Multiply": return KeyEvent.#Keys.MULTIPLY;
                            case "NavigateIn": return KeyEvent.#Keys.NAVIGATE_IN;
                            case "NavigateNext": return KeyEvent.#Keys.NAVIGATE_NEXT;
                            case "NavigateOut": return KeyEvent.#Keys.NAVIGATE_OUT;
                            case "NavigatePrevious": return KeyEvent.#Keys.NAVIGATE_PREVIOUS;
                            case "New": return KeyEvent.#Keys.NEW;
                            case "NextCandidate": return KeyEvent.#Keys.NEXT_CANDIDATE;
                            case "NextFavoriteChannel": return KeyEvent.#Keys.NEXT_FAVORITE_CHANNEL;
                            case "NextUserProfile": return KeyEvent.#Keys.NEXT_USER_PROFILE;
                            case "NonConvert": return KeyEvent.#Keys.NON_CONVERT;
                            case "Notification": return KeyEvent.#Keys.NOTIFICATION;
                            case "NumLock": return KeyEvent.#Keys.NUMBER_LOCK;
                            case "OnDemand": return KeyEvent.#Keys.ON_DEMAND;
                            case "Open": return KeyEvent.#Keys.OPEN;
                            case "PageDown": return KeyEvent.#Keys.PAGE_DOWN;
                            case "PageUp": return KeyEvent.#Keys.PAGE_UP;
                            case "Pairing": return KeyEvent.#Keys.PAIRING;
                            case "Paste": return KeyEvent.#Keys.PASTE;
                            case "Pause": return KeyEvent.#Keys.PAUSE;
                            case "PinPDown": return KeyEvent.#Keys.PIN_P_DOWN;
                            case "PinPMove": return KeyEvent.#Keys.PIN_P_MOVE;
                            case "PinPToggle": return KeyEvent.#Keys.PIN_P_TOGGLE;
                            case "PinPUp": return KeyEvent.#Keys.PIN_P_UP;
                            case "Play": return KeyEvent.#Keys.PLAY;
                            case "PlaySpeedDown": return KeyEvent.#Keys.PLAY_SPEED_DOWN;
                            case "PlaySpeedReset": return KeyEvent.#Keys.PLAY_SPEED_RESET;
                            case "PlaySpeedUp": return KeyEvent.#Keys.PLAY_SPEED_UP;
                            case "Power": return KeyEvent.#Keys.POWER;
                            case "PowerOff": return KeyEvent.#Keys.POWER_OFF;
                            case "PreviousCandidate": return KeyEvent.#Keys.PREVIOUS_CANDIDATE;
                            case "Print": return KeyEvent.#Keys.PRINT;
                            case "PrintScreen": return KeyEvent.#Keys.PRINT_SCREEN;
                            case "Process": return KeyEvent.#Keys.PROCESS;
                            case "Props": return KeyEvent.#Keys.PROPERTIES;
                            case "RandomToggle": return KeyEvent.#Keys.RANDOM_TOGGLE;
                            case "RcLowBattery": return KeyEvent.#Keys.REMOTE_CONTROL_LOW_BATTERY;
                            case "RecordSpeedNext": return KeyEvent.#Keys.RECORD_SPEED_NEXT;
                            case "Redo": return KeyEvent.#Keys.REDO;
                            case "RfBypass": return KeyEvent.#Keys.RADIO_FREQUENCY_BYPASS;
                            case "Romaji": return KeyEvent.#Keys.ROMAJI;
                            case "STBInput": return KeyEvent.#Keys.SET_TOP_BOX_INPUT;
                            case "STBPower": return KeyEvent.#Keys.SET_TOP_BOX_POWER;
                            case "Save": return KeyEvent.#Keys.SAVE;
                            case "ScanChannelsToggle": return KeyEvent.#Keys.SCAN_CHANNELS_TOGGLE;
                            case "ScreenModeNext": return KeyEvent.#Keys.SCREEN_MODE_NEXT;
                            case "ScrollLock": return KeyEvent.#Keys.SCROLL_LOCK;
                            case "Select": return KeyEvent.#Keys.SELECT;
                            case "Separator": return KeyEvent.#Keys.SEPARATOR;
                            case "Settings": return KeyEvent.#Keys.SETTINGS;
                            case "SingleCandidate": return KeyEvent.#Keys.SINGLE_CANDIDATE;
                            case "Soft1": return KeyEvent.#Keys.SOFT1;
                            case "Soft2": return KeyEvent.#Keys.SOFT2;
                            case "Soft3": return KeyEvent.#Keys.SOFT3;
                            case "Soft4": return KeyEvent.#Keys.SOFT4;
                            case "SpeechCorrectionList": return KeyEvent.#Keys.SPEECH_CORRECTION_LIST;
                            case "SpeechInputToggle": return KeyEvent.#Keys.SPEECH_INPUT_TOGGLE;
                            case "SpellCheck": return KeyEvent.#Keys.SPELL_CHECK;
                            case "SplitScreenToggle": return KeyEvent.#Keys.SPLIT_SCREEN_TOGGLE;
                            case "Standby": return KeyEvent.#Keys.STANDBY;
                            case "Subtitle": return KeyEvent.#Keys.SUBTITLE;
                            case "Subtract": return KeyEvent.#Keys.SUBTRACT;
                            case "Super": return KeyEvent.#Keys.SUPER;
                            case "Symbol": return KeyEvent.#Keys.SYMBOL;
                            case "SymbolLock": return KeyEvent.#Keys.SYMBOL_LOCK;
                            case "TV": return KeyEvent.#Keys.TV;
                            case "TV3DMode": return KeyEvent.#Keys.TV_3D_MODE;
                            case "TVAntennaCable": return KeyEvent.#Keys.TV_ANTENNA_CABLE;
                            case "TVAudioDescription": return KeyEvent.#Keys.TV_AUDIO_DESCRIPTION;
                            case "TVAudioDescriptionMixDown": return KeyEvent.#Keys.TV_AUDIO_DESCRIPTION_MIX_DOWN;
                            case "TVAudioDescriptionMixUp": return KeyEvent.#Keys.TV_AUDIO_DESCRIPTION_MIX_UP;
                            case "TVContentsMenu": return KeyEvent.#Keys.TV_CONTENTS_MENU;
                            case "TVDataService": return KeyEvent.#Keys.TV_DATA_SERVICE;
                            case "TVInput": return KeyEvent.#Keys.TV_INPUT;
                            case "TVInputComponent1": return KeyEvent.#Keys.TV_INPUT_COMPONENT1;
                            case "TVInputComponent2": return KeyEvent.#Keys.TV_INPUT_COMPONENT2;
                            case "TVInputComposite1": return KeyEvent.#Keys.TV_INPUT_COMPOSITE1;
                            case "TVInputComposite2": return KeyEvent.#Keys.TV_INPUT_COMPOSITE2;
                            case "TVInputHDMI1": return KeyEvent.#Keys.TV_INPUT_HDMI1;
                            case "TVInputHDMI2": return KeyEvent.#Keys.TV_INPUT_HDMI2;
                            case "TVInputHDMI3": return KeyEvent.#Keys.TV_INPUT_HDMI3;
                            case "TVInputHDMI4": return KeyEvent.#Keys.TV_INPUT_HDMI4;
                            case "TVInputVGA1": return KeyEvent.#Keys.TV_INPUT_VGA1;
                            case "TVMediaContext": return KeyEvent.#Keys.TV_MEDIA_CONTEXT;
                            case "TVNetwork": return KeyEvent.#Keys.TV_NETWORK;
                            case "TVNumberEntry": return KeyEvent.#Keys.TV_NUMBER_ENTRY;
                            case "TVPower": return KeyEvent.#Keys.TV_POWER;
                            case "TVRadioService": return KeyEvent.#Keys.TV_RADIO_SERVICE;
                            case "TVSatellite": return KeyEvent.#Keys.TV_SATELLITE;
                            case "TVSatelliteBS": return KeyEvent.#Keys.TV_SATELLITE_BROADCAST;
                            case "TVSatelliteCS": return KeyEvent.#Keys.TV_SATELLITE_COMMUNICATION;
                            case "TVSatelliteToggle": return KeyEvent.#Keys.TV_SATELLITE_TOGGLE;
                            case "TVTerrestrialAnalog": return KeyEvent.#Keys.TV_TERRESTRIAL_ANALOG;
                            case "TVTerrestrialDigital": return KeyEvent.#Keys.TV_TERRESTRIAL_DIGITAL;
                            case "TVTimer": return KeyEvent.#Keys.TV_TIMER;
                            case "Tab": return KeyEvent.#Keys.TAB;case "Teletext": return KeyEvent.#Keys.TELETEXT;
                            case "Undo": return KeyEvent.#Keys.UNDO;
                            case "Unidentified": return KeyEvent.#Keys.UNIDENTIFIED;
                            case "VideoModeNext": return KeyEvent.#Keys.VIDEO_MODE_NEXT;
                            case "VoiceDial": return KeyEvent.#Keys.VOICE_DIAL;
                            case "WakeUp": return KeyEvent.#Keys.WAKE_UP;
                            case "Wink": return KeyEvent.#Keys.WINK;
                            case "Zenkaku": return KeyEvent.#Keys.ZENKAKU;
                            case "ZenkakuHanaku": return KeyEvent.#Keys.ZENKAKU_HANAKU;
                            case "ZoomIn": return KeyEvent.#Keys.ZOOM_IN;
                            case "ZoomOut": return KeyEvent.#Keys.ZOOM_OUT;
                            case "ZoomToggle": return KeyEvent.#Keys.ZOOM_TOGGLE;
                            case '0': return KeyEvent.#Keys.DIGIT0;
                            case '1': return KeyEvent.#Keys.DIGIT1;
                            case '2': return KeyEvent.#Keys.DIGIT2;
                            case '3': return KeyEvent.#Keys.DIGIT3;
                            case '4': return KeyEvent.#Keys.DIGIT4;
                            case '5': return KeyEvent.#Keys.DIGIT5;
                            case '6': return KeyEvent.#Keys.DIGIT6;
                            case '7': return KeyEvent.#Keys.DIGIT7;
                            case '8': return KeyEvent.#Keys.DIGIT8;
                            case '9': return KeyEvent.#Keys.DIGIT9;
                            case 'A': return KeyEvent.#Keys.UPPERCASE_A; case 'a': return KeyEvent.#Keys.LOWERCASE_A;
                            case 'B': return KeyEvent.#Keys.UPPERCASE_B; case 'b': return KeyEvent.#Keys.LOWERCASE_B;
                            case 'C': return KeyEvent.#Keys.UPPERCASE_C; case 'c': return KeyEvent.#Keys.LOWERCASE_C;
                            case 'D': return KeyEvent.#Keys.UPPERCASE_D; case 'd': return KeyEvent.#Keys.LOWERCASE_D;
                            case 'E': return KeyEvent.#Keys.UPPERCASE_E; case 'e': return KeyEvent.#Keys.LOWERCASE_E;
                            case 'F': return KeyEvent.#Keys.UPPERCASE_F; case 'f': return KeyEvent.#Keys.LOWERCASE_F;
                            case 'G': return KeyEvent.#Keys.UPPERCASE_G; case 'g': return KeyEvent.#Keys.LOWERCASE_G;
                            case 'H': return KeyEvent.#Keys.UPPERCASE_H; case 'h': return KeyEvent.#Keys.LOWERCASE_H;
                            case 'I': return KeyEvent.#Keys.UPPERCASE_I; case 'i': return KeyEvent.#Keys.LOWERCASE_I;
                            case 'J': return KeyEvent.#Keys.UPPERCASE_J; case 'j': return KeyEvent.#Keys.LOWERCASE_J;
                            case 'K': return KeyEvent.#Keys.UPPERCASE_K; case 'k': return KeyEvent.#Keys.LOWERCASE_K;
                            case 'L': return KeyEvent.#Keys.UPPERCASE_L; case 'l': return KeyEvent.#Keys.LOWERCASE_L;
                            case 'M': return KeyEvent.#Keys.UPPERCASE_M; case 'm': return KeyEvent.#Keys.LOWERCASE_M;
                            case 'N': return KeyEvent.#Keys.UPPERCASE_N; case 'n': return KeyEvent.#Keys.LOWERCASE_N;
                            case 'O': return KeyEvent.#Keys.UPPERCASE_O; case 'o': return KeyEvent.#Keys.LOWERCASE_O;
                            case 'P': return KeyEvent.#Keys.UPPERCASE_P; case 'p': return KeyEvent.#Keys.LOWERCASE_P;
                            case 'Q': return KeyEvent.#Keys.UPPERCASE_Q; case 'q': return KeyEvent.#Keys.LOWERCASE_Q;
                            case 'R': return KeyEvent.#Keys.UPPERCASE_R; case 'r': return KeyEvent.#Keys.LOWERCASE_R;
                            case 'S': return KeyEvent.#Keys.UPPERCASE_S; case 's': return KeyEvent.#Keys.LOWERCASE_S;
                            case 'T': return KeyEvent.#Keys.UPPERCASE_T; case 't': return KeyEvent.#Keys.LOWERCASE_T;
                            case 'U': return KeyEvent.#Keys.UPPERCASE_U; case 'u': return KeyEvent.#Keys.LOWERCASE_U;
                            case 'V': return KeyEvent.#Keys.UPPERCASE_V; case 'v': return KeyEvent.#Keys.LOWERCASE_V;
                            case 'W': return KeyEvent.#Keys.UPPERCASE_W; case 'w': return KeyEvent.#Keys.LOWERCASE_W;
                            case 'X': return KeyEvent.#Keys.UPPERCASE_X; case 'x': return KeyEvent.#Keys.LOWERCASE_X;
                            case 'Y': return KeyEvent.#Keys.UPPERCASE_Y; case 'y': return KeyEvent.#Keys.LOWERCASE_Y;
                            case 'Z': return KeyEvent.#Keys.UPPERCASE_Z; case 'z': return KeyEvent.#Keys.LOWERCASE_Z;

                            case '+': return KeyEvent.#Keys.ADD;
                            case '.': return KeyEvent.#Keys.DECIMAL;
                            case '/': return KeyEvent.#Keys.DIVIDE;
                            case '=': return KeyEvent.#Keys.EQUAL;
                            case '*': return KeyEvent.#Keys.MULTIPLY;
                            case '-': return KeyEvent.#Keys.SUBTRACT;

                            case '`': return KeyEvent.#Keys.QUOTE;
                            case '"': return KeyEvent.#Keys.DOUBLE_QUOTE;
                            case '\'': return KeyEvent.#Keys.SINGLE_QUOTE
                        }
                    }
                };
                static PointerEvent = class PointerEvent extends Events.Event {
                    static #Coordinates = class Coordinates { x; y; constructor(x, y) { this.x = x ?? +0; this.y = y ?? +0 } };
                    #coordinates = new PointerEvent.#Coordinates;

                    get x() { return this.#coordinates.x }
                    set x(coordinate) { return (this.#coordinates.x = coordinate) }
                    get y() { return this.#coordinates.y }
                    set y(coordinate) { return (this.#coordinates.y = coordinate) }
                };
                static ResizeEvent = class ResizeEvent extends Events.Event {
                    currentHeight = +0; currentWidth = +0;
                    previousHeight = +0; previouswidth = +0;

                    get height() { return this.currentHeight }
                    set height(size) { return (this.currentHeight = size) }
                    get width() { return this.currentWidth }
                    set width(size) { return (this.currentWidth = size) }
                };
                static ResourceLoadEvent = class ResourceLoadEvent extends Events.Event { loaded = false; url = null };
                static ScrollWheelEvent = class ScrollWheelEvent extends Events.Event {
                    static #Direction = class Direction extends Enumerable {};
                    static Directions = ImmutableReference(new class DirectionEnumeration extends Enumeration {}(
                        "DOWN", "UP"
                    ).of(ScrollWheelEvent.#Direction));

                    direction
                };

            static #EventsObject = class EventsObject extends Context {};
            static #EventListener = class EventListener extends this.#EventsObject {
                Event;
                invoke; target;

                constructor(invoke, event, target) { super(); this.Event = event ?? Events.Event; this.invoke = invoke; this.target = target ?? GLOBAL }
                listen(target) { this.target = target; return this }
            };

            // Initialization > ... --- REDACT (Lapys) --- NOTE (Lapys) -> Some events are compounded.
                // [...]
                onblur = new Events.#EventListener(function invoke(handler) { const listener = this;
                    listener.target.addEventListener("blur", function _onblur(event) {
                        handler(ImmutableReference(new listener.Event));
                        if (event.cancelable)  { event.preventDefault(); event.stopPropagation() }
                    }, {capture: true, once: false, passive: false}, true);

                    return this
                }, class BlurEvent extends Events.Event {});
                onclick = new Events.#EventListener(function invoke(handler) { const listener = this;
                    listener.target.addEventListener("click", function _onclick(event) {
                        const EVENT = new listener.Event; {
                            EVENT.x = event.clientX;
                            EVENT.y = event.clientY;

                            handler(ImmutableReference(EVENT))
                        } if (event.cancelable)  { event.preventDefault(); event.stopPropagation() }
                    }, {capture: true, once: false, passive: false}, true);

                    return this
                }, Events.PointerEvent);
                ondoubleclick = new Events.#EventListener(function invoke(handler) { const listener = this;
                    listener.target.addEventListener("dblclick", function _ondoubleclick(event) {
                        const EVENT = new listener.Event; {
                            EVENT.x = event.clientX;
                            EVENT.y = event.clientY;

                            handler(ImmutableReference(EVENT))
                        } if (event.cancelable)  { event.preventDefault(); event.stopPropagation() }
                    }, {capture: true, once: false, passive: false}, true);

                    return this
                }, Events.PointerEvent);
                onfocus = new Events.#EventListener(function invoke(handler) { const listener = this;
                    listener.target.addEventListener("focus", function _onfocus(event) {
                        handler(ImmutableReference(new listener.Event));
                        if (event.cancelable)  { event.preventDefault(); event.stopPropagation() }
                    }, {capture: true, once: false, passive: false}, true);

                    return this
                }, class FocusEvent extends Events.Event {});
                onready = new Events.#EventListener(function invoke(handler) { const listener = this, target = listener.target;
                    const EVENT = new listener.Event;

                    if (target instanceof Graphics.Image) {
                        listener.context.onready.listen(target.getRender()).invoke(handler);
                        listener.context.onready.listen(target)
                    }

                    else if (target instanceof GLOBAL.Image) {
                        EVENT.url = target.src;

                        target.addEventListener("error", function _onready() { EVENT.loaded = false; target.removeEventListener("error", _onready); handler(ImmutableReference(EVENT)); }, {capture: true, once: true, passive: false}, true);
                        target.addEventListener("load", function _onready() { EVENT.loaded = true; target.removeEventListener("load", _onready); handler(ImmutableReference(EVENT)) }, {capture: true, once: true, passive: false}, true)
                    }

                    return this
                }, Events.ResourceLoadEvent);
                onresize = new Events.#EventListener(function invoke(handler) { const listener = this, target = listener.target;
                    let {height, width} = getSize();

                    function getSize() {
                        if (target instanceof Window) return {height: GLOBAL.innerHeight, width: GLOBAL.innerWidth};
                        else if (target instanceof Document || target instanceof HTMLDocument) return {height: Math.max(target.body.offsetHeight, target.body.scrollHeight, target.documentElement.clientHeight, target.documentElement.offsetHeight, target.documentElement.scrollHeight), width: Math.max(target.body.offsetWidth, target.body.scrollWidth, target.documentElement.clientWidth, target.documentElement.offsetWidth, target.documentElement.scrollWidth)};
                        else if (target instanceof Element || target instanceof HTMLElement) {
                            let boundingClientRectangle = target.getBoundingClientRect();
                            return {height: boundingClientRectangle.height, width: boundingClientRectangle.width}
                        }

                        return {height: null, width: null}
                    }

                    if (target instanceof EventTarget) {
                        listener.target.addEventListener("resize", function _onresize(event) {
                            const EVENT = new listener.Event; {
                                EVENT.previousHeight = height; EVENT.previousWidth = width;
                                height = getSize().height; width = getSize().width;
                                EVENT.currentHeight = height; EVENT.currentWidth = width;

                                handler(ImmutableReference(EVENT))
                            } if (event.cancelable)  { event.preventDefault(); event.stopPropagation() }
                        }, {capture: true, once: false, passive: false}, true)
                    }

                    return this
                }, Events.ResizeEvent);
                onscrollwheel = new Events.#EventListener(function invoke(handler) { const listener = this;
                    listener.target.addEventListener("wheel", function _onscrollwheel(event) { const EVENT = new listener.Event;
                        EVENT.direction = event.deltaY < 0 ? Events.ScrollWheelEvent.Directions.DOWN : Events.ScrollWheelEvent.Directions.UP;
                        handler(ImmutableReference(EVENT));
                        if (event.cancelable)  { event.preventDefault(); event.stopPropagation() }
                    }, {capture: true, once: false, passive: false}, true);

                    return this
                }, Events.ScrollWheelEvent);

                // [Key]
                onkeydown = new Events.#EventListener(function invoke(handler) { const listener = this, context = listener.context;
                    let isPushing = false;
                    const targets = {blur: context.onblur.target, keypress: context.onkeypress.target, keyup: context.onkeyup.target};

                    function unpush() { isPushing = false }

                    context.onblur.listen(listener.target).invoke(unpush);
                    context.onkeypress.listen(listener.target).invoke(function(event) { if (false == isPushing) {
                        const EVENT = new listener.Event; EVENT.key = event.key;
                        isPushing = true; handler(ImmutableReference(EVENT));
                    } });
                    context.onkeyup.listen(listener.target).invoke(unpush);

                    context.onblur.listen(targets.blur);
                    context.onkeypress.listen(targets.keypress);
                    context.onkeyup.listen(targets.keyup);

                    return this
                }, class KeyPushEvent extends Events.KeyEvent {});
                onkeypress = new Events.#EventListener(function invoke(handler) { const listener = this;
                    listener.target.addEventListener("keypress", function _onkeypress(event) {
                        const EVENT = new listener.Event; {
                            EVENT.key = Events.KeyEvent.getAssociatedKey(event);
                            handler(ImmutableReference(EVENT))
                        } if (event.cancelable)  { event.preventDefault(); event.stopPropagation() }
                    }, {capture: true, once: false, passive: false}, true);

                    return this
                }, class KeyPressEvent extends Events.KeyEvent {});
                onkeyup = new Events.#EventListener(function invoke(handler) { const listener = this;
                    listener.target.addEventListener("keyup", function _onkeyup(event) {
                        const EVENT = new listener.Event; {
                            EVENT.key = Events.KeyEvent.getAssociatedKey(event);
                            handler(ImmutableReference(EVENT))
                        } if (event.cancelable)  { event.preventDefault(); event.stopPropagation() }
                    }, {capture: true, once: false, passive: false}, true);

                    return this
                }, class KeyReleaseEvent extends Events.KeyEvent {});

                // [Pointer] --- NOTE (Lapys) -> The `PointerReleaseEvent` will not be dispatched when the target is unfocused.
                onpointerdown = new Events.#EventListener(function invoke(handler) { const listener = this;
                    let isPending = false;

                    function unpend() { isPending = false }
                    function _onpointerdown(event) { if (false == isPending) {
                        const EVENT = new listener.Event; {
                            if (event instanceof TouchEvent) { EVENT.x = event.touches[0].clientX; EVENT.y = event.touches[0].clientY }
                            else { EVENT.x = event.clientX; EVENT.y = event.clientY }

                            isPending = true; handler(ImmutableReference(EVENT));
                            Game.tick(unpend)
                        } if (event.cancelable)  { event.preventDefault(); event.stopPropagation() }
                    } }

                    listener.target.addEventListener("mousedown", _onpointerdown, {capture: true, once: false, passive: false}, true);
                    listener.target.addEventListener("pointerdown", _onpointerdown, {capture: true, once: false, passive: false}, true);
                    listener.target.addEventListener("touchstart", _onpointerdown, {capture: true, once: false, passive: false}, true);

                    return this
                }, class PointerPushEvent extends Events.PointerEvent {});
                onpointermove = new Events.#EventListener(function invoke(handler) { const listener = this;
                    let isPending = false;

                    function unpend() { isPending = false }
                    function _onpointermove(event) { if (false == isPending) {
                        const EVENT = new listener.Event; {
                            if (event instanceof TouchEvent) { EVENT.x = event.touches[0].clientX; EVENT.y = event.touches[0].clientY }
                            else { EVENT.x = event.clientX; EVENT.y = event.clientY }

                            isPending = true; handler(ImmutableReference(EVENT));
                            Game.tick(unpend)
                        } if (event.cancelable) { event.preventDefault(); event.stopPropagation() }
                    } }

                    listener.target.addEventListener("mousemove", _onpointermove, {capture: true, once: false, passive: false}, true);
                    listener.target.addEventListener("pointermove", _onpointermove, {capture: true, once: false, passive: false}, true);
                    listener.target.addEventListener("touchmove", _onpointermove, {capture: true, once: false, passive: false}, true);

                    return this
                }, class PointerMoveEvent extends Events.PointerEvent {});
                onpointerpress = new Events.#EventListener(function invoke(handler) { const listener = this, context = listener.context;
                    let isMoving = false, isPushing = false;
                    let EVENT, targets = {blur: context.onblur.target, pointerdown: context.onpointerdown.target, pointermove: context.onpointermove.target, pointerup: context.onpointerup.target};

                    function _onpointerpress() { handler(ImmutableReference(EVENT)) }
                    function _onpointerpressed(event) { EVENT = new listener.Event; EVENT.x = event.x; EVENT.y = event.y }

                    context.onblur.listen(listener.target).invoke(function() { isMoving = isPushing = false });
                    context.onpointerdown.listen(listener.target).invoke(function(event) {
                        isPushing = true; _onpointerpressed(event);
                        Game.tick(function _onpointerpressing() { if (isPushing) { _onpointerpress(); Game.tick(_onpointerpressing) } })
                    });
                    context.onpointermove.listen(listener.target).invoke(function(event) {
                        if (isMoving) { _onpointerpressed(event); _onpointerpress() }
                        else if (isPushing) Game.tick(function() { isMoving = true })
                    });
                    context.onpointerup.listen(listener.target).invoke(function() { isMoving = isPushing = false });

                    context.onblur.listen(targets.blur);
                    context.onpointerdown.listen(targets.pointerdown);
                    context.onpointermove.listen(targets.pointermove);
                    context.onpointerup.listen(targets.pointerup);

                    return this
                });
                onpointerup = new Events.#EventListener(function invoke(handler) { const listener = this;
                    let isPending = false;

                    function unpend() { isPending = false }
                    function _onpointerup(event) { if (false == isPending) {
                        const EVENT = new listener.Event; {
                            if (event instanceof TouchEvent) { EVENT.x = event.changedTouches[0].clientX; EVENT.y = event.changedTouches[0].clientY }
                            else { EVENT.x = event.clientX; EVENT.y = event.clientY }

                            isPending = true; handler(ImmutableReference(EVENT));
                            Game.tick(unpend)
                        } if (event.cancelable)  { event.preventDefault(); event.stopPropagation() }
                    } }

                    listener.target.addEventListener("mouseup", _onpointerup, {capture: true, once: false, passive: false}, true);
                    listener.target.addEventListener("pointerup", _onpointerup, {capture: true, once: false, passive: false}, true);
                    listener.target.addEventListener("touchend", _onpointerup, {capture: true, once: false, passive: false}, true);

                    return this
                }, class PointerReleaseEvent extends Events.PointerEvent {})
        };

    /* Class > Graphics --- NOTE (Lapys) ->
        - Buffers are `CanvasRenderingContext2D` objects,
        - Renders are `HTMLCanvasElement` objects.
    */
    class Graphics {
        // Initialization > ...
        #BufferList; // NOTE (Lapys) -> Batch of renders used to form graphics unto the `#Render`.
        #CurrentBufferIndex; // NOTE (Lapys) -> Current render "buffer" used to form graphics unto the `#Render`.
        #Render; // NOTE (Lapys) -> `HTMLCanvasElement` object where graphics is drawn unto.

        // : ... NOTE (Lapys) -> Settings of the drawing interface.
        CompositeOperation;
        Opacity;
        SubPixelRendering; // NOTE (Lapys) -> Allows coordinates to be aliased with floating-point numerals.

        // : ... NOTE (Lapys) -> Shorthand reference objects.
        Colors = null;
        Filters = null;
        GradientPatterns = null;
        LineCaps = null;
        LineJoins = null;
        Positions = null;

        /* [Constructor] */
        constructor(render) { this.#Initiate(render) }

        /* Class */
            /* ... [Utility] */
            static BufferList = class BufferList extends List {};

            static CompositeOperations = ImmutableReference(new class CompositeOperationEnumeration extends Enumeration {}(
                "COLOR", "COLOR_BURN", "COLOR_DODGE", "COPY",
                "DARKEN", "DESTINATION_ATOP", "DESTINATION_IN", "DESTINATION_OVER", "DESTINATION_OUT", "DIFFERENCE",
                "EXCLUSION",
                "HARD_LIGHT", "HUE",
                "LIGHTEN", "LIGHTER", "LUMINOSITY",
                "MULTIPLY", "OVERLAY",
                "SATURATION", "SCREEN", "SOFT_LIGHT", "SOURCE_ATOP", "SOURCE_IN", "SOURCE_OVER", "SOURCE_OUT",
                "XOR"
            ).of(class CompositeOperation extends Enumerable {}));

            static Vector = class Vector {};
            static _2D_Vector = class _2D_Vector extends Graphics.Vector { x; y; constructor(x, y) { super(); this.x = x ?? +0; this.y = y ?? +0 } };
            static _3D_Vector = class _3D_Vector extends Graphics.Vector { x; y; z; constructor(x, y, z) { super(); this.x = x ?? +0; this.y = y ?? +0; this.z = z ?? +0 } };

            /* Arc --- CHECKPOINT (Lapys) */
            static Arc = class Arc {};

            /* Graphics Object
                    --- NOTE (Lapys) -> Instance-dependent class.
                    --- WARN (Lapys) -> Any child class must be non-static.
            */
            GraphicsObject = class GraphicsObject extends Context {};

            /* Color --- NOTE (Lapys) -> RGBA format. --- REDACT (Lapys) */
            static Color = class Color {
                static ColorValue = class ColorValue extends Number {};
                #alpha = 1;
                #value = new Color.ColorValue(0xFFFFFF);

                constructor(red, green, blue, alpha) {
                    if (arguments.length) {
                        let value = 0x0;
                        switch (Math.min(4, arguments.length)) {
                            case 4: this.alpha = alpha;
                            case 3: value += blue;
                            case 2: value += -~0x0000FF * green;
                            case 1: value += -~0x00FFFF * red; break;
                        } this.#value = new Color.ColorValue(value)
                    }
                }

                get alpha() { return this.#alpha }
                set alpha(range) { return (this.#alpha = range % 2) }
                get blue() { return this.#value & 0xFF }
                set blue(range) { this.#value = new Color.ColorValue((range % 256) + (this.#value & 0xFFFF00)) }
                get green() { return (this.#value >> 8) & 0xFF }
                set green(range) { this.#value = new Color.ColorValue((-~0x0000FF * (range % 256)) + (this.#value & 0xFF00FF)) }
                get red() { return (this.#value >> 16) & 0xFF }
                set red(range) { this.#value = new Color.ColorValue((-~0x00FFFF * (range % 256)) + (this.#value & 0x00FFFF)) }
                toString() { return "rgba(" + this.red + ", " + this.green + ", " + this.blue + ", " + this.alpha + ')' }
            };

            /* Coordinates --- REDACT (Lapys) */
            Coordinates = class Coordinates extends this.GraphicsObject {
                #value;

                constructor(x, y) { super(); this.#value = new Graphics._2D_Vector(x, y) }
                static #resolveCoordinate(coordinate) { return Coordinates.getContext().SubPixelRendering ? coordinate : Math.trunc(coordinate) }

                get x() { return Coordinates.#resolveCoordinate(this.#value.x) }
                set x(coordinate) { return (this.#value.x = Coordinates.#resolveCoordinate(coordinate)) }
                get y() { return Coordinates.#resolveCoordinate(this.#value.y) }
                set y(coordinate) { return (this.#value.y = Coordinates.#resolveCoordinate(coordinate)) }
            };

            /* Draw Options --- NOTE (Lapys) -> Ambiguous? */
            DrawOptions = class DrawOptions extends this.GraphicsObject {
                // Initialization > ...
                colors; coordinates;
                filters; gradients; line;
                opacity; overlay;
                patterns; transforms;

                // [Constructor]
                constructor() { const options = Object(arguments[0]); super();
                    // Constant > ...
                    const context = this.context;

                    // Modification > Target > ...
                    this.colors = {fill: DrawOptions.Colors.TRANSPARENT, stroke: DrawOptions.Colors.BLACK};
                    this.coordinates = new context.Coordinates;
                    this.filters = new DrawOptions.FilterList;
                    this.gradients = {
                        fill: {anchors: new List, stops: new DrawOptions.GradientStopList, type: null},
                        stroke: {anchors: new List, stops: new DrawOptions.GradientStopList, type: null}
                    };
                    this.line = {cap: DrawOptions.LineCaps.BUTT, dashOffset: +0, join: DrawOptions.LineCaps.ROUND, width: 1};
                    this.opacity = {fill: 1, stroke: 1};
                    this.overlay = new DrawOptions.DrawOptionList;
                    this.patterns = {fill: null, stroke: null};
                    this.transforms = {
                        rotation: {anchor: new context.Coordinates, angle: +0},
                        translation: new context.Coordinates,
                        scale: new context.constructor._2D_Vector,
                        skew: new context.constructor._2D_Vector
                    };
                }

                /* Class */
                    /* [Utility] ... */
                    static DrawOptionList = class DrawOptionList extends List {};
                    static DynamicCoordinates = class DynamicCoordinates extends Enumerable {};

                    /* Filter ... */
                    static Filter = class Filter {
                        #source;
                        constructor(name, parameters) { this.#source = arguments.length ? name + '(' + ((arguments.length || 1) == 1 ? "" : parameters.join(", ")) + ')' : "none" }
                        toString() { return this.#source }
                    };
                    static FilterList = class FilterList extends List {};

                    /* Gradient Stop List --- REDACT (Lapys) */
                    static GradientStopList = class GradientStopList extends List {
                        add() { const length = arguments.length; if (length) {
                            let range = this.#getLastStopRange();
                            for (let iterator = +0; iterator ^ length; ++iterator) {
                                const stop = arguments[iterator];

                                if (range < stop.range) {
                                    List.prototype.add.call(this, stop);
                                    range = stop.range
                                } else if (range > stop.range) {
                                    List.prototype.add.call(this, stop);
                                    List.prototype.sort.call(this, (x, y) => { return (x.range < y.range) * -1 })
                                }
                            }
                        } }

                        #getLastStopRange() { const last = this.last; return last ? last.range : +0 }
                    };

                /* Function > ... */
                static #generatePresetFilterConstructor(name) { return function PresetFilter() { return new DrawOptions.Filter(name, Array.from(arguments)) } }

                static hasFillColor(options) { return true }
                static hasFillGradient(options) { return null !== options.gradients.fill.type }
                static hasFillPattern(options) { return null !== options.patterns.fill }
                static hasStrokeColor(options) { return true }
                static hasStrokeGradient(options) { return null !== options.gradients.stroke.type }
                static hasStrokePattern(options) { return null !== options.patterns.stroke }

                get fillColor() { return this.colors.fill }
                set fillColor(color) { return (this.colors.fill = color) }
                get fillGradient() { return this.gradients.fill }
                get fillOpacity() { return this.opacity.fill }
                set fillOpacity(opacity) { return (this.opacity.fill = opacity) }
                get fillPattern() { return this.patterns.fill }
                set fillPattern(image) { return (this.patterns.fill = image) }
                get lineCap() { return this.line.cap }
                set lineCap(cap) { return (this.line.cap = cap) }
                get lineDashOffset() { return this.line.dashOffset }
                set lineDashOffset(size) { return (this.line.dashOffset = size) }
                get lineJoin() { return this.line.join }
                set lineJoin(join) { return (this.line.join = join) }
                get lineWidth() { return this.line.width }
                set lineWidth(size) { return (this.line.width = size) }
                get rotation() { return this.transforms.rotation.angle }
                set rotation(angle) { return (this.transforms.rotation.angle = angle) }
                get rotationAnchor() { return this.transforms.rotation.anchor }
                get translation() { return this.transforms.translation }
                get scale() { return this.transforms.scale }
                get skew() { return this.transforms.skew }
                get strokeColor() { return this.colors.stroke }
                set strokeColor(color) { return (this.colors.stroke = color) }
                get strokeGradient() { return this.gradients.stroke }
                get strokeOpacity() { return this.opacity.stroke }
                set strokeOpacity(opacity) { return (this.opacity.stroke = opacity) }
                get strokePattern() { return this.patterns.stroke }
                set strokePattern(image) { return (this.patterns.stroke = image) }
                get x() { return this.coordinates.x }
                set x(coordinate) { return (this.coordinates.x = coordinate) }
                get y() { return this.coordinates.y }
                set y(coordinate) { return (this.coordinates.y = coordinate) }

                // Constant > ...
                static Colors = ImmutableObject({
                    BLACK: new Graphics.Color(+0, +0, +0, 1),
                    BLUE: new Graphics.Color(+0, +0, 255, 1),
                    CYAN: new Graphics.Color(+0, 255, 255, 1),
                    GRAY: new Graphics.Color(127, 127, 127, 1),
                    GREY: new Graphics.Color(127, 127, 127, 1),
                    GREEN: new Graphics.Color(+0, 255, +0, 1),
                    MAGENTA: new Graphics.Color(255, +0, 255, 1),
                    RED: new Graphics.Color(255, +0, +0, 1),
                    TRANSPARENT: new Graphics.Color(+0, +0, +0, +0),
                    WHITE: new Graphics.Color(255, 255, 255, 1),
                    YELLOW: new Graphics.Color(255, 255, +0, 1)
                });

                static Filters = ImmutableReference({
                    BLUR: DrawOptions.#generatePresetFilterConstructor("blur"),
                    BRIGHTNESS: DrawOptions.#generatePresetFilterConstructor("brightness"),
                    CONTRAST: DrawOptions.#generatePresetFilterConstructor("contrast"),
                    DROP_SHADOW: DrawOptions.#generatePresetFilterConstructor("drop-shadow"),
                    GRAYSCALE: DrawOptions.#generatePresetFilterConstructor("grayscale"),
                    HUE_ROTATE: DrawOptions.#generatePresetFilterConstructor("hue-rotate"),
                    INVERT: DrawOptions.#generatePresetFilterConstructor("invert"),
                    OPACITY: DrawOptions.#generatePresetFilterConstructor("opacity"),
                    SATURATE: DrawOptions.#generatePresetFilterConstructor("saturate"),
                    SEPIA: DrawOptions.#generatePresetFilterConstructor("sepia"),
                    NONE: new DrawOptions.Filter,
                    URL: DrawOptions.#generatePresetFilterConstructor("url")
                });

                static GradientPatterns = ImmutableReference(new class GradientPatternEnumeration extends Enumeration {}(
                    "LINEAR", "RADIAL"
                ).of(class GradientPattern extends Enumerable {}));

                static LineCaps = ImmutableReference(new class LineCapEnumeration extends Enumeration {}(
                    "BUTT", "ROUND", "SQUARE"
                ).of(class LineCap extends Enumerable {}));

                static LineJoins = ImmutableReference(new class LineJoinEnumeration extends Enumeration {}(
                    "BEVEL", "MITER", "ROUND"
                ).of(class LineJoin extends Enumerable {}));

                static Positions = ImmutableReference(new class DynamicCoordinatesEnumeration extends Enumeration {}(
                    "BOTTOM", "CENTER", "LEFT", "RIGHT", "TOP"
                ).of(DrawOptions.DynamicCoordinates));

                /* Phase > Initiate */
                static Initiate() { const context = DrawOptions.getContext();
                    // Modification > ... Context > ...
                    context.Colors = DrawOptions.Colors;
                    context.Filters = DrawOptions.Filters;
                    context.GradientPatterns = DrawOptions.GradientPatterns;
                    context.LineCaps = DrawOptions.LineCaps;
                    context.LineJoins = DrawOptions.LineJoins;
                    context.Positions = DrawOptions.Positions
                }
            };

            /* Gradient Stop */
            static GradientStop = class GradientStop extends Graphics.Color {
                #range = +0;
                constructor(red, green, blue, alpha, range) { super(red, green, blue, alpha); this.range = range }

                get range() { return this.#range }
                set range(range) { return (this.#range = range % 2) }
            };

            /* Image */
            static Image = class GraphicsImage {
                // [Constructor]; Initialization > Value
                #value = null;
                constructor(url) { if (arguments.length) { const graphicsImage = this;
                    // Constant > Image
                    const image = new GLOBAL.Image;

                    // Modification > Graphics Image > Value
                    graphicsImage.#value = image;
                    image.src = url;

                    // Event > Image > Resource Load
                    Events.onready.listen(image).invoke(function(event) {
                        // Logic > ...
                        if (event.loaded) {
                            image.height = image.naturalHeight;
                            image.width = image.naturalWidth
                        } else graphicsImage.#value = null
                    })
                } }

                // Function > Get Render
                getRender() { return null === this.#value ? new Image : this.#value }
            };

            /* Line --- CHECKPOINT (Lapys) */
            static Line = class Line {};

            /* Shape --- CHECKPOINT (Lapys) */
            static Shape = class Shape {};

            /* Text --- CHECKPOINT (Lapys) */
            static Text = class Text {};

        /* Phase > (Initiate, Reset) */
        #Initiate(render) {
            // Modification > Target > ...
            this.#Render = render ?? null;
            this.SubPixelRendering = true;

            /* ... */
            this.GraphicsObject.Initiate(this);
            this.DrawOptions.Initiate();

            this.Reset()
        }

        Reset(render) {
            // Modification > Target > ...
            this.#BufferList = new Graphics.BufferList;
            this.CompositeOperation = Graphics.CompositeOperations.SOURCE_OVER;
            this.#CurrentBufferIndex = -1; // NOTE (Lapys) -> Represents no available buffer.
            this.Opacity = 1;
            this.SubPixelRendering = true;

            // ...
            // this.setBufferCount(3)
        }
    };

    /* Modification */ {
        /* Global > ... */
        Object.defineProperty(GLOBAL, "Game", {configurable: true, enumerable: true, value: Game, writable: false});
        Object.defineProperty(GLOBAL, "Graphics", {configurable: true, enumerable: true, value: Graphics, writable: false});
        Object.defineProperty(GLOBAL, "Events", {configurable: true, enumerable: true, value: Events, writable: false});

        Object.defineProperty(GLOBAL, "preload", {configurable: true, enumerable: true, value: Game.preload, writable: true})
    }
}("undefined" == typeof(self) ? ("undefined" == typeof(window) ? ("undefined" == typeof(global) ? (function() { return this })() : global) : window) : self);
