/* Game
    --- NOTE (Lapys) -> May utilize older JavaScript features for clearer & more efficient programming.
    --- WARN (Lapys) -> Assertion (or exception handling) is minimal due to JavaScript's design.
*/
; void function Game(Global) {
    /* Class */
        /* Enum... --- NOTE (Lapys) -> Keyed list of enumerable (whole integer) values. */
        class Enumeration {
            // : Constant > Maximum Unique Enumerable Size --- NOTE (Lapys) -> Maximum number of `Enumerable` values that can be stored within a `Number`.
            // : Class > Enumerable
            static MAX_UNIQUE_ENUMERABLE_SIZE = Enumeration.getLeastRepresentableByteSize(Number.MAX_SAFE_INTEGER);
            static Enumerable;

            // [Constructor]
            constructor() {
                // Constant > (Length, ...)
                // : Class > Integer
                const length = arguments.length;
                const isUniquelyRepresentable = length < Enumeration.MAX_UNIQUE_ENUMERABLE_SIZE;

                const Integer = isUniquelyRepresentable ? Number : BigInt;

                // Loop > Modification > Target; Continue
                for (let index = Integer(1), iterator = length - 1; ~iterator; --iterator) {
                    this[arguments[iterator]] = index;
                    isUniquelyRepresentable ? index *= Integer(2) : ++index
                }
            }

            // Function > (Get Least Representable Byte Size, Of)
            static getLeastRepresentableByteSize(number) { let iterator = number, size = +0; while (iterator) { ++size; iterator /= 2; iterator = Math.trunc(iterator) } return size ? size + 1 : 1 }
            of(constructor) { for (let enumerable in this) this[enumerable] = new constructor(this[enumerable]); return this }
        }; const Enumerable = (Enumeration.Enumerable = class Enumerable extends Number { constructor(value) { super(Math.trunc(Number.from(value))) } });

        /* List --- NOTE (Lapys) -> List of values. */
        class List extends Array {
            // Initialization > ...
            get first() { return this.length ? this[0] : undefined }
            set first(value) { this.length && (this[0] = value); return undefined }
            get last() { return this.length ? this[this.length - 1] : undefined }
            set last(value) { this.length && (this[this.length - 1] = value); return value }

            // Function > ...
            static from(list) { if ("object" == typeof(list) && null !== list) { if (list instanceof Array) return list; else { const evaluation = new this; for (let iterator = +0, length = list.length; iterator ^ length; ++iterator) evaluation.push(list[iterator]); return evaluation } } return new this }

            add() { return Array.prototype.push.apply(this, arguments) }
            build(handler) { const list = this; list.foreach(function _build(element, index) { list[index] = handler(element, index, list) }) }
            firstIndexOf(value) { for (let iterator = +0, length = this.length; iterator ^ length; ++iterator) if (value === this[iterator]) return iterator; return -1 }
            foreach() { List.prototype.forEach.apply(this, arguments) }
            free() { this.resize(+0) }
            includes(value) { return false != ~(this.length >>> 14 ? List.prototype.indexOf.call(this, value) : List.prototype.firstIndexOf.call(this, value)) }
            indexOf(value) { const length = this.length; if (length >>> 14) { for (let endIterator = length - 1, middleStartIterator = Math.trunc(length / 2), middleEndIterator = middleStartIterator + !(length % 2), startIterator = +0; endIterator >= middleEndIterator || startIterator <= middleStartIterator; (--endIterator, ++middleEndIterator, --middleStartIterator, ++startIterator)) switch (value) { case this[endIterator]: return endIterator; case this[middleEndIterator]: return middleEndIterator; case this[middleStartIterator]: return middleStartIterator; case this[startIterator]: return startIterator } } else { switch (length) { case 0: return -1; case 2: if (value == array[1]) return 1; case 1: if (value == array[0]) return +0 } for (let endIterator = length - 1, startIterator = +0; endIterator >= startIterator; (--endIterator, ++startIterator)) switch (value) { case this[endIterator]: return endIterator; case this[startIterator]: return startIterator } } return -1 }
            lastIndexOf(value) { for (let iterator = this.length - 1; ~iterator; --iterator) if (value === this[iterator]) return iterator; return -1 }
            pop(value) { const index = List.prototype.indexOf.call(this, value); ~index ? (List.prototype.splice.call(this, index, 1), true) : false }
            popFirst(value) { const index = List.prototype.firstIndexOf.call(this, value); ~index ? (List.prototype.splice.call(this, index, 1), true) : false }
            popLast(value) { const index = List.prototype.lastIndexOf.call(this, value); ~index ? (List.prototype.splice.call(this, index, 1), true) : false }
            push(value) { return Array.prototype.push.call(this, value) }
            remove() { for (let iterator = +0, length = arguments.length; iterator ^ length; ++iterator) this.pop(arguments[iterator]) }
            removeFirst() { for (let iterator = +0, length = arguments.length; iterator ^ length; ++iterator) this.popFirst(arguments[iterator]) }
            removeLast() { for (let iterator = +0, length = arguments.length; iterator ^ length; ++iterator) this.popLast(arguments[iterator]) }
            resize(length) { this.length = length }
        };

        /* : Immutable Object --- NOTE (Lapys) -> Deeply qualifies properties to be immutable. --- REDACT (Lapys) */
        /* : Immutable Reference --- NOTE (Lapys) -> Qualifies immediate properties to be immutable. --- REDACT (Lapys) */
        function ImmutableObject(object) { if (this instanceof ImmutableObject) throw new TypeError("`ImmutableObject` is not a constructor"); else { for (let key in object) { if ("object" == typeof(object[key])) object[key] = ImmutableObject(object[key]) } ImmutableReference(object); return object } }
        function ImmutableReference(object) { if (this instanceof ImmutableReference) throw new TypeError("`ImmutableReference` is not a constructor"); else { Object.freeze(object); return object } }

    /* Namespace --- CONSIDER (Lapys) -> Heavier data definitions are only declared here. */
        /* Game */
        const Game = new class Game {
            // Class > (Animations, Entity, Events, Graphics, Object)
            Animations;
            Components = {Renderable: null};
            Entity;
            Events;
            Graphics;
            Object;
            Scene;

            // Constant > (Initiated, Pending Count, Tick Speed)
            INITIATED = false;
            PENDING_COUNT = 0n;
            TICK_SPEED = 1000 / 60; // NOTE (Lapys) -> 1000 milliseconds in 60 frames.

            // Phase > (..., Initiate, Reset, Update, Terminate) ...
            INITIATE_HANDLER = function INITIATE() { this.INITIATE_HANDLER = function INITIATE() {}; this.EXECUTE() };
            RESET_HANDLER = function RESET() { this.INITIATE_HANDLER() };
            UPDATE_HANDLER = function UPDATE() {};
            TERMINATE_HANDLER = function TERMINATE() { this.INITIATED = false };

            EXECUTE() {
                // Constant > Game
                // : Initialization > Recent Timestamp
                const Game = this;
                let recentTimestamp = Game.timestamp();

                // ...
                Game.INITIATE_HANDLER();
                void function _ontick() { if (Game.INITIATED) {
                    // Constant > Timestamp
                    const timestamp = Game.timestamp();

                    // Logic > ...
                    if (timestamp - recentTimestamp >= Game.TICK_SPEED) { recentTimestamp = timestamp; Game.UPDATE_HANDLER(true) }
                    else Game.UPDATE_HANDLER(false);

                    // ...
                    Game.tick(_ontick)
                } }();

                // Deletion
                Game.EXECUTE = null; delete Game.EXECUTE
            }
            get INITIATE() { return this.INITIATE_HANDLER };
            set INITIATE(handler) { ("function" == typeof(handler)) && (this.INITIATE_HANDLER = handler); if (false == this.INITIATED) { this.INITIATED = true; this.EXECUTE() } }
            get RESET() { return this.RESET_HANDLER };
            set RESET(handler) { ("function" == typeof(handler)) && (this.RESET_HANDLER = handler) }
            get UPDATE() { return this.UPDATE_HANDLER };
            set UPDATE(handler) { ("function" == typeof(handler)) && (this.UPDATE_HANDLER = handler) }
            get TERMINATE() { return this.TERMINATE_HANDLER };
            set TERMINATE(handler) { ("function" == typeof(handler)) && (this.TERMINATE_HANDLER = handler) }

            // Function
                // Get Tick Speed
                getTickSpeed = function getTickSpeed() { return this.TICK_SPEED };

                // Loop
                loop = function loop(handler) {
                    // Constant > Game
                    // : ...
                    const game = this;
                    game.tick(function _onloop() { handler(); game.tick(_onloop) })
                };

                // Pend, Unpend
                pend = function pend() { return ++this.PENDING_COUNT };
                unpend = function unpend() { return 0n == (this.PENDING_COUNT ? --this.PENDING_COUNT : this.PENDING_COUNT) };

                // Preload
                preload = ("undefined" == typeof(XMLHttpRequest) ?
                    function preload(url) {
                        // Constant > Request
                        const request = new Request(url, {cache: "force-cache", method: "GET", mode: "cors"});

                        // ...; Fetch
                        Game.pend();
                        fetch(request, {
                            cache: request.cache,
                            credentials: request.credentials,
                            headers: request.headers,
                            integrity: request.integrity,
                            keepalive: request.keepalive,
                            method: request.method,
                            mode: request.mode,
                            redirect: request.redirect,
                            referrer: request.referrer,
                            referrerPolicy: request.referrerPolicy,
                            signal: request.signal
                        }).then(Game.unpend)
                    } : function preload(url) {
                        // Constant > (..., Request)
                        let unpend = function unpend() { Game.unpend() };
                        const request = new XMLHttpRequest;

                        // ...; Event > Request > (Error, Load End, Timeout)
                        Game.pend();

                        request.addEventListener("error", function() { (null === unpend) || unpend(); unpend = null });
                        request.addEventListener("loadend", function() { (null === unpend) || unpend(); unpend = null });
                        request.addEventListener("timeout", function() { (null === unpend) || unpend(); unpend = null });

                        // Request > (Open, Send)
                        request.open("GET", url, true, null, null);
                        request.send(null)
                    }
                );

                // Tick
                tick = (function() {
                    // Constant > ... Ticker --- CONSIDER (Lapys) -> Should `unticker` be used?
                    const ticker = "undefined" == typeof(requestAnimationFrame) ? Global.setTimeout : Global.requestAnimationFrame;
                    const unticker = "undefined" == typeof(cancelAnimationFrame) ? Global.clearTimeout : Global.cancelAnimationFrame;

                    // Return
                    return function tick(handler) { return ticker(handler) }
                })();

                // Timestamp
                timestamp = (function() {
                    // Initialization > Timestamper
                    let timestamper;

                    // Logic > Update > Timestamper
                    if ("undefined" != typeof(performance)) {
                        if ("now" in performance && "function" == typeof(performance.now)) timestamper = function() { return performance.now() };
                        else if (
                            "clearMarks" in performance &&
                            "getEntriesByName" in performance &&
                            "mark" in performance &&
                            ("timing" in performance && "navigationStart" in Global.Object(performance.timing))
                        ) timestamper = function() {
                            performance.clearMarks("__PERFORMANCE_NOW__");
                            performance.mark("__PERFORMANCE_NOW__");
                            return performance.getEntriesByName("__PERFORMANCE_NOW__")[0].startTime
                        };
                    }
                    else if ("now" in Date && "function" == typeof(Date.now)) timestamper = Date.now;
                    else timestamper = function() { return (new Date).getTime() };

                    // Return
                    return function timestamp() { return timestamper() }
                })();

                // Set Tick Speed
                setTickSpeed = function setTickSpeed(speed) { this.TICK_SPEED = Number.from(speed) }
        };

        /* Entity ... */
        const EntityList = class EntityList extends List {};
        const Entity = (Game.Entity = class Entity {
            // Initialization > (Children, Identity, Total)
            children = new EntityList; id = Entity.total++;
            static total = 0n;

            // Function > (Add Component, Define, Draw)
            addComponent(component) { const descriptors = Global.Object.getOwnPropertyDescriptors(component.prototype); for (let identifier in descriptors) { if ("constructor" != descriptors) Global.Object.defineProperty(this, identifier, descriptors[identifier]) } component.call(this) }
            static define(entity, identifier, value) { Global.Object.defineProperty(entity, identifier, {configurable: true, enumerable: true, value: value, writable: true}) }
            draw(renderer, parameters, graphics) {}
        });

        /* Object --- NOTE (Lapys) -> Every other class object inherits from this. */
        const Object = (Game.Object = class Object extends Global.Object {
            // Function --- NOTE (Lapys) -> Utility functions.
                // Define, Undefine
                static define = function define(object, identifier, descriptor) {
                    // Logic > ...
                    if (arguments.length > 2) {
                        // Constant > (..., Property Descriptor)
                        const NULL = {};
                        const propertyDescriptor = {configurable: true, enumerable: true, get: NULL, set: NULL, value: NULL, writable: true};

                        // Logic
                        if (null !== descriptor && "object" == typeof(descriptor) && Global.Object.prototype === Global.Object.getPrototypeOf(descriptor)) {
                            // Modification > Property Descriptor > (Enumerable, Get, Set, Value)
                            Object.hasOwn(descriptor, "enumerable") && (propertyDescriptor.enumerable = descriptor.enumerable);
                            Object.hasOwn(descriptor, "get") && (("function" == typeof(propertyDescriptor.get)) && (propertyDescriptor.get = descriptor.get));
                            Object.hasOwn(descriptor, "set") && (("function" == typeof(propertyDescriptor.set)) && (propertyDescriptor.set = descriptor.set));
                            Object.hasOwn(descriptor, "value") && (propertyDescriptor.value = descriptor.value);

                            // Logic > Property Descriptor > (Configurable, Writable)
                            if (Object.hasOwn(descriptor, "mutable")) { const mutable = Boolean(descriptor.mutable);
                                propertyDescriptor.configurable = mutable;
                                propertyDescriptor.writable = mutable
                            } else if (Object.hasOwn(descriptor, "immutable")) { const immutable = Boolean(descriptor.immutable);
                                propertyDescriptor.configurable = false == immutable;
                                propertyDescriptor.writable = false == immutable
                            } else {
                                Object.hasOwn(descriptor, "configurable") && (propertyDescriptor.configurable = descriptor.configurable);
                                Object.hasOwn(descriptor, "writable") && (propertyDescriptor.writable = descriptor.writable)
                            }

                            // Logic > Deletion
                            if (NULL !== propertyDescriptor.value) { delete propertyDescriptor.get; delete propertyDescriptor.set }
                            else if (NULL !== propertyDescriptor.get || NULL !== propertyDescriptor.set) delete propertyDescriptor.value;

                            // Modification > ...
                            (NULL === propertyDescriptor.value) && (propertyDescriptor.value = undefined);
                            Global.Object.defineProperty(object, identifier, propertyDescriptor)
                        } else Global.Object.defineProperty(object, identifier, {configurable: true, enumerable: true, value: descriptor, writable: true})
                    } else Global.Object.defineProperty(object, identifier, {configurable: true, enumerable: true, value: undefined, writable: true});

                    // Return
                    return object
                }; static undefine = function undefine(object, identifier) { if (Object.hasOwn(object, identifier)) { Global.Object.defineProperty(object, identifier, {configurable: true, enumerable: true, value: undefined, writable: true}); return delete object[identifier] } else return false };

                // : From
                // : Has Own
                static from = function from(argument) { return Global.Object(argument) };
                static hasOwn = (function(nativeMethod) { return function hasOwn(object, identifier) { return object ? nativeMethod.call(object, identifier) : false } })(Object.hasOwnProperty)
        });

        /* Events --- NOTE (Lapys) -> The game's event management system. */
        const Events = (Game.Events = new class Events { // WARN (Lapys) -> Events can not be undone.
            // Initialization > ... --- NOTE (Lapys) -> Event listeners.
            onblur = null; onclick = null; ondoubleclick = null; onfocus = null;
            onready = null; onresize = null;
            onscrollwheel = null;

            /* Class > Event ... */
            static Event = class Event { /* NOTE (Lapys) -> Base implementation for handling event data. */ };
            static EventListener = class EventListener {
                // Initialization > (EventConstructor, Invocator, Target)
                eventConstructor; invocator;
                target = Global;

                get target() { return this.target }

                // [Constructor]
                constructor(invocator, constructor) {
                    // Modification > ...
                    this.eventConstructor = constructor ?? Events.Event;
                    this.invocator = invocator ?? null
                }

                // Function > (Invoke, Listen)
                invoke(handler) { (null === this.invocator) || this.invocator(handler, this.target, this.eventConstructor); return this }
                listen(target) { this.target = target; return this }
            };

            /* Class --- NOTE (Lapys) -> Custom event listener implementations. */
                // ...
                static BlurEvent = class BlurEvent extends Events.Event {};
                static FocusEvent = class FocusEvent extends Events.Event {};

                // Key Event; ...
                static KeyEvent = class KeyEvent extends Events.Event {
                    // Class > Key

                    // : Initialization > Key
                    // : Constant > Keys
                    static Key;
                    key; static Keys;

                    // [Constructor]
                    constructor(key) { super(); this.key = key ?? new KeyEvent.Key }

                    // Function > Get Associated Key --- REDACT (Lapys)
                    static getAssociatedKey(event) {
                        switch (event.code) {
                            case "AltLeft": return KeyEvent.Keys.LEFT_ALT;
                            case "AltRight": return KeyEvent.Keys.RIGHT_ALT;
                            case "Backquote": return KeyEvent.Keys.BACKQUOTE;
                            case "Comma": return KeyEvent.Keys.COMMA;
                            case "ControlLeft": return KeyEvent.Keys.LEFT_CONTROL;
                            case "ControlRight": return KeyEvent.Keys.RIGHT_CONTROL;
                            case "Eject": return KeyEvent.Keys.EJECT;
                            case "Period": return KeyEvent.Keys.PERIOD;
                            case "Quote": return KeyEvent.Keys.Quote;
                            case "Semicolon": return KeyEvent.Keys.SEMICOLON;
                            case "ShiftLeft": return KeyEvent.Keys.LEFT_SHIFT;
                            case "ShiftRight": return KeyEvent.Keys.RIGHT_SHIFT;
                            case "Slash": return KeyEvent.Keys.SLASH;
                        }

                        switch (event.key) {
                            case '~': return KeyEvent.Keys.TILDE;
                            case '!': return KeyEvent.Keys.EXCLAMATION;
                            case '@': return KeyEvent.Keys.AT;
                            case '#': return KeyEvent.Keys.HASH;
                            case '$': return KeyEvent.Keys.DOLLAR;
                            case '%': return KeyEvent.Keys.PERCENTAGE;
                            case '^': return KeyEvent.Keys.CARET;
                            case '&': return KeyEvent.Keys.AMPERSAND;
                            case '_': return KeyEvent.Keys.UNDERSCORE;
                            case '|': return KeyEvent.Keys.VERTICAL_BAR;
                            case ':': return KeyEvent.Keys.COLON;
                            case '<': return KeyEvent.Keys.LESSER_THAN;
                            case '>': return KeyEvent.Keys.GREATER_THAN;
                            case '?': return KeyEvent.Keys.QUESTION;
                            case ',': return KeyEvent.Keys.COMMA;
                            case '\\': return KeyEvent.Keys.BACKSLASH;

                            case '{': return KeyEvent.Keys.LEFT_BRACE;
                            case '[': return KeyEvent.Keys.LEFT_BRACKET;
                            case '(': return KeyEvent.Keys.LEFT_PARENTHESIS;
                            case '}': return KeyEvent.Keys.RIGHT_BRACE;
                            case ']': return KeyEvent.Keys.RIGHT_BRACKET;
                            case ')': return KeyEvent.Keys.RIGHT_PARENTHESIS;
                            case ' ': return KeyEvent.Keys.SPACEBAR;

                            case "AVRInput": return KeyEvent.Keys.AVR_INPUT;
                            case "AVRPower": return KeyEvent.Keys.AVR_POWER;
                            case "Accept": return KeyEvent.Keys.ACCEPT;
                            case "Add": return KeyEvent.Keys.ADD;
                            case "Again": return KeyEvent.Keys.AGAIN;
                            case "AllCandidates": return KeyEvent.Keys.ALL_CANDIDATES;
                            case "Alphanumeric": return KeyEvent.Keys.ALPHANUMERIC;
                            case "AltGraph": return KeyEvent.Keys.ALT_GRAPH;
                            case "AppSwitch": return KeyEvent.Keys.APP_SWITCH;
                            case "ArrowDown": return KeyEvent.Keys.ARROW_DOWN;
                            case "ArrowLeft": return KeyEvent.Keys.ARROW_LEFT;
                            case "ArrowRight": return KeyEvent.Keys.ARROW_RIGHT;
                            case "ArrowUp": return KeyEvent.Keys.ARROW_UP;
                            case "Attn": return KeyEvent.Keys.ATTENTION;
                            case "AudioBalanceLeft": return KeyEvent.Keys.AUDIO_BALANCE_LEFT;
                            case "AudioBalanceRight": return KeyEvent.Keys.AUDIO_BALANCE_RIGHT;
                            case "AudioBassBoostDown": return KeyEvent.Keys.AUDIO_BASS_BOOST_DOWN;
                            case "AudioBassBoostToggle": return KeyEvent.Keys.AUDIO_BASS_BOOST_TOGGLE;
                            case "AudioBassBoostUp": return KeyEvent.Keys.AUDIO_BASS_BOOST_UP;
                            case "AudioBassDown": return KeyEvent.Keys.AUDIO_BASS_DOWN;
                            case "AudioBassUp": return KeyEvent.Keys.AUDIO_BASS_UP;
                            case "AudioFaderFront": return KeyEvent.Keys.AUDIO_FADER_FRONT;
                            case "AudioFaderRear": return KeyEvent.Keys.AUDIO_FADER_REAR;
                            case "AudioSurroundModeNext": return KeyEvent.Keys.AUDIO_SURROUND_MODE_NEXT;
                            case "AudioTrebleDown": return KeyEvent.Keys.AUDIO_TREBLE_DOWN;
                            case "AudioTrebleUp": return KeyEvent.Keys.AUDIO_TREBLE_UP;
                            case "AudioVolumeDown": return KeyEvent.Keys.AUDIO_VOLUME_DOWN;
                            case "AudioVolumeMute": return KeyEvent.Keys.AUDIO_VOLUME_MUTE;
                            case "AudioVolumeUp": return KeyEvent.Keys.AUDIO_VOLUME_UP;
                            case "Backspace": return KeyEvent.Keys.BACKSPACE;
                            case "BrightnessDown": return KeyEvent.Keys.BRIGHTNESS_DOWN;
                            case "BrightnessUp": return KeyEvent.Keys.BRIGHTNESS_UP;
                            case "BrowserBack": return KeyEvent.Keys.BROWSER_BACK;
                            case "BrowserFavorites": return KeyEvent.Keys.BROWSER_FAVORITES;
                            case "BrowserForward": return KeyEvent.Keys.BROWSER_FORWARD;
                            case "BrowserHome": return KeyEvent.Keys.BROWSER_HOME;
                            case "BrowserRefresh": return KeyEvent.Keys.BROWSER_REFRESH;
                            case "BrowserSearch": return KeyEvent.Keys.BROWSER_SEARCH;
                            case "BrowserStop": return KeyEvent.Keys.BROWSER_STOP;
                            case "Call": return KeyEvent.Keys.CALL;
                            case "Camera": return KeyEvent.Keys.CAMERA;
                            case "CameraFocus": return KeyEvent.Keys.CAMERA_FOCUS;
                            case "Cancel": return KeyEvent.Keys.CANCEL;
                            case "CapsLock": return KeyEvent.Keys.CAPS_LOCK;
                            case "ChannelDown": return KeyEvent.Keys.CHANNEL_DOWN;
                            case "ChannelUp": return KeyEvent.Keys.CHANNEL_UP;
                            case "Clear": return KeyEvent.Keys.CLEAR;
                            case "Clear": return KeyEvent.Keys.CLEAR;
                            case "Close": return KeyEvent.Keys.CLOSE;
                            case "ClosedCaptionToggle": return KeyEvent.Keys.COLOR_F5_BROWN;
                            case "CodeInput": return KeyEvent.Keys.CODE_INPUT;
                            case "ColorF0Red": return KeyEvent.Keys.COLOR_F0_RED;
                            case "ColorF1Green": return KeyEvent.Keys.COLOR_F1_GREEN;
                            case "ColorF2Yellow": return KeyEvent.Keys.COLOR_F2_YELLOW;
                            case "ColorF3Blue": return KeyEvent.Keys.COLOR_F3_BLUE;
                            case "ColorF4Grey": return KeyEvent.Keys.COLOR_F4_GRAY;
                            case "ColorF5Brown": return KeyEvent.Keys.COLOR_F5_BROWN;
                            case "Compose": return KeyEvent.Keys.COMPOSE;
                            case "ContextMenu": return KeyEvent.Keys.CONTEXT_MENU;
                            case "Convert": return KeyEvent.Keys.CONVERT;
                            case "Copy": return KeyEvent.Keys.COPY;
                            case "CrSel": return KeyEvent.Keys.CURSOR_SELECT;
                            case "Cut": return KeyEvent.Keys.CUT;
                            case "DVR": return KeyEvent.Keys.DVR;
                            case "Dead": return KeyEvent.Keys.DEAD;
                            case "Decimal": return KeyEvent.Keys.DECIMAL;
                            case "Delete": return KeyEvent.Keys.DELETE;
                            case "Dimmer": return KeyEvent.Keys.DIMMER;
                            case "DisplaySwap": return KeyEvent.Keys.DISPLAY_SWAP;
                            case "Divide": return KeyEvent.Keys.DIVIDE;
                            case "Eisu": return KeyEvent.Keys.EISU;
                            case "Eject": return KeyEvent.Keys.EJECT;
                            case "End": return KeyEvent.Keys.END;
                            case "EndCall": return KeyEvent.Keys.END_CALL;
                            case "Enter": return KeyEvent.Keys.ENTER;
                            case "EraseEof": return KeyEvent.Keys.ERASE_END_OF_FIELD;
                            case "Escape": return KeyEvent.Keys.ESCAPE;
                            case "ExSel": return KeyEvent.Keys.EXTEND_SELECT;
                            case "Execute": return KeyEvent.Keys.EXECUTE;
                            case "Exit": return KeyEvent.Keys.EXIT;
                            case "F1": return KeyEvent.Keys.F1;
                            case "F2": return KeyEvent.Keys.F2;
                            case "F3": return KeyEvent.Keys.F3;
                            case "F4": return KeyEvent.Keys.F4;
                            case "F5": return KeyEvent.Keys.F5;
                            case "F6": return KeyEvent.Keys.F6;
                            case "F7": return KeyEvent.Keys.F7;
                            case "F8": return KeyEvent.Keys.F8;
                            case "F9": return KeyEvent.Keys.F9;
                            case "F10": return KeyEvent.Keys.F10;
                            case "F11": return KeyEvent.Keys.F11;
                            case "F12": return KeyEvent.Keys.F12;
                            case "F13": return KeyEvent.Keys.F13;
                            case "F14": return KeyEvent.Keys.F14;
                            case "F15": return KeyEvent.Keys.F15;
                            case "F16": return KeyEvent.Keys.F16;
                            case "F17": return KeyEvent.Keys.F17;
                            case "F18": return KeyEvent.Keys.F18;
                            case "F19": return KeyEvent.Keys.F19;
                            case "F20": return KeyEvent.Keys.F20;
                            case "F21": return KeyEvent.Keys.F21;
                            case "F22": return KeyEvent.Keys.F22;
                            case "F23": return KeyEvent.Keys.F23;
                            case "F24": return KeyEvent.Keys.F24;
                            case "FavoriteClear0": return KeyEvent.Keys.FAVORITE_CLEAR0;
                            case "FavoriteClear1": return KeyEvent.Keys.FAVORITE_CLEAR1;
                            case "FavoriteClear2": return KeyEvent.Keys.FAVORITE_CLEAR2;
                            case "FavoriteClear3": return KeyEvent.Keys.FAVORITE_CLEAR3;
                            case "FavoriteRecall0": return KeyEvent.Keys.FAVORITE_RECALL0;
                            case "FavoriteRecall1": return KeyEvent.Keys.FAVORITE_RECALL1;
                            case "FavoriteRecall2": return KeyEvent.Keys.FAVORITE_RECALL2;
                            case "FavoriteRecall3": return KeyEvent.Keys.FAVORITE_RECALL3;
                            case "FavoriteStore0": return KeyEvent.Keys.FAVORITE_STORE0;
                            case "FavoriteStore1": return KeyEvent.Keys.FAVORITE_STORE1;
                            case "FavoriteStore2": return KeyEvent.Keys.FAVORITE_STORE2;
                            case "FavoriteStore3": return KeyEvent.Keys.FAVORITE_STORE3;
                            case "FinalMode": return KeyEvent.Keys.FINAL_MODE;
                            case "Find": return KeyEvent.Keys.FIND;
                            case "Finish": return KeyEvent.Keys.FINISH;
                            case "Fn": return KeyEvent.Keys.FUNCTION;
                            case "FnLock": return KeyEvent.Keys.FUNCTION_LOCK;
                            case "GoBack": return KeyEvent.Keys.GO_BACK;
                            case "GoHome": return KeyEvent.Keys.GO_HOME;
                            case "GroupFirst": return KeyEvent.Keys.GROUP_FIRST;
                            case "GroupLast": return KeyEvent.Keys.GROUP_LAST;
                            case "GroupNext": return KeyEvent.Keys.GROUP_NEXT;
                            case "GroupPrevious": return KeyEvent.Keys.GROUP_PREVIOUS;
                            case "Guide": return KeyEvent.Keys.GUIDE;
                            case "GuideNextDay": return KeyEvent.Keys.GUIDE_NEXT_DAY;
                            case "GuidePreviousDay": return KeyEvent.Keys.GUIDE_PREVIOUS_DAY;
                            case "HangulMode": return KeyEvent.Keys.HANGUL_MODE;
                            case "HanjaMode": return KeyEvent.Keys.HANJA_MODE;
                            case "Hankaku": return KeyEvent.Keys.HANKAKU;
                            case "HeadsetHook": return KeyEvent.Keys.HEADSET_HOOK;
                            case "Help": return KeyEvent.Keys.HELP;
                            case "Hibernate": return KeyEvent.Keys.HIBERNATE;
                            case "Hiragana": return KeyEvent.Keys.HIRAGANA;
                            case "HiraganaKatakana": return KeyEvent.Keys.HIRAGANA_KATAKANA;
                            case "Home": return KeyEvent.Keys.HOME;
                            case "Hyper": return KeyEvent.Keys.HYPER;
                            case "Info": return KeyEvent.Keys.INFORMATION;
                            case "Insert": return KeyEvent.Keys.INSERT;
                            case "InstantReplay": return KeyEvent.Keys.INSTANT_REPLAY;
                            case "JunjaMode": return KeyEvent.Keys.JUNJA_MODE;
                            case "KanaMode": return KeyEvent.Keys.KANA_MODE;
                            case "KanjiMode": return KeyEvent.Keys.KANJI_MODE;
                            case "Katakana": return KeyEvent.Keys.KATAKANA;
                            case "Key11": return KeyEvent.Keys.KEY11;
                            case "Key12": return KeyEvent.Keys.KEY12;
                            case "LastNumberRedial": return KeyEvent.Keys.LAST_NUMBER_REDIAL;
                            case "LaunchApplication1": return KeyEvent.Keys.LAUNCH_APPLICATION1;
                            case "LaunchApplication10": return KeyEvent.Keys.LAUNCH_APPLICATION10;
                            case "LaunchApplication11": return KeyEvent.Keys.LAUNCH_APPLICATION11;
                            case "LaunchApplication12": return KeyEvent.Keys.LAUNCH_APPLICATION12;
                            case "LaunchApplication13": return KeyEvent.Keys.LAUNCH_APPLICATION13;
                            case "LaunchApplication14": return KeyEvent.Keys.LAUNCH_APPLICATION14;
                            case "LaunchApplication15": return KeyEvent.Keys.LAUNCH_APPLICATION15;
                            case "LaunchApplication16": return KeyEvent.Keys.LAUNCH_APPLICATION16;
                            case "LaunchApplication2": return KeyEvent.Keys.LAUNCH_APPLICATION2;
                            case "LaunchApplication3": return KeyEvent.Keys.LAUNCH_APPLICATION3;
                            case "LaunchApplication4": return KeyEvent.Keys.LAUNCH_APPLICATION4;
                            case "LaunchApplication5": return KeyEvent.Keys.LAUNCH_APPLICATION5;
                            case "LaunchApplication6": return KeyEvent.Keys.LAUNCH_APPLICATION6;
                            case "LaunchApplication7": return KeyEvent.Keys.LAUNCH_APPLICATION7;
                            case "LaunchApplication8": return KeyEvent.Keys.LAUNCH_APPLICATION8;
                            case "LaunchApplication9": return KeyEvent.Keys.LAUNCH_APPLICATION9;
                            case "LaunchCalculator": return KeyEvent.Keys.LAUNCH_CALCULATOR;
                            case "LaunchContacts": return KeyEvent.Keys.LAUNCH_CONTACTS;
                            case "LaunchMail": return KeyEvent.Keys.LAUNCH_MAIL;
                            case "LaunchMediaPlayer": return KeyEvent.Keys.LAUNCH_MEDIA_PLAYER;
                            case "LaunchMusicPlayer": return KeyEvent.Keys.LAUNCH_MUSIC_PLAYER;
                            case "LaunchMyComputer": return KeyEvent.Keys.LAUNCH_MY_COMPUTER;
                            case "LaunchPhone": return KeyEvent.Keys.LAUNCH_PHONE;
                            case "LaunchScreenSaver": return KeyEvent.Keys.LAUNCH_SCREEN_SAVER;
                            case "LaunchSpreadsheet": return KeyEvent.Keys.LAUNCH_SPREADSHEET;
                            case "LaunchWebBrowser": return KeyEvent.Keys.LAUNCH_WEB_BROWSER;
                            case "LaunchWebCam": return KeyEvent.Keys.LAUNCH_WEB_CAMERA;
                            case "LaunchWordProcessor": return KeyEvent.Keys.LAUNCH_WORD_PROCESSOR;
                            case "Link": return KeyEvent.Keys.LINK;
                            case "ListProgram": return KeyEvent.Keys.LIST_PROGRAM;
                            case "LiveContent": return KeyEvent.Keys.LIVE_CONTENT;
                            case "Lock": return KeyEvent.Keys.LOCK;
                            case "LogOff": return KeyEvent.Keys.LOG_OFF;
                            case "MailForward": return KeyEvent.Keys.MAIL_FORWARD;
                            case "MailReply": return KeyEvent.Keys.MAIL_REPLY;
                            case "MailSend": return KeyEvent.Keys.MAIL_SEND;
                            case "MannerMode": return KeyEvent.Keys.MANNER_MODE;
                            case "MediaApps": return KeyEvent.Keys.MEDIA_APPLICATIONS;
                            case "MediaAudioTrack": return KeyEvent.Keys.MEDIA_AUDIO_TRACK;
                            case "MediaFastForward": return KeyEvent.Keys.MEDIA_FAST_FORWARD;
                            case "MediaLast": return KeyEvent.Keys.MEDIA_LAST;
                            case "MediaPlay": return KeyEvent.Keys.MEDIA_PLAY;
                            case "MediaPlayPause": return KeyEvent.Keys.MEDIA_PLAY_PAUSE;
                            case "MediaRecord": return KeyEvent.Keys.MEDIA_RECORD;
                            case "MediaRewind": return KeyEvent.Keys.MEDIA_REWIND;
                            case "MediaSkipBackward": return KeyEvent.Keys.MEDIA_SKIP_BACKWARD;
                            case "MediaSkipForward": return KeyEvent.Keys.MEDIA_SKIP_FORWARD;
                            case "MediaStepBackward": return KeyEvent.Keys.MEDIA_STEP_BACKWARD;
                            case "MediaStepForward": return KeyEvent.Keys.MEDIA_STEP_FORWARD;
                            case "MediaStop": return KeyEvent.Keys.MEDIA_STOP;
                            case "MediaTopMenu": return KeyEvent.Keys.MEDIA_TOP_MENU;
                            case "MediaTrackNext": return KeyEvent.Keys.MEDIA_TRACK_NEXT;
                            case "MediaTrackPrevious": return KeyEvent.Keys.MEDIA_TRACK_PREVIOUS;
                            case "Meta": return KeyEvent.Keys.META;
                            case "MicrophoneToggle": return KeyEvent.Keys.MICROPHONE_TOGGLE;
                            case "MicrophoneVolumeDown": return KeyEvent.Keys.MICROPHONE_VOLUME_DOWN;
                            case "MicrophoneVolumeMute": return KeyEvent.Keys.MICROPHONE_VOLUME_MUTE;
                            case "MicrophoneVolumeUp": return KeyEvent.Keys.MICROPHONE_VOLUME_UP;
                            case "ModeChange": return KeyEvent.Keys.MODE_CHANGE;
                            case "Multiply": return KeyEvent.Keys.MULTIPLY;
                            case "NavigateIn": return KeyEvent.Keys.NAVIGATE_IN;
                            case "NavigateNext": return KeyEvent.Keys.NAVIGATE_NEXT;
                            case "NavigateOut": return KeyEvent.Keys.NAVIGATE_OUT;
                            case "NavigatePrevious": return KeyEvent.Keys.NAVIGATE_PREVIOUS;
                            case "New": return KeyEvent.Keys.NEW;
                            case "NextCandidate": return KeyEvent.Keys.NEXT_CANDIDATE;
                            case "NextFavoriteChannel": return KeyEvent.Keys.NEXT_FAVORITE_CHANNEL;
                            case "NextUserProfile": return KeyEvent.Keys.NEXT_USER_PROFILE;
                            case "NonConvert": return KeyEvent.Keys.NON_CONVERT;
                            case "Notification": return KeyEvent.Keys.NOTIFICATION;
                            case "NumLock": return KeyEvent.Keys.NUMBER_LOCK;
                            case "OnDemand": return KeyEvent.Keys.ON_DEMAND;
                            case "Open": return KeyEvent.Keys.OPEN;
                            case "PageDown": return KeyEvent.Keys.PAGE_DOWN;
                            case "PageUp": return KeyEvent.Keys.PAGE_UP;
                            case "Pairing": return KeyEvent.Keys.PAIRING;
                            case "Paste": return KeyEvent.Keys.PASTE;
                            case "Pause": return KeyEvent.Keys.PAUSE;
                            case "PinPDown": return KeyEvent.Keys.PIN_P_DOWN;
                            case "PinPMove": return KeyEvent.Keys.PIN_P_MOVE;
                            case "PinPToggle": return KeyEvent.Keys.PIN_P_TOGGLE;
                            case "PinPUp": return KeyEvent.Keys.PIN_P_UP;
                            case "Play": return KeyEvent.Keys.PLAY;
                            case "PlaySpeedDown": return KeyEvent.Keys.PLAY_SPEED_DOWN;
                            case "PlaySpeedReset": return KeyEvent.Keys.PLAY_SPEED_RESET;
                            case "PlaySpeedUp": return KeyEvent.Keys.PLAY_SPEED_UP;
                            case "Power": return KeyEvent.Keys.POWER;
                            case "PowerOff": return KeyEvent.Keys.POWER_OFF;
                            case "PreviousCandidate": return KeyEvent.Keys.PREVIOUS_CANDIDATE;
                            case "Print": return KeyEvent.Keys.PRINT;
                            case "PrintScreen": return KeyEvent.Keys.PRINT_SCREEN;
                            case "Process": return KeyEvent.Keys.PROCESS;
                            case "Props": return KeyEvent.Keys.PROPERTIES;
                            case "RandomToggle": return KeyEvent.Keys.RANDOM_TOGGLE;
                            case "RcLowBattery": return KeyEvent.Keys.REMOTE_CONTROL_LOW_BATTERY;
                            case "RecordSpeedNext": return KeyEvent.Keys.RECORD_SPEED_NEXT;
                            case "Redo": return KeyEvent.Keys.REDO;
                            case "RfBypass": return KeyEvent.Keys.RADIO_FREQUENCY_BYPASS;
                            case "Romaji": return KeyEvent.Keys.ROMAJI;
                            case "STBInput": return KeyEvent.Keys.SET_TOP_BOX_INPUT;
                            case "STBPower": return KeyEvent.Keys.SET_TOP_BOX_POWER;
                            case "Save": return KeyEvent.Keys.SAVE;
                            case "ScanChannelsToggle": return KeyEvent.Keys.SCAN_CHANNELS_TOGGLE;
                            case "ScreenModeNext": return KeyEvent.Keys.SCREEN_MODE_NEXT;
                            case "ScrollLock": return KeyEvent.Keys.SCROLL_LOCK;
                            case "Select": return KeyEvent.Keys.SELECT;
                            case "Separator": return KeyEvent.Keys.SEPARATOR;
                            case "Settings": return KeyEvent.Keys.SETTINGS;
                            case "SingleCandidate": return KeyEvent.Keys.SINGLE_CANDIDATE;
                            case "Soft1": return KeyEvent.Keys.SOFT1;
                            case "Soft2": return KeyEvent.Keys.SOFT2;
                            case "Soft3": return KeyEvent.Keys.SOFT3;
                            case "Soft4": return KeyEvent.Keys.SOFT4;
                            case "SpeechCorrectionList": return KeyEvent.Keys.SPEECH_CORRECTION_LIST;
                            case "SpeechInputToggle": return KeyEvent.Keys.SPEECH_INPUT_TOGGLE;
                            case "SpellCheck": return KeyEvent.Keys.SPELL_CHECK;
                            case "SplitScreenToggle": return KeyEvent.Keys.SPLIT_SCREEN_TOGGLE;
                            case "Standby": return KeyEvent.Keys.STANDBY;
                            case "Subtitle": return KeyEvent.Keys.SUBTITLE;
                            case "Subtract": return KeyEvent.Keys.SUBTRACT;
                            case "Super": return KeyEvent.Keys.SUPER;
                            case "Symbol": return KeyEvent.Keys.SYMBOL;
                            case "SymbolLock": return KeyEvent.Keys.SYMBOL_LOCK;
                            case "TV": return KeyEvent.Keys.TV;
                            case "TV3DMode": return KeyEvent.Keys.TV_3D_MODE;
                            case "TVAntennaCable": return KeyEvent.Keys.TV_ANTENNA_CABLE;
                            case "TVAudioDescription": return KeyEvent.Keys.TV_AUDIO_DESCRIPTION;
                            case "TVAudioDescriptionMixDown": return KeyEvent.Keys.TV_AUDIO_DESCRIPTION_MIX_DOWN;
                            case "TVAudioDescriptionMixUp": return KeyEvent.Keys.TV_AUDIO_DESCRIPTION_MIX_UP;
                            case "TVContentsMenu": return KeyEvent.Keys.TV_CONTENTS_MENU;
                            case "TVDataService": return KeyEvent.Keys.TV_DATA_SERVICE;
                            case "TVInput": return KeyEvent.Keys.TV_INPUT;
                            case "TVInputComponent1": return KeyEvent.Keys.TV_INPUT_COMPONENT1;
                            case "TVInputComponent2": return KeyEvent.Keys.TV_INPUT_COMPONENT2;
                            case "TVInputComposite1": return KeyEvent.Keys.TV_INPUT_COMPOSITE1;
                            case "TVInputComposite2": return KeyEvent.Keys.TV_INPUT_COMPOSITE2;
                            case "TVInputHDMI1": return KeyEvent.Keys.TV_INPUT_HDMI1;
                            case "TVInputHDMI2": return KeyEvent.Keys.TV_INPUT_HDMI2;
                            case "TVInputHDMI3": return KeyEvent.Keys.TV_INPUT_HDMI3;
                            case "TVInputHDMI4": return KeyEvent.Keys.TV_INPUT_HDMI4;
                            case "TVInputVGA1": return KeyEvent.Keys.TV_INPUT_VGA1;
                            case "TVMediaContext": return KeyEvent.Keys.TV_MEDIA_CONTEXT;
                            case "TVNetwork": return KeyEvent.Keys.TV_NETWORK;
                            case "TVNumberEntry": return KeyEvent.Keys.TV_NUMBER_ENTRY;
                            case "TVPower": return KeyEvent.Keys.TV_POWER;
                            case "TVRadioService": return KeyEvent.Keys.TV_RADIO_SERVICE;
                            case "TVSatellite": return KeyEvent.Keys.TV_SATELLITE;
                            case "TVSatelliteBS": return KeyEvent.Keys.TV_SATELLITE_BROADCAST;
                            case "TVSatelliteCS": return KeyEvent.Keys.TV_SATELLITE_COMMUNICATION;
                            case "TVSatelliteToggle": return KeyEvent.Keys.TV_SATELLITE_TOGGLE;
                            case "TVTerrestrialAnalog": return KeyEvent.Keys.TV_TERRESTRIAL_ANALOG;
                            case "TVTerrestrialDigital": return KeyEvent.Keys.TV_TERRESTRIAL_DIGITAL;
                            case "TVTimer": return KeyEvent.Keys.TV_TIMER;
                            case "Tab": return KeyEvent.Keys.TAB;case "Teletext": return KeyEvent.Keys.TELETEXT;
                            case "Undo": return KeyEvent.Keys.UNDO;
                            case "Unidentified": return KeyEvent.Keys.UNIDENTIFIED;
                            case "VideoModeNext": return KeyEvent.Keys.VIDEO_MODE_NEXT;
                            case "VoiceDial": return KeyEvent.Keys.VOICE_DIAL;
                            case "WakeUp": return KeyEvent.Keys.WAKE_UP;
                            case "Wink": return KeyEvent.Keys.WINK;
                            case "Zenkaku": return KeyEvent.Keys.ZENKAKU;
                            case "ZenkakuHanaku": return KeyEvent.Keys.ZENKAKU_HANAKU;
                            case "ZoomIn": return KeyEvent.Keys.ZOOM_IN;
                            case "ZoomOut": return KeyEvent.Keys.ZOOM_OUT;
                            case "ZoomToggle": return KeyEvent.Keys.ZOOM_TOGGLE;
                            case '0': return KeyEvent.Keys.DIGIT0;
                            case '1': return KeyEvent.Keys.DIGIT1;
                            case '2': return KeyEvent.Keys.DIGIT2;
                            case '3': return KeyEvent.Keys.DIGIT3;
                            case '4': return KeyEvent.Keys.DIGIT4;
                            case '5': return KeyEvent.Keys.DIGIT5;
                            case '6': return KeyEvent.Keys.DIGIT6;
                            case '7': return KeyEvent.Keys.DIGIT7;
                            case '8': return KeyEvent.Keys.DIGIT8;
                            case '9': return KeyEvent.Keys.DIGIT9;
                            case 'A': return KeyEvent.Keys.UPPERCASE_A; case 'a': return KeyEvent.Keys.LOWERCASE_A;
                            case 'B': return KeyEvent.Keys.UPPERCASE_B; case 'b': return KeyEvent.Keys.LOWERCASE_B;
                            case 'C': return KeyEvent.Keys.UPPERCASE_C; case 'c': return KeyEvent.Keys.LOWERCASE_C;
                            case 'D': return KeyEvent.Keys.UPPERCASE_D; case 'd': return KeyEvent.Keys.LOWERCASE_D;
                            case 'E': return KeyEvent.Keys.UPPERCASE_E; case 'e': return KeyEvent.Keys.LOWERCASE_E;
                            case 'F': return KeyEvent.Keys.UPPERCASE_F; case 'f': return KeyEvent.Keys.LOWERCASE_F;
                            case 'G': return KeyEvent.Keys.UPPERCASE_G; case 'g': return KeyEvent.Keys.LOWERCASE_G;
                            case 'H': return KeyEvent.Keys.UPPERCASE_H; case 'h': return KeyEvent.Keys.LOWERCASE_H;
                            case 'I': return KeyEvent.Keys.UPPERCASE_I; case 'i': return KeyEvent.Keys.LOWERCASE_I;
                            case 'J': return KeyEvent.Keys.UPPERCASE_J; case 'j': return KeyEvent.Keys.LOWERCASE_J;
                            case 'K': return KeyEvent.Keys.UPPERCASE_K; case 'k': return KeyEvent.Keys.LOWERCASE_K;
                            case 'L': return KeyEvent.Keys.UPPERCASE_L; case 'l': return KeyEvent.Keys.LOWERCASE_L;
                            case 'M': return KeyEvent.Keys.UPPERCASE_M; case 'm': return KeyEvent.Keys.LOWERCASE_M;
                            case 'N': return KeyEvent.Keys.UPPERCASE_N; case 'n': return KeyEvent.Keys.LOWERCASE_N;
                            case 'O': return KeyEvent.Keys.UPPERCASE_O; case 'o': return KeyEvent.Keys.LOWERCASE_O;
                            case 'P': return KeyEvent.Keys.UPPERCASE_P; case 'p': return KeyEvent.Keys.LOWERCASE_P;
                            case 'Q': return KeyEvent.Keys.UPPERCASE_Q; case 'q': return KeyEvent.Keys.LOWERCASE_Q;
                            case 'R': return KeyEvent.Keys.UPPERCASE_R; case 'r': return KeyEvent.Keys.LOWERCASE_R;
                            case 'S': return KeyEvent.Keys.UPPERCASE_S; case 's': return KeyEvent.Keys.LOWERCASE_S;
                            case 'T': return KeyEvent.Keys.UPPERCASE_T; case 't': return KeyEvent.Keys.LOWERCASE_T;
                            case 'U': return KeyEvent.Keys.UPPERCASE_U; case 'u': return KeyEvent.Keys.LOWERCASE_U;
                            case 'V': return KeyEvent.Keys.UPPERCASE_V; case 'v': return KeyEvent.Keys.LOWERCASE_V;
                            case 'W': return KeyEvent.Keys.UPPERCASE_W; case 'w': return KeyEvent.Keys.LOWERCASE_W;
                            case 'X': return KeyEvent.Keys.UPPERCASE_X; case 'x': return KeyEvent.Keys.LOWERCASE_X;
                            case 'Y': return KeyEvent.Keys.UPPERCASE_Y; case 'y': return KeyEvent.Keys.LOWERCASE_Y;
                            case 'Z': return KeyEvent.Keys.UPPERCASE_Z; case 'z': return KeyEvent.Keys.LOWERCASE_Z;

                            case '+': return KeyEvent.Keys.ADD;
                            case '.': return KeyEvent.Keys.DECIMAL;
                            case '/': return KeyEvent.Keys.DIVIDE;
                            case '=': return KeyEvent.Keys.EQUAL;
                            case '*': return KeyEvent.Keys.MULTIPLY;
                            case '-': return KeyEvent.Keys.SUBTRACT;

                            case '`': return KeyEvent.Keys.QUOTE;
                            case '"': return KeyEvent.Keys.DOUBLE_QUOTE;
                            case '\'': return KeyEvent.Keys.SINGLE_QUOTE
                        }
                    }
                };

                static KeyPressEvent = class KeyPressEvent extends Events.KeyEvent {};
                static KeyPushEvent = class KeyPushEvent extends Events.KeyEvent {};
                static KeyReleaseEvent = class KeyReleaseEvent extends Events.KeyEvent {};

                // Pointer Event
                static PointerEvent = class PointerEvent extends Events.Event {
                    // Class > (Coordinates, Pointer Coordinate List)
                    static Coordinates = class PointerCoordinates { x; y; constructor(x, y) { this.x = x; this.y = y } };
                    static PointerCoordinateList;

                    // Initialization > (Coordinates, X, Y)
                    coordinates = new PointerEvent.PointerCoordinateList;

                    get x() { return this.coordinates[0].x }
                    set x(coordinate) { return (this.coordinates[0].x = coordinate) }

                    get y() { return this.coordinates[0].y }
                    set y(coordinate) { return (this.coordinates[0].y = coordinate) }

                    // [Constructor]
                    constructor(x, y) { super(); arguments.length && this.addCoordinates(Number(x), y ?? +0) }

                    // Function > (Add, ...) Coordinates
                    addCoordinates(x, y) { this.coordinates.push(new PointerEvent.Coordinates(x, y)) }
                };

                static PointerMoveEvent = class PointerMoveEvent extends Events.PointerEvent {};
                static PointerPressEvent = class PointerPressEvent extends Events.PointerEvent {};
                static PointerPushEvent = class PointerPushEvent extends Events.PointerEvent {};
                static PointerReleaseEvent = class PointerReleaseEvent extends Events.PointerEvent {};

                // Resource Load Event
                static ResourceLoadEvent = class ResourceLoadEvent extends Events.Event { loaded = false; url; constructor(url) { super(); this.url = url ?? null } };

                // Resize Event
                static ResizeEvent = class ResizeEvent extends Events.Event {
                    // Initialization > (Current, Recent) (Height, Width)
                    currentHeight; currentWidth;
                    recentHeight = +0; recentWidth = +0;

                    get currentHeight() { return this.currentHeight }
                    set currentHeight(size) { this.recentHeight = this.currentHeight; return (this.currentHeight = size) }
                    get currentWidth() { return this.currentWidth }
                    set currentWidth(size) { this.recentWidth = this.currentWidth; return (this.currentWidth = size) }

                    // [Constructor]
                    constructor(height, width) { super(); this.currentHeight = height ?? +0; this.currentWidth = width ?? +0 }
                };

                // Scroll Wheel Event
                static ScrollWheelEvent = class ScrollWheelEvent extends Events.Event {
                    // Initialization > Direction
                    // : Constant > Directions
                    direction;
                    static Directions;

                    // [Constructor]
                    constructor(direction) { this.direction = direction ?? null }
                };
        });

        /* Graphics
                --- NOTE (Lapys) -> Anything not suggestive of 2D graphics (or using the Canvas2D API) is just for laughs :P
                --- WARN (Lapys) -> Might have implemented multiple-buffering wrongly :<
        */
        const Graphics = (Game.Graphics = class Graphics {
            /* Constant > ... */
            static CompositeOperations;
            static Colors;
            static Filters;
            static GradientPatterns;
            static LineCaps;
            static LineJoins;
            static Positions;

            /* Initialization */
            // : [Rendering] (Buffer List ..., Current Buffer Index, Render ..., Scene)
            bufferList = new Graphics.BufferList;
            currentBufferIndex = -1;
            render; renderer; // NOTE (Lapys) -> Technically a `Buffer` structure.

            // : [Settings]
            get compositeOperation() { switch (this.renderer.globalCompositeOperation) {
                case "color": return Graphics.CompositeOperations.COLOR;
                case "color-burn": return Graphics.CompositeOperations.COLOR_BURN;
                case "color-dodge": return Graphics.CompositeOperations.COLOR_DODGE;
                case "copy": return Graphics.CompositeOperations.COPY;
                case "darken": return Graphics.CompositeOperations.DARKEN;
                case "destination-atop": return Graphics.CompositeOperations.DESTINATION_ATOP;
                case "destination-in": return Graphics.CompositeOperations.DESTINATION_IN;
                case "destination-over": return Graphics.CompositeOperations.DESTINATION_OVER;
                case "destination-out": return Graphics.CompositeOperations.DESTINATION_OUT;
                case "difference": return Graphics.CompositeOperations.DIFFERENCE;
                case "exclusion": return Graphics.CompositeOperations.EXCLUSION;
                case "hard-light": return Graphics.CompositeOperations.HARD_LIGHT;
                case "hue": return Graphics.CompositeOperations.HUE;
                case "lighten": return Graphics.CompositeOperations.LIGHTEN;
                case "lighter": return Graphics.CompositeOperations.LIGHTER;
                case "luminosity": return Graphics.CompositeOperations.LUMINOSITY;
                case "multiply": return Graphics.CompositeOperations.MULTIPLY;
                case "overlay": return Graphics.CompositeOperations.OVERLAY;
                case "saturation": return Graphics.CompositeOperations.SATURATION;
                case "screen": return Graphics.CompositeOperations.SCREEN;
                case "soft-light": return Graphics.CompositeOperations.SOFT_LIGHT;
                case "source-atop": return Graphics.CompositeOperations.SOURCE_ATOP;
                case "source-in": return Graphics.CompositeOperations.SOURCE_IN;
                case "source-over": return Graphics.CompositeOperations.SOURCE_OVER;
                case "source-out": return Graphics.CompositeOperations.SOURCE_OUT;
                case "xor": return Graphics.CompositeOperations.XOR
            } }
            set compositeOperation(operation) { switch (operation) {
                case Graphics.CompositeOperations.COLOR: this.renderer.globalCompositeOperation = "color"; return Graphics.CompositeOperations.COLOR;
                case Graphics.CompositeOperations.COLOR_BURN: this.renderer.globalCompositeOperation = "color-burn"; return Graphics.CompositeOperations.COLOR_BURN;
                case Graphics.CompositeOperations.COLOR_DODGE: this.renderer.globalCompositeOperation = "color-dodge"; return Graphics.CompositeOperations.COLOR_DODGE;
                case Graphics.CompositeOperations.COPY: this.renderer.globalCompositeOperation = "copy"; return Graphics.CompositeOperations.COPY;
                case Graphics.CompositeOperations.DARKEN: this.renderer.globalCompositeOperation = "darken"; return Graphics.CompositeOperations.DARKEN;
                case Graphics.CompositeOperations.DESTINATION_ATOP: this.renderer.globalCompositeOperation = "destination-atop"; return Graphics.CompositeOperations.DESTINATION_ATOP;
                case Graphics.CompositeOperations.DESTINATION_IN: this.renderer.globalCompositeOperation = "destination-in"; return Graphics.CompositeOperations.DESTINATION_IN;
                case Graphics.CompositeOperations.DESTINATION_OVER: this.renderer.globalCompositeOperation = "destination-over"; return Graphics.CompositeOperations.DESTINATION_OVER;
                case Graphics.CompositeOperations.DESTINATION_OUT: this.renderer.globalCompositeOperation = "destination-out"; return Graphics.CompositeOperations.DESTINATION_OUT;
                case Graphics.CompositeOperations.DIFFERENCE: this.renderer.globalCompositeOperation = "difference"; return Graphics.CompositeOperations.DIFFERENCE;
                case Graphics.CompositeOperations.EXCLUSION: this.renderer.globalCompositeOperation = "exclusion"; return Graphics.CompositeOperations.EXCLUSION;
                case Graphics.CompositeOperations.HARD_LIGHT: this.renderer.globalCompositeOperation = "hard-light"; return Graphics.CompositeOperations.HARD_LIGHT;
                case Graphics.CompositeOperations.HUE: this.renderer.globalCompositeOperation = "hue"; return Graphics.CompositeOperations.HUE;
                case Graphics.CompositeOperations.LIGHTEN: this.renderer.globalCompositeOperation = "lighten"; return Graphics.CompositeOperations.LIGHTEN;
                case Graphics.CompositeOperations.LIGHTER: this.renderer.globalCompositeOperation = "lighter"; return Graphics.CompositeOperations.LIGHTER;
                case Graphics.CompositeOperations.LUMINOSITY: this.renderer.globalCompositeOperation = "luminosity"; return Graphics.CompositeOperations.LUMINOSITY;
                case Graphics.CompositeOperations.MULTIPLY: this.renderer.globalCompositeOperation = "multiply"; return Graphics.CompositeOperations.MULTIPLY;
                case Graphics.CompositeOperations.OVERLAY: this.renderer.globalCompositeOperation = "overlay"; return Graphics.CompositeOperations.OVERLAY;
                case Graphics.CompositeOperations.SATURATION: this.renderer.globalCompositeOperation = "saturation"; return Graphics.CompositeOperations.SATURATION;
                case Graphics.CompositeOperations.SCREEN: this.renderer.globalCompositeOperation = "screen"; return Graphics.CompositeOperations.SCREEN;
                case Graphics.CompositeOperations.SOFT_LIGHT: this.renderer.globalCompositeOperation = "soft-light"; return Graphics.CompositeOperations.SOFT_LIGHT;
                case Graphics.CompositeOperations.SOURCE_ATOP: this.renderer.globalCompositeOperation = "source-atop"; return Graphics.CompositeOperations.SOURCE_ATOP;
                case Graphics.CompositeOperations.SOURCE_IN: this.renderer.globalCompositeOperation = "source-in"; return Graphics.CompositeOperations.SOURCE_IN;
                case Graphics.CompositeOperations.SOURCE_OVER: this.renderer.globalCompositeOperation = "source-over"; return Graphics.CompositeOperations.SOURCE_OVER;
                case Graphics.CompositeOperations.SOURCE_OUT: this.renderer.globalCompositeOperation = "source-out"; return Graphics.CompositeOperations.SOURCE_OUT;
                case Graphics.CompositeOperations.XOR: this.renderer.globalCompositeOperation = "xor"; return Graphics.CompositeOperations.XOR;
            } }

            get opacity() { return +this.renderer.globalAlpha }
            set opacity(range) { return (this.renderer.globalAlpha = Math.wrap(range, 1)) }

            subPixelRendering = true;

            // [Constructor]
            constructor(render) {
                // ...
                this.setBufferCount(2 /* NOTE (Lapys) -> Double buffering. */);
                this.setRender(render ?? new Graphics.Render);

                // Modification > Target > ...
                this.compositeOperation = Graphics.CompositeOperations.SOURCE_OVER
            }

            /* Class */
                // Buffer, Filter, Graphic, Image, Render, Vector --- MINIFY (Lapys)
                static Buffer = class Buffer { render; renderer; constructor(height, width) { this.render = Graphics.Render.apply(Graphics, arguments); this.renderer = new Graphics.Renderer(this.render) } };
                static BufferList = class BufferList extends List {};

                static Filter = class Filter { source; constructor(name, parameters) { if ("none" != (this.source = name ?? "none")) { this.source += '('; for (var iterator = 1, length = arguments.length || 1; iterator ^ length; ++iterator) this.source += arguments[iterator]; this.source += ')' } } toString() { return this.source } };
                static FilterList = class FilterList extends List {};
                static PresetFilter = function PresetFilter(name) { return function PresetFilter(parameters) { return new Graphics.Filter(name, parameters) } };

                static LineCap = class LineCap extends Enumerable {};
                static LineJoin = class LineJoin extends Enumerable {};

                static Image = class Image extends Global.Image { constructor(url) { super(); const image = this; image.src = ""; if (arguments.length) { const target = Events.onready.target; image.src = url; Events.onready.listen(image).invoke(function(event) { if (event.loaded) { image.height = image.naturalHeight; image.width = image.naturalWidth } else image.src = "" }).listen(target) } } };
                static ImagePattern = class ImagePattern extends Graphics.Image {};

                static Render = function Render(height, width) { const render = document.createElement("canvas"); switch (arguments.length) { case 2: render.width = Number(width); case 1: render.height = Number(height) } return render };
                static Renderer = function Renderer(render) { return render.getContext("2d") };

                static Vector = class Vector extends Number { constructor(number) { super(number) } }; // CONSIDER (Lapys) -> Slow, but not dangerously slow. :P

                static Vector1D = class Vector1D extends Graphics.Vector { x; constructor(x) { super(Number.from(x)); this.x = x ?? +0 } static from(coordinates) { return coordinates ? new this(Number.from(coordinates.x)) : new this } };
                static Vector2D = class Vector2D extends Graphics.Vector { x; y; constructor(x, y) { super(Math.sqrt(Number.from((x * x) + (y * y)))); this.x = x ?? +0; this.y = y ?? +0 } static from(coordinates) { return coordinates ? new this(Number.from(coordinates.x), Number.from(coordinates.y)) : new this } };
                static Vector3D = class Vector3D extends Graphics.Vector { x; y; z; constructor(x, y, z) { super(Math.sqrt(Number.from((x * x) + (y * y) + (z * z)))); this.x = x ?? +0; this.y = y ?? +0; this.z = z ?? +0 } static from(coordinates) { return coordinates ? new this(Number.from(coordinates.x), Number.from(coordinates.y), Number.from(coordinates.z)) : new this } };
                static Vector4D = class Vector4D extends Graphics.Vector { w; x; y; z; constructor(x, y, z, w) { super(Math.sqrt(Number.from((w * w) + (x * x) + (y * y) + (z * z)))); this.w = w ?? +0; this.x = x ?? +0; this.y = y ?? +0; this.z = z ?? +0 } static from(coordinates) { return coordinates ? new this(Number.from(coordinates.x), Number.from(coordinates.y), Number.from(coordinates.z), Number.from(coordinates.w)) : new this } };

                // Color
                static Color = class Color {
                    // Class > Color Value
                    static ColorValue = class ColorValue extends Number {};

                    // Initialization > (Alpha, Blue, Green, Red, Value, ...)
                    value = new Color.ColorValue(0x0000000);

                    get alpha() { return this.value >>> 24 }
                    set alpha(range) { this.value &= 0x0FFFFFF; return (this.value |= range ? 0x1000000 : 0x0000000) }
                    get blue() { return this.value & 0xFF }
                    set blue(range) { this.value = new Color.ColorValue(Math.wrap(range, 255) + (this.value & 0x1FFFF00)); return range }
                    get green() { return (this.value >>> 8) & 0xFF }
                    set green(range) { this.value = new Color.ColorValue((-~0x0000FF * Math.wrap(range, 255)) + (this.value & 0x1FF00FF)); return range }
                    get red() { return (this.value >>> 16) & 0xFF }
                    set red(range) { this.value = new Color.ColorValue((-~0x00FFFF * Math.wrap(range, 255)) + (this.value & 0x100FFFF)); return range }

                    // [Constructor] --- REDACT (Lapys)
                    constructor(red, green, blue, alpha) { this.value = Color.RGBA(red ?? +0, green ?? +0, blue ?? +0, alpha ?? 1) }

                    // Function > (CMYK, Hex, HSL, RGB, RGBA, ...) --- MINIFY (Lapys) --- REDACT (Lapys)
                    static CMYK(cyan, magenta, yellow, black) { const normalized = {black: Math.abs(black) / 100, cyan: Math.abs(cyan) / 100, magenta: Math.abs(magenta) / 100, yellow: Math.abs(yellow) / 100}; return Color.RGB(Math.ceil(255 * (1 - normalized.cyan) * (1 - normalized.black)), Math.ceil(255 * (1 - normalized.magenta) * (1 - normalized.black)), Math.ceil(255 * (1 - normalized.yellow) * (1 - normalized.black))) }
                    static Hex(red, green, blue) { return Color.RGB(red, green, blue) }
                    static RGB(red, green, blue) { return Color.RGBA(red, green, blue, 1) }
                    static RGBA(red, green, blue, alpha) { return new Color.ColorValue(Math.wrap(blue, 0xFF) + (-~0x0000FF * Math.wrap(green, 0xFF)) + (-~0x00FFFF * Math.wrap(red, 0xFF)) + (alpha << 0x18)) }
                    static HSL(hue, saturation, luminosity) { // UPDATE (Lapys)
                        let blue, green, red;
                        const normalized = {hue: Math.wrap(Math.abs(hue), 360), luminosity: Math.abs(luminosity) / 100, saturation: Math.abs(saturation) / 100};

                        const C = (1 - Math.abs((normalized.luminosity * 2) - 1)) * normalized.saturation;
                        const X = C * (1 - Math.abs(((normalized.hue / 60) % 2) - 1));
                        const m = normalized.luminosity - (C / 2);

                        if (+0 <= hue && hue < 60) { blue = +0; green = X; red = C }
                        else if (60 <= hue && hue < 120) { blue = +0; green = C; red = X }
                        else if (120 <= hue && hue < 180) { blue = X; green = C; red = +0 }
                        else if (180 <= hue && hue < 240) { blue = C; green = X; red = +0 }
                        else if (240 <= hue && hue < 300) { blue = C; green = +0; red = X }
                        else if (300 <= hue && hue < 360) { blue = x; green = +0; red = C }

                        return Color.RGB((red + m) * 255, (green + m) * 255, (blue + m) * 255, 1)
                    }

                    toString() { return "rgba(" + this.red + ", " + this.green + ", " + this.blue + ", " + this.alpha + ')' }
                    valueOf() { return this.value }
                };

                // ... Coordinates ...
                static Coordinates2D = class Coordinates2D extends Graphics.Vector2D { get w() { return null } set w(coordinate) { return null } get z() { return null } set z(coordinate) { return null } };
                static Coordinates3D = class Coordinates3D extends Graphics.Vector3D { get w() { return null } set w(coordinate) { return null } };
                static Coordinates4D = class Coordinates4D extends Graphics.Vector4D {};

                static DynamicCoordinates = class DynamicCoordinates extends Enumerable {};

                // Gradient ... --- MINIFY (Lapys) (Lapys)
                static GradientPattern = class GradientPattern extends Enumerable {};
                static GradientStop = class GradientStop extends Graphics.Color { range = +0; constructor(red, green, blue, alpha, range) { super(red, green, blue, alpha); this.range = range } get range() { return this.range } set range(range) { return (this.range = range % 2) } };
                static GradientStopList = class GradientStopList extends List { add() { for (var iterator = +0, length = arguments.length; iterator ^ length; ++iterator) GradientStopList.prototype.push.call(this, arguments[iterator]) } getLastStopRange() { const last = this.last; return last ? last.range : +0 } push(stop) { const range = this.getLastStopRange(); List.prototype.push.call(this, stop); (range > stop.range) && List.prototype.sort.call(this, (x, y) => { return (x.range < y.range) * -1 }) } };

                // Graphic ...
                static GraphicCollection = class GraphicCollection extends List {};

                graphics.resolveParameters(parameters)
                static Graphic = class Graphic {
                    // Initialization > (Parameters, ...) --- CONSIDER (Lapys) -> Better way of instantiating these accessors/ mutators?
                    parameters = null;

                    get fillColor() { return null === this.parameters ? null : this.parameters.colors.fill }
                    set fillColor(color) { (null === this.parameters) || (this.parameters.colors.fill = color); return color }
                    get fillGradient() { return null === this.parameters ? null : this.parameters.gradients.fill }
                    get fillOpacity() { return null === this.parameters ? null : this.parameters.opacity.fill }
                    set fillOpacity(opacity) { (null === this.parameters) || (this.parameters.opacity.fill = opacity); return opacity }
                    get fillPattern() { return null === this.parameters ? null : this.parameters.patterns.fill }
                    set fillPattern(image) { (null === this.parameters) || (this.parameters.patterns.fill = image); return image }
                    get lineCap() { return null === this.parameters ? null : this.parameters.line.cap }
                    set lineCap(cap) { (null === this.parameters) || (this.parameters.line.cap = cap); return cap }
                    get lineDashOffset() { return null === this.parameters ? null : this.parameters.line.dashOffset }
                    set lineDashOffset(size) { (null === this.parameters) || (this.parameters.line.dashOffset = size); return size }
                    get lineJoin() { return null === this.parameters ? null : this.parameters.line.join }
                    set lineJoin(join) { (null === this.parameters) || (this.parameters.line.join = join); return join }
                    get lineWidth() { return null === this.parameters ? null : this.parameters.line.width }
                    set lineWidth(size) { (null === this.parameters) || (this.parameters.line.width = size); return size }
                    get rotation() { return null === this.parameters ? null : this.parameters.transforms.rotation.angle }
                    set rotation(angle) { (null === this.parameters) || (this.parameters.transforms.rotation.angle = angle); return angle }
                    get rotationAnchor() { return null === this.parameters ? null : this.parameters.transforms.rotation.anchor }
                    get translation() { return null === this.parameters ? null : this.parameters.transforms.translation }
                    get scale() { return null === this.parameters ? null : this.parameters.transforms.scale }
                    get skew() { return null === this.parameters ? null : this.parameters.transforms.skew }
                    get strokeColor() { return null === this.parameters ? null : this.parameters.colors.stroke }
                    set strokeColor(color) { (null === this.parameters) || (this.parameters.colors.stroke = color); return color }
                    get strokeGradient() { return null === this.parameters ? null : this.parameters.gradients.stroke }
                    get strokeOpacity() { return null === this.parameters ? null : this.parameters.opacity.stroke }
                    set strokeOpacity(opacity) { (null === this.parameters) || (this.parameters.opacity.stroke = opacity); return opacity }
                    get strokePattern() { return null === this.parameters ? null : this.parameters.patterns.stroke }
                    set strokePattern(image) { (null === this.parameters) || (this.parameters.patterns.stroke = image); return image }
                    get x() { return null === this.parameters ? null : this.parameters.coordinates.x }
                    set x(coordinate) { (null === this.parameters) || (this.parameters.coordinates.x = coordinate); return coordinate }
                    get y() { return null === this.parameters ? null : this.parameters.coordinates.y }
                    set y(coordinate) { (null === this.parameters) || (this.parameters.coordinates.y = coordinate); return coordinate }

                    // Class > Parameters ... --- NOTE (Lapys) -> Additional options when parsing a `Graphic` object.
                    static ParametersList = class GraphicParametersList extends List {};
                    static Parameters = class GraphicParameters {
                        // [Constructor]
                        constructor(initialize) { arguments.length || GraphicParameters.from(this, false) }

                        // Function
                            // From --- WARN (Lapys) -> May modify the `parameters` object.
                            static from(parameters, isProxy) {
                                // Evaluation > Evaluation
                                const evaluation = parameters instanceof Graphics.Graphic.Parameters ? parameters : ((arguments.length || 1) == 1 || isProxy ? new Graphics.Graphic.Parameters(null) : parameters);

                                // Function > ...
                                function define(object, identifier, value) { return Global.Object.defineProperty(object, identifier, {configurable: false, enumerable: true, value: value, writable: true}) }
                                function set(destination, source, identifier, value) {
                                    if (Object.hasOwn(source, identifier) && null !== source[identifier]) define(destination, identifier, source[identifier]);
                                    else { define(destination, identifier, value); source[identifier] = value }
                                }

                                /* ... NOTE (Lapys) -> Fill missing data. */ {
                                    // [Colors, Opacity, Patterns]
                                    set(evaluation, parameters, "colors", {}); { set(evaluation.colors, parameters.colors, "fill", null); set(evaluation.colors, parameters.colors, "stroke", null) }
                                    set(evaluation, parameters, "opacity", {}); { set(evaluation.opacity, parameters.opacity, "fill", null); set(evaluation.opacity, parameters.opacity, "stroke", null) }
                                    set(evaluation, parameters, "patterns", {}); { set(evaluation.patterns, parameters.patterns, "fill", null); set(evaluation.patterns, parameters.patterns, "stroke", null) }

                                    // [Gradients]
                                    set(evaluation, parameters, "gradients", {}); {
                                        set(evaluation.gradients, parameters.gradients, "fill", {}); { set(evaluation.gradients.fill, parameters.gradients.fill, "stops", null); set(evaluation.gradients.fill, parameters.gradients.fill, "type", null) }
                                        set(evaluation.gradients, parameters.gradients, "stroke", {}); { set(evaluation.gradients.stroke, parameters.gradients.stroke, "stops", null); set(evaluation.gradients.stroke, parameters.gradients.stroke, "type", null) }
                                    }

                                    // [Line]
                                    set(evaluation, parameters, "line", {}); {
                                        set(evaluation.line, parameters.line, "cap", null);
                                        set(evaluation.line, parameters.line, "dashOffset", null);
                                        set(evaluation.line, parameters.line, "join", null);
                                        set(evaluation.line, parameters.line, "width", null)
                                    }

                                    // [Transforms]
                                    set(evaluation, parameters, "transforms", {}); {
                                        set(evaluation.transforms, parameters.transforms, "rotation", {}); { set(evaluation.transforms.rotation, parameters.transforms.rotation, "anchor", null); set(evaluation.transforms.rotation, parameters.transforms.rotation, "angle", null) }
                                        set(evaluation.transforms, parameters.transforms, "translation", null);
                                        set(evaluation.transforms, parameters.transforms, "scale", null);
                                        set(evaluation.transforms, parameters.transforms, "skew", null)
                                    }

                                    // [...]
                                    set(evaluation, parameters, "coordinates", null);
                                    set(evaluation, parameters, "filters", null);
                                    set(evaluation, parameters, "overlays", null)
                                }

                                /* ... NOTE (Lapys) -> Correct data. */ {
                                    (isProxy && evaluation.colors.fill instanceof Graphics.Color) || (evaluation.colors.fill = Graphics.Colors.TRANSPARENT);
                                    (isProxy && evaluation.colors.stroke instanceof Graphics.Color) || (evaluation.colors.stroke = Graphics.Colors.BLACK);
                                    (isProxy && evaluation.coordinates instanceof Graphics.Coordinates2D) || (evaluation.coordinates = Graphics.Coordinates2D.from(evaluation.coordinates));
                                    (isProxy && evaluation.filters instanceof Graphics.FilterList) || (evaluation.filters = Graphics.FilterList.from(evaluation.filters));
                                    (isProxy && evaluation.gradients.fill.stops instanceof Graphics.GradientStopList) || (evaluation.gradients.fill.stops = Graphics.GradientStopList.from(evaluation.gradients.fill.stops));
                                    (isProxy && evaluation.gradients.stroke.stops instanceof Graphics.GradientStopList) || (evaluation.gradients.stroke.stops = Graphics.GradientStopList.from(evaluation.gradients.stroke.stops));
                                    (isProxy && evaluation.line.cap instanceof Graphics.LineCap) || (evaluation.line.cap = Graphics.LineCaps.BUTT);
                                    (isProxy && evaluation.line.dashOffset instanceof Number) || (evaluation.line.dashOffset = +0);
                                    (isProxy && evaluation.line.join instanceof Graphics.LineJoin) || (evaluation.line.join = Graphics.LineJoins.ROUND);
                                    (isProxy && evaluation.line.width instanceof Number) || (evaluation.line.width = 1);
                                    (isProxy && evaluation.opacity.fill instanceof Number) || (evaluation.opacity.fill = 1);
                                    (isProxy && evaluation.opacity.stroke instanceof Number) || (evaluation.opacity.stroke = 1);
                                    (isProxy && evaluation.overlays instanceof Graphics.Graphic.ParametersList) || (evaluation.overlays = Graphics.Graphic.ParametersList.from(evaluation.overlays));
                                    (isProxy && evaluation.transforms.rotation.anchor instanceof Graphics.Coordinates2D) || (evaluation.transforms.rotation.anchor = Graphics.Coordinates2D.from(evaluation.transforms.rotation.anchor));
                                    (isProxy && evaluation.transforms.rotation.angle instanceof Number) || (evaluation.transforms.rotation.angle = +0);
                                    (isProxy && evaluation.transforms.translation instanceof Graphics.Coordinates2D) || (evaluation.transforms.translation = Graphics.Coordinates2D.from(evaluation.transforms.translation));
                                    (isProxy && evaluation.transforms.scale instanceof Graphics.Vector2D) || (evaluation.transforms.scale = Graphics.Vector2D.from(evaluation.transforms.scale));
                                    (isProxy && evaluation.transforms.skew instanceof Graphics.Vector2D) || (evaluation.transforms.skew = Graphics.Vector2D.from(evaluation.transforms.skew))
                                } Object.assign(parameters, evaluation);

                                // Return
                                return evaluation
                            }

                            // Has ...
                            hasFill() { return this.hasFillColor() || this.hasFillGradient() || this.hasFillPattern() }
                            hasFillColor() { return +Graphics.Colors.TRANSPARENT != +this.colors.fill }
                            hasFillGradient() { return null === this.gradients.fill.type }
                            hasFillPattern() { return null === this.patterns.fill }

                            hasStroke() { return this.hasStrokeColor() || this.hasStrokeGradient() || this.hasStrokePattern() }
                            hasStrokeColor() { return +Graphics.Colors.TRANSPARENT != +this.colors.stroke }
                            hasStrokeGradient() { return null === this.gradients.stroke.type }
                            hasStrokePattern() { return null === this.patterns.stroke }
                    };

                    // Function > Draw
                    draw(renderer, parameters, context) {
                        context.resolveCoordinates(parameters.coordinates);
                        context.resolveCoordinates(parameters.transforms.rotation.anchor);
                        context.resolveCoordinates(parameters.transforms.translation);

                        this.parameters = parameters;
                        renderer.fillStyle = parameters.colors.fill.toString();
                        renderer.filter = parameters.filters.length ? parameters.filters.join(' ') : "none";
                        if (parameters.line.width && Graphics.Colors.TRANSPARENT !== parameters.colors.stroke) {
                            renderer.lineCap = parameters.line.cap;
                            renderer.lineDashOffset = parameters.line.dashOffset;
                            renderer.lineJoin = parameters.line.join;
                            renderer.lineWidth = parameters.line.width;

                            renderer.strokeStyle = parameters.colors.stroke.toString();
                        } else {
                            renderer.lineWidth = +0;
                            renderer.strokeStyle = Graphics.Colors.TRANSPARENT.toString()
                        }

                        // transforms: {rotation: {…}, translation: Coordinates2D, scale: Vector2D, skew: Vector2D}
                    }
                };

                // Shape --- NOTE (Lapys) -> Shapes have a fill, other graphics don't.
                static Shape = class Shape extends Graphics.Graphic {};

            /* Class */
                // Arc --- CHECKPOINT (Lapys)
                static Arc = class Arc extends Graphics.Graphic {
                    angles = {end: +0, start: +0};
                    clockwise;
                    radius;
                    x; y;

                    get endAngle() { return this.angles.end }
                    set endAngle(angle) { return (this.angles.end = angle) }
                    get startAngle() { return this.angles.start }
                    set startAngle(angle) { return (this.angles.start = angle) }

                    constructor() { super() }
                };

                // Ellipse --- CHECKPOINT (Lapys)
                static Ellipse = class Ellipse extends Graphics.Shape {};

                // Circle --- CHECKPOINT (Lapys)
                static Circle = class Circle extends Graphics.Ellipse {};

                // Line --- CHECKPOINT (Lapys)
                static Line = class Line extends Graphics.Graphic {};

                // Oval --- CHECKPOINT (Lapys)
                static Oval = class Oval extends Graphics.Shape {};

                // Polygon --- CHECKPOINT (Lapys)
                static Polygon = class Polygon extends Graphics.Shape {};

                // Rectangle --- REDACT (Lapys)
                static Rectangle = class Rectangle extends Graphics.Shape {
                    height; width; constructor(height, width) { super(); this.height = height ?? +0; this.width = width ?? +0 }

                    draw(renderer, parameters, context) {
                        renderer.fillRect(parameters.coordinates.x, parameters.coordinates.y, this.width, this.height);
                        renderer.strokeRect(parameters.coordinates.x, parameters.coordinates.y, this.width, this.height)

                        // gradients
                        // patterns
                    }
                };
                    // ... Rectangle
                    static BeveledRectangle = class BeveledRectangle extends Graphics.Rectangle { cornerLengths; constructor(height, width, lengths) { super(height ?? +0, width ?? +0); this.cornerLengths = lengths ?? [+0, +0, +0, +0] } };
                    static ChamferedRectangle = class ChamferedRectangle extends Graphics.Rectangle { cornerRadii = [+0, +0, +0, +0]; constructor(height, width, radii) { super(height ?? +0, width ?? +0); this.cornerRadii = radii ?? [+0, +0, +0, +0] } };
                    static RoundedRectangle = class RoundedRectangle extends Graphics.Rectangle { cornerRadii = [+0, +0, +0, +0]; constructor(height, width, radii) { super(height ?? +0, width ?? +0); this.cornerRadii = radii ?? [+0, +0, +0, +0] } };

                // Spline --- CHECKPOINT (Lapys)
                static Spline = class Spline extends Graphics.Graphic {};
                    // ... Spline --- CHECKPOINT (Lapys)
                    static BezierSpline;
                    static QuadraticSpline;

                // Square
                static Square = class Square extends Graphics.Rectangle { constructor(size) { super(size ?? +0, size ?? +0) } };
                    // ... Square --- CHECKPOINT (Lapys)
                    static BeveledSquare;
                    static ChamferedSquare;
                    static RoundedSquare;

                // Star --- CHECKPOINT (Lapys)
                static Star = class Star extends Graphics.Polygon {};

                // Text --- CHECKPOINT (Lapys)
                static Text = class Text extends Graphics.Graphic {};

            /* Function */
                // Draw
                draw(graphic, parameters, renderer) { if (graphic.draw !== Graphics.Graphic.prototype.draw) {
                    // Constant > (Graphics, Resolved Parameters)
                    const graphics = this;
                    const resolvedParameters = graphics.resolveParameters(parameters);

                    // Logic > ...
                    if (graphic instanceof Entity) graphic.draw(renderer ?? graphics.renderer, resolvedParameters, graphic);
                    else {
                        Graphics.Graphic.prototype.draw.call(graphic, renderer ?? graphics.renderer, resolvedParameters, graphics);
                        graphic.draw(renderer ?? graphics.renderer, resolvedParameters, graphics);
                        resolvedParameters.overlays.foreach(overlay => graphics.draw(overlay, resolvedParameters, renderer ?? graphics.renderer))
                    }
                } }

                // Erase
                erase(graphic, parameters) {
                    // Constant > (Graphics, Composite Operation, Resolved Parameters)
                    const graphics = this;
                    const compositeOperation = graphics.compositeOperation;
                    const resolvedParameters = graphics.resolveParameters(parameters);

                    // Modification > Graphics > Composite Operation; ...
                    graphics.compositeOperation = Graphics.CompositeOperations.DESTINATION_OUT; {
                        graphics.draw(graphic, resolvedParameters, graphics.renderer);
                        graphics.bufferList.foreach(buffer => graphics.draw(graphic, resolvedParameters, buffer.renderer))
                    } graphics.compositeOperation = compositeOperation
                }

                // Resolve Coordinate(s)
                resolveCoordinate(coordinate) { return this.subPixelRendering ? coordinate : Math.trunc(coordinate) }
                resolveCoordinates(coordinates) {
                    // Logic > ...
                    if (null === coordinates || "object" != typeof(coordinates)) return new Graphics.Coordinates2D;
                    else {
                        // Evaluation > Evaluation
                        const evaluation = Graphics.Coordinates2D.from(coordinates);

                        // Modification > Evaluation > (W, X, Y, Z)
                        evaluation.w = this.resolveCoordinate(evaluation.w);
                        evaluation.x = this.resolveCoordinate(evaluation.x);
                        evaluation.y = this.resolveCoordinate(evaluation.y);
                        evaluation.z = this.resolveCoordinate(evaluation.z);

                        // Return
                        return evaluation
                    }

                    // Return
                    return coordinates
                }

                /* Resolve Graphic Parameters
                        --- NOTE (Lapys) -> Absolve all shorthand properties.
                        --- WARN (Lapys) -> Will modify the `parameters` object as it assumes it is a proxy of a `Parameters` instance.
                */
                resolveParameters(parameters) {
                    // Logic > ...
                    if (null === parameters || "object" != typeof(parameters)) return new Graphics.Graphic.Parameters;
                    else if (false == parameters instanceof Graphics.Graphic.Parameters) {
                        // Function > ...
                        function define(object, identifier, value) { return Global.Object.defineProperty(object, identifier, {configurable: false, enumerable: true, value: value, writable: true}) }
                        function has(object, identifier) { return Object.hasOwn(object, identifier) }

                        // ... Modification > Parameters > ...
                        has(parameters, "fillColor") && define(parameters.colors = Object.from(parameters.colors), "fill", parameters.fillColor);
                        has(parameters, "fillGradient") && define(parameters.gradients = Object.from(parameters.gradients), "fill", parameters.fillGradient);
                        has(parameters, "fillOpacity") && define(parameters.opacity = Object.from(parameters.opacity), "fill", parameters.fillOpacity);
                        has(parameters, "fillPattern") && define(parameters.patterns = Object.from(parameters.patterns), "fill", parameters.fillPattern);
                        has(parameters, "lineCap") && define(parameters.line = Object.from(parameters.line), "cap", parameters.lineCap);
                        has(parameters, "lineDashOffset") && define(parameters.line = Object.from(parameters.line), "dashOffset", parameters.lineDashOffset);
                        has(parameters, "lineJoin") && define(parameters.line = Object.from(parameters.line), "join", parameters.lineJoin);
                        has(parameters, "lineWidth") && define(parameters.line = Object.from(parameters.line), "width", parameters.lineWidth);
                        if (has(parameters, "rotation")) { parameters.transforms = Object.from(parameters.transforms); define(parameters.transforms.rotation = Object.from(parameters.transforms.rotation), "angle", parameters.rotation) }
                        if (has(parameters, "rotationAnchor")) { parameters.transforms = Object.from(parameters.transforms); define(parameters.transforms.rotation = Object.from(parameters.transforms.rotation), "anchor", parameters.rotationAnchor) }
                        has(parameters, "translation") && define(parameters.transforms = Object.from(parameters.transforms), "translation", parameters.translation);
                        has(parameters, "scale") && define(parameters.transforms = Object.from(parameters.transforms), "scale", parameters.scale);
                        has(parameters, "skew") && define(parameters.transforms = Object.from(parameters.transforms), "skew", parameters.skew);
                        has(parameters, "strokeColor") && define(parameters.colors = Object.from(parameters.colors), "stroke", parameters.strokeColor);
                        has(parameters, "strokeGradient") && define(parameters.gradients = Object.from(parameters.gradients), "stroke", parameters.strokeGradient);
                        has(parameters, "strokeOpacity") && define(parameters.opacity = Object.from(parameters.opacity), "stroke", parameters.strokeOpacity);
                        has(parameters, "strokePattern") && define(parameters.patterns = Object.from(parameters.patterns), "stroke", parameters.strokePattern);
                        has(parameters, 'x') && define(parameters.coordinates = Object.from(parameters.coordinates), 'x', parameters.x);
                        has(parameters, 'y') && define(parameters.coordinates = Object.from(parameters.coordinates), 'y', parameters.y);

                        // Return
                        return Graphics.Graphic.Parameters.from(parameters, true)
                    }

                    // Return
                    return parameters
                }

                // Set Buffer Count
                setBufferCount(count) {
                    // Modification > Target > (Buffer List, Current Buffer List)
                    for (let iterator = count; iterator; --iterator) this.bufferList.push(new Graphics.Buffer);
                    this.currentBufferIndex = -1
                }

                // Set Render
                setRender(render) { if (render !== this.render) {
                    // Constant > (Graphics, Target)
                    const graphics = this;
                    const target = Events.onresize.target;

                    // Modification > Graphics > Render ...
                    graphics.render = render;
                    graphics.renderer = new Graphics.Renderer(render);

                    // Event > Render > Resize
                    Events.onresize.listen(render).invoke(function onresize(event, target) {
                        // Constant > (Height, Width)
                        const {height, width} = graphics.render;

                        // Loop
                        for (let iterator = graphics.bufferList.length - 1; ~iterator; --iterator) {
                            // Modification > [Buffer] > (Height, Width)
                            graphics.bufferList[iterator].render.height = height;
                            graphics.bufferList[iterator].render.width = width
                        }
                    }).listen(target)
                } }

                // Update Buffer Index
                updateBufferIndex() { (this.bufferList.length == ++this.currentBufferIndex) && (this.currentBufferIndex = +0) }
        });

        /* Scene --- NOTE (Lapys) -> Layer of `Graphic` objects. */
        const Scene = (Game.Scene = class Scene {
            // Initialization > Renderables
            renderables = new Graphics.GraphicList;

            // Function
                // Add
                add(graphic, parameters) {}

                // Draw
                draw(renderer, parameters, context) {
                }
        });

    /* Modification */ {
        /* ... */
        Object.define(Global, "Entity", Entity);
        Object.define(Global, "Enumerable", Enumerable);
        Object.define(Global, "Enumeration", Enumeration);
        Object.define(Global, "Events", Events);
        Object.define(Global, "List", List);
        Object.define(Global, "Game", Game);
        Object.define(Global, "Graphics", Graphics);
        Object.define(Global, "Scene", Scene);

        Object.hasOwn(Math, "clamp") || Object.define(Math, "clamp", function clamp(number, minimum, maximum) { return number <= minimum ? minimum : number >= maximum ? maximum : number });
        Object.hasOwn(Math, "perc") || Object.define(Math, "perc", function perc(base, exponent) { return base * (exponent / 100) });
        Object.hasOwn(Math, "wrap") || Object.define(Math, "wrap", function wrap(number, range) { return number % (range + 1) });

        Object.hasOwn(Number, "from") || Object.define(Number, "from", function from(argument) { return Number.parseFloat(argument) || +0 });

        /* Events */ { const EventListener = Events.constructor.EventListener, EventTypes = Events.constructor;
            function cancelEvent(event) { if (event.cancelable) { event.preventDefault(); event.stopPropagation() } }
            function PointerEvent(event, Event = EventTypes.PointerEvent) { // WARN (Lapys) -> Not a constructor.
                let pointerPushEvent;

                if (event instanceof TouchEvent) { const eventTouches = event.touches; pointerPushEvent = new Event; for (let iterator = +0, length = eventTouches.length; iterator ^ length; ++iterator) pointerPushEvent.addCoordinates(eventTouches[iterator].clientX, eventTouches[iterator].clientY) }
                else pointerPushEvent = new Event(event.clientX, event.clientY);

                return pointerPushEvent
            }

            // On ... --- NOTE (Lapys) -> General event listener functionality.
            Events.onblur = new EventListener((handler, target, Event) => {
                if (target instanceof EventTarget) target.addEventListener("blur", function _onblur(event) {
                    cancelEvent(event);
                    handler(ImmutableReference(new Event), target)
                }, {capture: true, once: false, passive: false}, true)
            }, EventTypes.BlurEvent);

            Events.onclick = new EventListener((handler, target, Event) => {
                if (target instanceof EventTarget) target.addEventListener("click", function _onclick(event) {
                    cancelEvent(event);
                    handler(ImmutableReference(new Event(event.clientX, event.clientY)), target)
                })
            }, EventTypes.PointerEvent);

            Events.ondoubleclick = new EventListener((handler, target, Event) => {
                if (target instanceof EventTarget) target.addEventListener("dblclick", function _ondoubleclick(event) {
                    cancelEvent(event);
                    handler(ImmutableReference(new Event(event.clientX, event.clientY)), target)
                })
            }, EventTypes.PointerEvent);

            Events.onfocus = new EventListener((handler, target, Event) => {
                if (target instanceof EventTarget) target.addEventListener("focus", function _onfocus(event) {
                    cancelEvent(event);
                    handler(ImmutableReference(new Event), target)
                }, {capture: true, once: false, passive: false}, true)
            }, EventTypes.FocusEvent);

            Events.onkeypress = new EventListener((handler, target, Event) => {
                target.addEventListener("keypress", function _onkeypress(event) {
                    cancelEvent(event);
                    handler(ImmutableReference(new Event(EventTypes.KeyEvent.getAssociatedKey(event))), target)
                }, {capture: true, once: false, passive: false}, true)
            }, EventTypes.KeyPressEvent);

            Events.onkeyup = new EventListener((handler, target, Event) => {
                target.addEventListener("keyup", function _onkeyup(event) {
                    cancelEvent(event);
                    handler(ImmutableReference(new Event(EventTypes.KeyEvent.getAssociatedKey(event))), target)
                }, {capture: true, once: false, passive: false}, true)
            }, EventTypes.KeyReleaseEvent);

            Events.onscrollwheel = new EventListener((handler, target, Event) => {
                if (target instanceof EventTarget)
                target.addEventListener("wheel", function _onscrollwheel(event) {
                    cancelEvent(event);
                    handler(ImmutableReference(new Event(event.deltaY < 0 ? Events.ScrollWheelEvent.Directions.DOWN : Events.ScrollWheelEvent.Directions.UP)), target)
                }, {capture: true, once: false, passive: false}, true)
            }, EventTypes.ScrollWheelEvent);

            // On Key Down
            Events.onkeydown = new EventListener((handler, target, Event) => {
                // Initialization > Is Pushing
                // : Constant > ...
                let isPushing = false;
                const targets = {blur: Events.onblur.target, keypress: Events.onkeypress.target, keyup: Events.onkeyup.target};

                // Function > ...
                function unpush() { isPushing = false }

                // Event > Target > (Blur, Key (Press, Up))
                Events.onblur.listen(target).invoke(unpush).listen(targets.blur);
                Events.onkeypress.listen(target).invoke(function(event) { if (false == isPushing) { isPushing = true; handler(ImmutableReference(new Event(event.key)), target) } }).listen(targets.keypress);
                Events.onkeyup.listen(target).invoke(unpush).listen(targets.keyup)
            }, EventTypes.KeyPushEvent);

            // On Pointer Down
            Events.onpointerdown = new EventListener((handler, target, Event) => {
                // Initialization > Is Pending
                let isPending = false;

                // Function > ... --- REDACT (Lapys)
                function _onpointerdown(event) { if (false == isPending) {
                    isPending = true; Game.tick(unpend);
                    cancelEvent(event); handler(ImmutableReference(new PointerEvent(event, Event)), target)
                } } function unpend() { isPending = false }

                // Event > Target > (Mouse Down, Pointer Down, Touch Start)
                target.addEventListener("mousedown", _onpointerdown, {capture: true, once: false, passive: false}, true);
                target.addEventListener("pointerdown", _onpointerdown, {capture: true, once: false, passive: false}, true);
                target.addEventListener("touchstart", _onpointerdown, {capture: true, once: false, passive: false}, true)
            }, EventTypes.PointerPushEvent);

            // On Pointer Move
            Events.onpointermove = new EventListener((handler, target, Event) => { // CONSIDER (Lapys) -> Is this efficient?
                // Initialization > Is Pending
                let isPending = false;

                // Function > ... --- REDACT (Lapys)
                function _onpointermove(event) { if (false == isPending) {
                    isPending = true; Game.tick(unpend);
                    cancelEvent(event); handler(ImmutableReference(new PointerEvent(event, Event)), target)
                } } function unpend() { isPending = false }

                // Event > Target > (Mouse Move, Pointer Move, Touch Move)
                target.addEventListener("mousemove", _onpointermove, {capture: true, once: false, passive: false}, true);
                target.addEventListener("pointermove", _onpointermove, {capture: true, once: false, passive: false}, true);
                target.addEventListener("touchmove", _onpointermove, {capture: true, once: false, passive: false}, true)
            }, EventTypes.PointerMoveEvent);

            // On Pointer Press
            Events.onpointerpress = new EventListener((handler, target, Event) => {
                // Initialization
                // : Is (Moving, Pushing)
                // : Pointer Press Event
                let isMoving = false, isPushing = false;
                let pointerPressEvent;

                // Constant > Targets
                const targets = {
                    blur: Events.onblur.target,
                    pointerdown: Events.onpointerdown.target,
                    pointermove: Events.onpointermove.target,
                    pointerup: Events.onpointerup.target
                };

                // Function > (On Pointer Press..., ...)
                function _onpointerpress() { handler(ImmutableReference(pointerPressEvent), target) }
                function _onpointerpressed(event) { pointerPressEvent = new Event; pointerPressEvent.coordinates = event.coordinates }
                function _onpointerpressing() { if (isPushing) { Game.tick(_onpointerpressing); _onpointerpress() } }
                function move() { isMoving = true }
                function unpend() { isMoving = isPushing = false }

                // Event > Target > (Blur, Pointer ...)
                Events.onblur.listen(target).invoke(unpend).listen(targets.blur);
                Events.onpointerdown.listen(target).invoke(function(event) { isPushing = true; _onpointerpressed(event); Game.tick(_onpointerpressing) }).listen(targets.pointermove);
                Events.onpointermove.listen(target).invoke(function(event) { if (isMoving) _onpointerpressed(event); else if (isPushing) Game.tick(move) }).listen(targets.pointermove);
                Events.onpointerup.listen(target).invoke(unpend).listen(targets.pointerup)
            }, EventTypes.PointerPressEvent);

            // On Pointer Up
            Events.onpointerup = new EventListener((handler, target, Event) => {
                // Initialization > Is Pending
                let isPending = false;

                // Function > ... --- REDACT (Lapys)
                function _onpointerup(event) { if (false == isPending) {
                    isPending = true; Game.tick(unpend);
                    cancelEvent(event); handler(ImmutableReference(new PointerEvent(event, Event)), target)
                } } function unpend() { isPending = false }

                // Event > Target > (Mouse Down, Pointer Down, Touch Start)
                target.addEventListener("mouseup", _onpointerup, {capture: true, once: false, passive: false}, true);
                target.addEventListener("pointerup", _onpointerup, {capture: true, once: false, passive: false}, true);
                target.addEventListener("touchend", _onpointerup, {capture: true, once: false, passive: false}, true)
            }, EventTypes.PointerReleaseEvent);

            // On Ready
            Events.onready = new EventListener((handler, target, Event) => {
                // Logic
                if (target instanceof Document || target instanceof HTMLDocument) {
                    // Constant > Resource Load Event
                    const resourceLoadEvent = new Event(target.location.href);

                    // Function > Ready
                    // : ...
                    function ready() { resourceLoadEvent.loaded = true; handler(ImmutableReference(resourceLoadEvent), target) }
                    "complete" == target.readyState ? ready() : target.addEventListener("readystatechange", function _onready(event) { if ("complete" == target.readyState) { cancelEvent(event); ready() } })
                }

                else if (target instanceof Image) {
                    // Constant > Resource Load Event
                    const resourceLoadEvent = new Event(target.src);

                    // Event > Target > (Error, Load)
                    target.addEventListener("error", function _onready(event) { target.removeEventListener("error", _onready); resourceLoadEvent.loaded = false; cancelEvent(event); handler(ImmutableReference(resourceLoadEvent), target) }, {capture: true, once: true, passive: false}, true);
                    target.addEventListener("load", function _onready(event) { target.removeEventListener("load", _onready); resourceLoadEvent.loaded = true; cancelEvent(event); handler(ImmutableReference(resourceLoadEvent), target) }, {capture: true, once: true, passive: false}, true)
                }
            }, EventTypes.ResourceLoadEvent);

            // On Resize
            Events.onresize = new EventListener((handler, target, Event) => {
                // Constant > Target Size
                const targetSize = {height: null, width: null};

                // Function > (..., Request Target Size) --- REDACT (Lapys)
                function resize() {
                    // Constant > Resize Event
                    const resizeEvent = new Event(targetSize.height, targetSize.width);

                    // ...; Modification > Resize Event > Current (Height, Width)
                    requestTargetSize();
                    resizeEvent.currentHeight = targetSize.height;
                    resizeEvent.currentWidth = targetSize.width;

                    // ...
                    handler(ImmutableReference(resizeEvent), target)
                }
                function requestTargetSize() {
                    if (target instanceof Window) { targetSize.height = target.innerHeight; targetSize.width = target.innerWidth }
                    else if (target instanceof Element || target instanceof HTMLElement) {
                        const boundingClientRectangle = target.getBoundingClientRect();

                        targetSize.height = boundingClientRectangle.height;
                        targetSize.width = boundingClientRectangle.width
                    }

                    else if (target instanceof Document || target instanceof HTMLDocument) {
                        const bodyElement = target.body;
                        const documentElement = target.documentElement;

                        targetSize.height = Math.max(bodyElement.offsetHeight, bodyElement.scrollHeight, documentElement.clientHeight, documentElement.offsetHeight, documentElement.scrollHeight);
                        targetSize.width = Math.max(bodyElement.offsetWidth, bodyElement.scrollWidth, documentElement.clientWidth, documentElement.offsetWidth, documentElement.scrollWidth)
                    }

                    return targetSize
                }

                // Logic
                if (target instanceof SVGElement || target instanceof Window) {
                    // Event > Target > Resize
                    target.addEventListener("resize", function _onresize(event) {
                        // ...
                        cancelEvent(event);
                        resize()
                    }, {capture: true, once: false, passive: false}, true)
                }

                else if ("undefined" == typeof(ResizeObserver)) {
                    // Constant > Recent Target Size
                    const recentTargetSize = {height: +0, width: +0};

                    // ...; Modification > Recent Target Size > (Height, Width)
                    requestTargetSize();
                    recentTargetSize.height = targetSize.height;
                    recentTargetSize.width = targetSize.width;

                    // ...
                    Game.tick(function resized() {
                        // ...; Logic
                        requestTargetSize();
                        if ((targetSize.height != recentTargetSize.height) || (targetSize.width != recentTargetSize.width)) {
                            // Modification > Recent Target Size > (Height, Width)
                            recentTargetSize.height = targetSize.height;
                            recentTargetSize.width = targetSize.width;

                            // ...
                            resize()
                        }

                        // ...
                        Game.tick(resized)
                    })
                }

                else {
                    // ...
                    new ResizeObserver(resize).observe(target)
                }
            }, EventTypes.ResizeEvent);

            /* Types */ with (EventTypes) {
                // Key Event > Key(s)
                KeyEvent.Key = class Key extends Enumerable {
                    // Function > To String
                    toString() { switch (this) {
                        case KeyEvent.Keys.ADD: return '+';
                        case KeyEvent.Keys.AMPERSAND: return '&';
                        case KeyEvent.Keys.AT: return '@';
                        case KeyEvent.Keys.BACKQUOTE: return '`';
                        case KeyEvent.Keys.BACKSLASH: return '\\';
                        case KeyEvent.Keys.BACKSPACE: return '\b';
                        case KeyEvent.Keys.CARET: return '^';
                        case KeyEvent.Keys.COLON: return ':';
                        case KeyEvent.Keys.COMMA: return ',';
                        case KeyEvent.Keys.DECIMAL: case KeyEvent.Keys.PERIOD: return '.';
                        case KeyEvent.Keys.DIGIT0: return '0';
                        case KeyEvent.Keys.DIGIT1: return '1';
                        case KeyEvent.Keys.DIGIT2: return '2';
                        case KeyEvent.Keys.DIGIT3: return '3';
                        case KeyEvent.Keys.DIGIT4: return '4';
                        case KeyEvent.Keys.DIGIT5: return '5';
                        case KeyEvent.Keys.DIGIT6: return '6';
                        case KeyEvent.Keys.DIGIT7: return '7';
                        case KeyEvent.Keys.DIGIT8: return '8';
                        case KeyEvent.Keys.DIGIT9: return '9';
                        case KeyEvent.Keys.DIVIDE: return '/';
                        case KeyEvent.Keys.DOLLAR: return '$';
                        case KeyEvent.Keys.DOUBLE_QUOTE: return '"';
                        case KeyEvent.Keys.ENTER: return '\n';
                        case KeyEvent.Keys.EQUAL: return '=';
                        case KeyEvent.Keys.ESCAPE: return '\r';
                        case KeyEvent.Keys.EXCLAMATION: return '!';
                        case KeyEvent.Keys.GREATER_THAN: return '>';
                        case KeyEvent.Keys.HASH: return '#';
                        case KeyEvent.Keys.LEFT_BRACE: return '{';
                        case KeyEvent.Keys.LEFT_BRACKET: return '[';
                        case KeyEvent.Keys.LEFT_PARENTHESIS: return '(';
                        case KeyEvent.Keys.LESSER_THAN: return '<';
                        case KeyEvent.Keys.LOWERCASE_A: return 'a';
                        case KeyEvent.Keys.LOWERCASE_B: return 'b';
                        case KeyEvent.Keys.LOWERCASE_C: return 'c';
                        case KeyEvent.Keys.LOWERCASE_D: return 'd';
                        case KeyEvent.Keys.LOWERCASE_E: return 'e';
                        case KeyEvent.Keys.LOWERCASE_F: return 'f';
                        case KeyEvent.Keys.LOWERCASE_G: return 'g';
                        case KeyEvent.Keys.LOWERCASE_H: return 'h';
                        case KeyEvent.Keys.LOWERCASE_I: return 'i';
                        case KeyEvent.Keys.LOWERCASE_J: return 'j';
                        case KeyEvent.Keys.LOWERCASE_K: return 'k';
                        case KeyEvent.Keys.LOWERCASE_L: return 'l';
                        case KeyEvent.Keys.LOWERCASE_M: return 'm';
                        case KeyEvent.Keys.LOWERCASE_N: return 'n';
                        case KeyEvent.Keys.LOWERCASE_O: return 'o';
                        case KeyEvent.Keys.LOWERCASE_P: return 'p';
                        case KeyEvent.Keys.LOWERCASE_Q: return 'q';
                        case KeyEvent.Keys.LOWERCASE_R: return 'r';
                        case KeyEvent.Keys.LOWERCASE_S: return 's';
                        case KeyEvent.Keys.LOWERCASE_T: return 't';
                        case KeyEvent.Keys.LOWERCASE_U: return 'u';
                        case KeyEvent.Keys.LOWERCASE_W: return 'w';
                        case KeyEvent.Keys.LOWERCASE_X: return 'x';
                        case KeyEvent.Keys.LOWERCASE_Y: return 'y';
                        case KeyEvent.Keys.LOWERCASE_Z: return 'z';
                        case KeyEvent.Keys.MULTIPLY: return '*';
                        case KeyEvent.Keys.NUMBER_PAD0: return '0';
                        case KeyEvent.Keys.NUMBER_PAD1: return '1';
                        case KeyEvent.Keys.NUMBER_PAD2: return '2';
                        case KeyEvent.Keys.NUMBER_PAD3: return '3';
                        case KeyEvent.Keys.NUMBER_PAD4: return '4';
                        case KeyEvent.Keys.NUMBER_PAD5: return '5';
                        case KeyEvent.Keys.NUMBER_PAD6: return '6';
                        case KeyEvent.Keys.NUMBER_PAD7: return '7';
                        case KeyEvent.Keys.NUMBER_PAD8: return '8';
                        case KeyEvent.Keys.NUMBER_PAD9: return '9';
                        case KeyEvent.Keys.PERCENTAGE: return '%';
                        case KeyEvent.Keys.QUESTION: return '?';
                        case KeyEvent.Keys.QUOTE: return '\'';
                        case KeyEvent.Keys.RIGHT_BRACE: return '}';
                        case KeyEvent.Keys.RIGHT_BRACKET: return ']';
                        case KeyEvent.Keys.RIGHT_PARENTHESIS: return ')';
                        case KeyEvent.Keys.SEMICOLON: return ';';
                        case KeyEvent.Keys.SINGLE_QUOTE: return '\'';
                        case KeyEvent.Keys.SLASH: return '/';
                        case KeyEvent.Keys.SPACEBAR: return ' ';
                        case KeyEvent.Keys.SUBTRACT: return '-';
                        case KeyEvent.Keys.TAB: return '\t';
                        case KeyEvent.Keys.TILDE: return '`';
                        case KeyEvent.Keys.UNDERSCORE: return '_';
                        case KeyEvent.Keys.UPPERCASE_A: return 'A';
                        case KeyEvent.Keys.UPPERCASE_B: return 'B';
                        case KeyEvent.Keys.UPPERCASE_C: return 'C';
                        case KeyEvent.Keys.UPPERCASE_D: return 'D';
                        case KeyEvent.Keys.UPPERCASE_E: return 'E';
                        case KeyEvent.Keys.UPPERCASE_F: return 'F';
                        case KeyEvent.Keys.UPPERCASE_G: return 'G';
                        case KeyEvent.Keys.UPPERCASE_H: return 'H';
                        case KeyEvent.Keys.UPPERCASE_I: return 'I';
                        case KeyEvent.Keys.UPPERCASE_J: return 'J';
                        case KeyEvent.Keys.UPPERCASE_K: return 'K';
                        case KeyEvent.Keys.UPPERCASE_L: return 'L';
                        case KeyEvent.Keys.UPPERCASE_M: return 'M';
                        case KeyEvent.Keys.UPPERCASE_N: return 'N';
                        case KeyEvent.Keys.UPPERCASE_O: return 'O';
                        case KeyEvent.Keys.UPPERCASE_P: return 'P';
                        case KeyEvent.Keys.UPPERCASE_Q: return 'Q';
                        case KeyEvent.Keys.UPPERCASE_R: return 'R';
                        case KeyEvent.Keys.UPPERCASE_S: return 'S';
                        case KeyEvent.Keys.UPPERCASE_T: return 'T';
                        case KeyEvent.Keys.UPPERCASE_U: return 'U';
                        case KeyEvent.Keys.UPPERCASE_W: return 'W';
                        case KeyEvent.Keys.UPPERCASE_X: return 'X';
                        case KeyEvent.Keys.UPPERCASE_Y: return 'Y';
                        case KeyEvent.Keys.UPPERCASE_Z: return 'Z';
                        case KeyEvent.Keys.VERTICAL_BAR: return '|';
                        default: return ""
                    } }
                };

                KeyEvent.Keys = ImmutableReference(new class KeyEnumeration extends Enumeration {}(
                    // [Application Selector]
                    "LAUNCH_CALCULATOR", "LAUNCH_CALENDER", "LAUNCH_CONTACTS",
                    "LAUNCH_MAIL", "LAUNCH_MEDIA_PLAYER", "LAUNCH_MUSIC_PLAYER", "LAUNCH_MY_COMPUTER",
                    "LAUNCH_PHONE",
                    "LAUNCH_SCREEN_SAVER", "LAUNCH_SPREADSHEET",
                    "LAUNCH_WEB_BROWSER", "LAUNCH_WEB_CAMERA", "LAUNCH_WORD_PROCESSOR",
                    "LAUNCH_APPLICATION1", "LAUNCH_APPLICATION2", "LAUNCH_APPLICATION3", "LAUNCH_APPLICATION4", "LAUNCH_APPLICATION5", "LAUNCH_APPLICATION6", "LAUNCH_APPLICATION7", "LAUNCH_APPLICATION8", "LAUNCH_APPLICATION9", "LAUNCH_APPLICATION10", "LAUNCH_APPLICATION11", "LAUNCH_APPLICATION12", "LAUNCH_APPLICATION13", "LAUNCH_APPLICATION14", "LAUNCH_APPLICATION15", "LAUNCH_APPLICATION16",

                    // [Audio Control]
                    "AUDIO_BALANCE_LEFT", "AUDIO_BALANCE_RIGHT",
                    "AUDIO_BASS_DOWN", "AUDIO_BASS_BOOST_DOWN", "AUDIO_BASS_BOOST_TOGGLE", "AUDIO_BASS_BOOST_UP", "AUDIO_BASS_UP",
                    "AUDIO_FADER_FRONT", "AUDIO_FADER_REAR",
                    "AUDIO_SURROUND_MODE_NEXT",
                    "AUDIO_TREBLE_DOWN", "AUDIO_TREBLE_UP",
                    "AUDIO_VOLUME_DOWN", "AUDIO_VOLUME_MUTE", "AUDIO_VOLUME_UP",
                    "MICROPHONE_TOGGLE",
                    "MICROPHONE_VOLUME_DOWN", "MICROPHONE_VOLUME_MUTE", "MICROPHONE_VOLUME_UP",

                    // [Browser Control]
                    "BROWSER_BACK",
                    "BROWSER_FAVORITES", "BROWSER_FORWARD",
                    "BROWSER_HOME", "BROWSER_REFRESH",
                    "BROWSER_SEARCH", "BROWSER_STOP",

                    // [Composition & Input Method Editing]
                    "ALL_CANDIDATES", "ALPHANUMERIC",
                    "CODE_INPUT", "COMPOSE", "CONVERT",
                    "DEAD", "EISU", "FINAL_MODE",
                    "GROUP_FIRST", "GROUP_LAST", "GROUP_NEXT", "GROUP_PREVIOUS",
                    "HANGUL_MODE", "HANKAKU", "HANJA_MODE", "HIRAGANA", "HIRAGANA_KATAKANA",
                    "JUNJA_MODE",
                    "KANA_MODE", "KANJI_MODE", "KATAKANA",
                    "MODE_CHANGE",
                    "NEXT_CANDIDATE", "NON_CONVERT",
                    "PREVIOUS_CANDIDATE", "PROCESS",
                    "ROMAJI", "SINGLE_CANDIDATE",
                    "ZENKAKU", "ZENKAKU_HANAKU",

                    // [Control]
                    "ALT_GRAPH", "CAPS_LOCK",
                    "FUNCTION", "FUNCTION_LOCK",
                    "HYPER",
                    "LEFT_ALT", "LEFT_CONTROL", "LEFT_SHIFT",
                    "META", "NUMBER_LOCK",
                    "RIGHT_ALT", "RIGHT_CONTROL", "RIGHT_SHIFT",
                    "SCROLL_LOCK", "SUPER", "SYMBOL", "SYMBOL_LOCK",

                    // [Device]
                    "BRIGHTNESS_DOWN", "BRIGHTNESS_UP",
                    "EJECT", "HIBERNATE", "LOG_OFF",
                    "POWER", "POWER_OFF", "PRINT_SCREEN",
                    "STANDBY", "WAKE_UP",

                    // [Document]
                    "CLOSE",
                    "MAIL_FORWARD", "MAIL_REPLY", "MAIL_SEND",
                    "NEW", "OPEN", "PRINT",
                    "SAVE", "SPELL_CHECK",

                    // [Edit]
                    "BACKSPACE",
                    "CLEAR", "COPY", "CURSOR_SELECT", "CUT",
                    "DELETE",
                    "ERASE_END_OF_FIELD", "EXTEND_SELECT",
                    "INSERT", "PASTE", "REDO", "UNDO",

                    // [Function]
                    "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24",
                    "SOFT1", "SOFT2", "SOFT3", "SOFT4",

                    // [Media Controller]
                    "AVR_INPUT", "AVR_POWER",
                    "COLOR_F0_RED", "COLOR_F1_GREEN", "COLOR_F2_YELLOW", "COLOR_F3_BLUE", "COLOR_F4_GRAY", "COLOR_F5_BROWN",
                    "CLOSED_CAPTION_TOGGLE", "DIMMER", "DISPLAY_SWAP", "DVR", "EXIT",
                    "FAVORITE_CLEAR0", "FAVORITE_CLEAR1", "FAVORITE_CLEAR2", "FAVORITE_CLEAR3",
                    "FAVORITE_RECALL0", "FAVORITE_RECALL1", "FAVORITE_RECALL2", "FAVORITE_RECALL3",
                    "FAVORITE_STORE0", "FAVORITE_STORE1", "FAVORITE_STORE2", "FAVORITE_STORE3",
                    "GUIDE", "GUIDE_NEXT_DAY", "GUIDE_PREVIOUS_DAY",
                    "INFORMATION", "INSTANT_REPLAY",
                    "LINK", "LIST_PROGRAM", "LIVE_CONTENT", "LOCK",
                    "MEDIA_APPLICATIONS", "MEDIA_AUDIO_TRACK",
                    "MEDIA_LAST",
                    "MEDIA_SKIP_BACKWARD", "MEDIA_SKIP_FORWARD",
                    "MEDIA_STEP_BACKWARD", "MEDIA_STEP_FORWARD",
                    "MEDIA_TOP_MENU",
                    "NAVIGATE_IN", "NAVIGATE_NEXT", "NAVIGATE_OUT", "NAVIGATE_PREVIOUS",
                    "NEXT_FAVORITE_CHANNEL", "NEXT_USER_PROFILE",
                    "ON_DEMAND", "PAIRING",
                    "PIN_P_DOWN", "PIN_P_MOVE", "PIN_P_TOGGLE", "PIN_P_UP",
                    "PLAY_SPEED_DOWN", "PLAY_SPEED_RESET", "PLAY_SPEED_UP",
                    "RANDOM_TOGGLE", "RECORD_SPEED_NEXT", "REMOTE_CONTROL_LOW_BATTERY", "RADIO_FREQUENCY_BYPASS",
                    "SCAN_CHANNELS_TOGGLE", "SCREEN_MODE_NEXT", "SETTINGS", "SPLIT_SCREEN_TOGGLE",
                    "SET_TOP_BOX_INPUT", "SET_TOP_BOX_POWER",
                    "SUBTITLE", "TELETEXT", "VIDEO_MODE_NEXT", "WINK", "ZOOM_TOGGLE",

                    // [Multimedia Keys]
                    "CHANNEL_DOWN", "CHANNEL_UP",
                    "MEDIA_FAST_FORWARD", "MEDIA_PAUSE", "MEDIA_PLAY", "MEDIA_PLAY_PAUSE", "MEDIA_RECORD", "MEDIA_REWIND", "MEDIA_STOP", "MEDIA_TRACK_NEXT", "MEDIA_TRACK_PREVIOUS",

                    // [Navigation]
                    "ARROW_DOWN", "ARROW_LEFT", "ARROW_RIGHT", "ARROW_UP",
                    "END", "HOME",
                    "PAGE_DOWN", "PAGE_UP",

                    // [Numeric]
                    "ADD", "CLEAR",
                    "DECIMAL", "DIVIDE", "EQUAL",
                    "KEY11", "KEY12",
                    "MULTIPLY",
                    "NUMBER_PAD0", "NUMBER_PAD1", "NUMBER_PAD2", "NUMBER_PAD3", "NUMBER_PAD4", "NUMBER_PAD5", "NUMBER_PAD6", "NUMBER_PAD7", "NUMBER_PAD8", "NUMBER_PAD9",
                    "SEPARATOR", "SUBTRACT",

                    // [Phone]
                    "APP_SWITCH",
                    "CALL", "CAMERA", "CAMERA_FOCUS",
                    "END_CALL",
                    "GO_BACK", "GO_HOME",
                    "HEADSET_HOOK", "LAST_NUMBER_REDIAL", "NOTIFICATION", "MANNER_MODE", "VOICE_DIAL",

                    // [Special]
                    "UNIDENTIFIED",

                    // [Speech Recognition]
                    "SPEECH_CORRECTION_LIST", "SPEECH_INPUT_TOGGLE",

                    // [TV Control]
                    "TV", "TV_3D_MODE",
                    "TV_ANTENNA_CABLE",
                    "TV_AUDIO_DESCRIPTION", "TV_AUDIO_DESCRIPTION_MIX_DOWN", "TV_AUDIO_DESCRIPTION_MIX_UP",
                    "TV_CONTENTS_MENU", "TV_DATA_SERVICE",
                    "TV_INPUT",
                    "TV_INPUT_COMPONENT1", "TV_INPUT_COMPONENT2", "TV_INPUT_COMPOSITE1", "TV_INPUT_COMPOSITE2",
                    "TV_INPUT_HDMI1", "TV_INPUT_HDMI2", "TV_INPUT_HDMI3", "TV_INPUT_HDMI4",
                    "TV_INPUT_VGA1", "TV_MEDIA_CONTEXT", "TV_NETWORK", "TV_NUMBER_ENTRY", "TV_POWER", "TV_RADIO_SERVICE",
                    "TV_SATELLITE", "TV_SATELLITE_BROADCAST", "TV_SATELLITE_COMMUNICATION", "TV_SATELLITE_TOGGLE",
                    "TV_TERRESTRIAL_ANALOG", "TV_TERRESTRIAL_DIGITAL",
                    "TV_TIMER",

                    // [User Interface]
                    "ACCEPT", "AGAIN", "ATTENTION",
                    "CANCEL", "CONTEXT_MENU",
                    "ESCAPE", "EXECUTE",
                    "FIND", "FINISH",
                    "HELP",
                    "PAUSE", "PLAY", "PROPERTIES",
                    "SELECT",
                    "ZOOM_IN", "ZOOM_OUT",

                    // [Whitespace]
                    "ENTER", "SPACEBAR", "TAB",

                    // [...]
                    "AMPERSAND", "AT",
                    "BACKSLASH", "BACKQUOTE",
                    "CARET", "COLON", "COMMA",
                    "DIGIT0", "DIGIT1", "DIGIT2", "DIGIT3", "DIGIT4", "DIGIT5", "DIGIT6", "DIGIT7", "DIGIT8", "DIGIT9",
                    "DOLLAR",
                    "EJECT", "EXCLAMATION",
                    "GREATER_THAN", "HASH",
                    "LEFT_BRACE", "LEFT_BRACKET", "LEFT_PARENTHESIS",
                    "LESSER_THAN",
                    "LOWERCASE_A", "LOWERCASE_B", "LOWERCASE_C", "LOWERCASE_D", "LOWERCASE_E", "LOWERCASE_F", "LOWERCASE_G", "LOWERCASE_H", "LOWERCASE_I", "LOWERCASE_J", "LOWERCASE_K", "LOWERCASE_L", "LOWERCASE_M", "LOWERCASE_N", "LOWERCASE_O", "LOWERCASE_P", "LOWERCASE_Q", "LOWERCASE_R", "LOWERCASE_S", "LOWERCASE_T", "LOWERCASE_U", "LOWERCASE_W", "LOWERCASE_X", "LOWERCASE_Y", "LOWERCASE_Z",
                    "PERCENTAGE", "PERIOD",
                    "QUESTION", "QUOTE",
                    "RIGHT_BRACE", "RIGHT_BRACKET", "RIGHT_PARENTHESIS",
                    "SEMICOLON", "SLASH",
                    "TILDE", "UNDERSCORE",
                    "UPPERCASE_A", "UPPERCASE_B", "UPPERCASE_C", "UPPERCASE_D", "UPPERCASE_E", "UPPERCASE_F", "UPPERCASE_G", "UPPERCASE_H", "UPPERCASE_I", "UPPERCASE_J", "UPPERCASE_K", "UPPERCASE_L", "UPPERCASE_M", "UPPERCASE_N", "UPPERCASE_O", "UPPERCASE_P", "UPPERCASE_Q", "UPPERCASE_R", "UPPERCASE_S", "UPPERCASE_T", "UPPERCASE_U", "UPPERCASE_W", "UPPERCASE_X", "UPPERCASE_Y", "UPPERCASE_Z",
                    "VERTICAL_BAR"
                ).of(KeyEvent.Key));

                // Pointer Event > Pointer Coordinate List
                PointerEvent.PointerCoordinateList = class PointerCoordinateList extends List {};

                // Scroll Wheel Event > Directions
                ScrollWheelEvent.Directions = ImmutableReference(new class ScrollWheelDirectionEnumeration extends Enumeration {}(
                    "DOWN", "UP"
                ).of(class ScrollWheelDirection extends Enumerable {}))
            }
        }

        /* Game */ {
            /* Components */ {
                // Renderable
                Game.Components.Renderable = function Renderable() { Entity.define(this, "graphics", new Graphics.GraphicList) };
                Game.Components.Renderable.prototype = {
                    draw(renderer, parameters, graphics) {
                        graphics.resolveParameters(parameters);
                        Graphics.Graphic.prototype.draw.call(this.graphic, renderer ?? graphics.renderer, resolvedParameters, graphics);
                    }
                };
            }
        }

        /* Graphics */ {
            // Colors
            Graphics.Colors = ImmutableObject({
                "BLACK": new Graphics.Color(+0, +0, +0, 1),
                "BLUE": new Graphics.Color(+0, +0, 255, 1),
                "CYAN": new Graphics.Color(+0, 255, 255, 1),
                "GRAY": new Graphics.Color(127, 127, 127, 1),
                "GREY": new Graphics.Color(127, 127, 127, 1),
                "GREEN": new Graphics.Color(+0, 255, +0, 1),
                "MAGENTA": new Graphics.Color(255, +0, 255, 1),
                "RED": new Graphics.Color(255, +0, +0, 1),
                "TRANSPARENT": new Graphics.Color(+0, +0, +0, +0),
                "WHITE": new Graphics.Color(255, 255, 255, 1),
                "YELLOW": new Graphics.Color(255, 255, +0, 1)
            });

            // Composite Operations
            Graphics.CompositeOperations = ImmutableReference(new class CompositeOperationEnumeration extends Enumeration {}(
                "COLOR", "COLOR_BURN", "COLOR_DODGE", "COPY",
                "DARKEN", "DESTINATION_ATOP", "DESTINATION_IN", "DESTINATION_OVER", "DESTINATION_OUT", "DIFFERENCE",
                "EXCLUSION",
                "HARD_LIGHT", "HUE",
                "LIGHTEN", "LIGHTER", "LUMINOSITY",
                "MULTIPLY", "OVERLAY",
                "SATURATION", "SCREEN", "SOFT_LIGHT", "SOURCE_ATOP", "SOURCE_IN", "SOURCE_OVER", "SOURCE_OUT",
                "XOR"
            ).of(class CompositeOperation extends Enumerable {}));

            // Filters
            Graphics.Filters = ImmutableReference({
                "BLUR": new Graphics.PresetFilter("blur"),
                "BRIGHTNESS": new Graphics.PresetFilter("brightness"),
                "CONTRAST": new Graphics.PresetFilter("contrast"),
                "DROP_SHADOW": new Graphics.PresetFilter("drop-shadow"),
                "GRAYSCALE": new Graphics.PresetFilter("grayscale"),
                "HUE_ROTATE": new Graphics.PresetFilter("hue-rotate"),
                "INVERT": new Graphics.PresetFilter("invert"),
                "OPACITY": new Graphics.PresetFilter("opacity"),
                "SATURATE": new Graphics.PresetFilter("saturate"),
                "SEPIA": new Graphics.PresetFilter("sepia"),
                "NONE": new Graphics.Filter,
                "URL": new Graphics.PresetFilter("url")
            });

            // Gradient Patterns
            Graphics.GradientPatterns = ImmutableReference(new class GradientPatternEnumeration extends Enumeration {}(
                "LINEAR", "RADIAL"
            ).of(Graphics.GradientPattern));

            // Line Caps
            Graphics.LineCaps = ImmutableReference(new class LineCapEnumeration extends Enumeration {}(
                "BUTT", "ROUND", "SQUARE"
            ).of(Graphics.LineCap));

            // Line Joins
            Graphics.LineJoins = ImmutableReference(new class LineJoinEnumeration extends Enumeration {}(
                "BEVEL", "MITER", "ROUND"
            ).of(Graphics.LineJoin));

            // Positions
            Graphics.Positions = ImmutableReference(new class DynamicCoordinatesEnumeration extends Enumeration {}(
                "BOTTOM", "CENTER", "LEFT", "RIGHT", "UP"
            ).of(Graphics.DynamicCoordinates))
        }
    }
}("undefined" == typeof(self) ? ("undefined" == typeof(window) ? ("undefined" == typeof(global) ? (function() { return this })() : global) : window) : self);
