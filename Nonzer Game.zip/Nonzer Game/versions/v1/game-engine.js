/* ... WARN (Lapys) -> Type assertion is ignored in function arguments. */
; void function Game(global) { // [Private Interface]
    /* Class */ {
        /* Enumerable */
        class Enumerable extends Number {};

        /* List */
        class List extends Array {
            add() { Array.prototype.push.apply(this, arguments) }

            remove() { for (let iterator = +0, length = arguments.length; iterator ^ length; ++iterator) { const index = this.indexOf(arguments[iterator]); ~index && this.splice(index, 1) } }
            removeLast() { for (let iterator = +0, length = arguments.length; iterator ^ length; ++iterator) { const index = this.lastIndexOf(arguments[iterator]); ~index && this.splice(index, 1) } }
        };

        /* Graphics */
        class Graphics {
            /* Initialization > ... */
            #BufferList;
            #CurrentBufferIndex;
            GlobalCompositeOperation;
            Opacity; // NOTE (Lapys) -> Global opacity of the `Graphics` renders.
            SubPixelRendering = true; // NOTE (Lapys) -> Prevents coordinates being represented with floating-point numerals.
            #Render;

            /* [Constructor] --- NOTE (Lapys) -> Renders are `HTMLCanvasElement` objects. */
            constructor(render) { INITIATE(render) }

            /* Class --- REDACT (Lapys) */
                /* [Base] */
                static #_2D_Vector = class _2D_Vector { x = +0; y = +0; constructor(x, y) { switch (arguments.length) { case 2: this.y = y; case 1: this.x = x; break } } };

                static Color = class Color { // MINIFY (Lapys) --- NOTE (Lapys) -> Defers to an RGB format.
                    // [...]
                    #value;

                    // [...]
                    constructor(red, green, blue) { this.value = 0x0; switch (arguments.length) { case 3: this.value += blue; break; case 2: this.value += -~0x0000FF * green; break; case 1: this.value += -~0x00FFFF * red; break; default: this.value = 0xFFFFFF; break; } }

                    get blue() { return this.value & 0xFF }
                    set blue(range) { this.value = range + (this.value & 0xFFFF00) }
                    get green() { return (this.value >> 8) & 0xFF }
                    set green(range) { this.value = (-~0x0000FF * range) + (this.value & 0xFF00FF) }
                    get red() { return (this.value >> 16) & 0xFF }
                    set red(range) { this.value = (-~0x00FFFF * range) + (this.value & 0x00FFFF) }
                    toString() { return "rgb(" + this.red + ", " + this.green + ", " + this.blue + ')' }
                };
                static Coordinate = function(graphics) { return graphics.Coordinate = function Coordinate(x, y) {
                    let evaluation = new Graphics._2D_Vector;
                    let value = new Graphics._2D_Vector(x, y);

                    Object.defineProperty(evaluation, 'x', { get: function x() { return graphics.SubPixelRendering ? Math.trunc(value.x) : value.x }, set: function x(coordinate) { return (value.x = graphics.SubPixelRendering ? Math.trunc(coordinate) : coordinate) } });
                    Object.defineProperty(evaluation, 'y', { get: function y() { return graphics.SubPixelRendering ? Math.trunc(value.y) : value.y }, set: function y(coordinate) { return (value.y = graphics.SubPixelRendering ? Math.trunc(coordinate) : coordinate) } })
                } };
                static #DrawFilters = class DrawFilters {}; // CONSIDER (Lapys) -> Probably not.
                static #DrawOptions = class DrawOptions {
                    // [...]
                    static DynamicCoordinates = class DynamicCoordinates extends Enumerable {};
                    static GradientPattern = class GradientPattern { static LINEAR = new GradientPattern; static RADIAL = new GradientPattern; };
                    static LineCap = class LineCap {
                        static BUTT = new LineCap; static ROUND = new LineCap; static SQUARE = new LineCap;
                        toString() { switch (this) { case BUTT: return "butt"; case ROUND: return "round"; case SQUARE: return "square" } }
                    };
                    static LineJoin = class LineJoin {
                        static BEVEL = new LineJoin; static MITER = new LineJoin; static ROUND = new LineJoin;
                        toString() { switch (this) { case BEVEL: return "bevel"; case MITER: return "miter"; case ROUND: return "round" } }
                    };

                    colors = {fill: new Graphics.Color(255, 255, 255), gradient: {
                        colors: new List, // NOTE (Lapys) -> List of `Color` objects.
                        points: new List, // NOTE (Lapys) -> List of `Coordinate` objects.
                        type: null
                    }, stroke: new Graphics.Color(+0, +0, +0)};
                    coordinates = new Graphics.Coordinate;
                    filters = {}; // CONSIDER (Lapys) -> Probably not.
                    line = {cap: LineCap.BUTT, dashOffset: +0, join: LineJoin.ROUND, width: 1};
                    opacity = {fill: 1, stroke: 1};
                    overlay = new List; // NOTE (Lapys) -> List of `Drawable` objects.
                    pattern = null; // NOTE (Lapys) -> `Image` object.
                    transforms = {rotation: {anchor: Graphics.Positions.CENTER, angle: +0}, translation: new Graphics.Coordinate, scale: new Graphics._2D_Vector, skew: new Graphics._2D_Vector};

                    // [...] --- MINIFY (Lapys) --- WARN (Lapys) -> Duplicated code
                    constructor(options) { const options = Object(arguments[0]);
                        /* [Colors] */ if (options.hasOwnProperty("colors")) { const colors = Object(options.colors); colors.hasOwnProperty("fill") && (this.colors.fill = colors.fill); colors.hasOwnProperty("stroke") && (this.colors.stroke = colors.stroke); if (colors.hasOwnProperty("gradient")) { const gradient = Object(colors.gradient); gradient.hasOwnProperty("colors") && (this.colors.gradient.colors = gradient.colors); gradient.hasOwnProperty("points") && (this.colors.gradient.points = gradient.points); gradient.hasOwnProperty("type") && (this.colors.gradient.type = gradient.type) } } else { options.hasOwnProperty("fillColor") && (this.colors.fill = options.fillColor); options.hasOwnProperty("gradientColor") && (this.colors.gradient = options.gradientColor); options.hasOwnProperty("strokeColor") && (this.colors.stroke = options.strokeColor); if (options.hasOwnProperty("gradient")) { const gradient = Object(options.gradient); gradient.hasOwnProperty("colors") && (this.colors.gradient.colors = gradient.colors); gradient.hasOwnProperty("points") && (this.colors.gradient.points = gradient.points); gradient.hasOwnProperty("type") && (this.colors.gradient.type = gradient.type) } }
                        /* [Coordinates] */ if (options.hasOwnProperty("coordinates")) { const coordinates = Object(options.coordinates); coordinates.hasOwnProperty('x') && (this.coordinates.x = coordinates.x); coordinates.hasOwnProperty('y') && (this.coordinates.y = coordinates.y) } else { options.hasOwnProperty('x') && (this.coordinates.x = options.x); options.hasOwnProperty('y') && (this.coordinates.y = options.y) }
                        /* [Line] */ if (options.hasOwnProperty("line")) { const line = Object(options.line); line.hasOwnProperty("cap") && (this.line.cap = line.cap); line.hasOwnProperty("dashOffset") && (this.line.dashOffset = line.dashOffset); line.hasOwnProperty("join") && (this.line.join = line.join); line.hasOwnProperty("width") && (this.line.width = line.width) } else { options.hasOwnProperty("lineCap") && (this.line.cap = options.lineCap); options.hasOwnProperty("lineDashOffset") && (this.line.dashOffset = options.lineDashOffset); options.hasOwnProperty("lineJoin") && (this.line.join = options.lineJoin); options.hasOwnProperty("lineWidth") && (this.line.width = options.lineWidth) }
                        /* [Opacity] */ if (options.hasOwnProperty("opacity")) { const opacity = Object(options.opacity); opacity.hasOwnProperty("fill") && (this.opacity.fill = opacity.fill); opacity.hasOwnProperty("stroke") && (this.opacity.stroke = opacity.stroke) } else { options.hasOwnProperty("fillOpacity") && (this.opacity.fill = options.fillOpacity); options.hasOwnProperty("strokeOpacity") && (this.opacity.stroke = options.strokeOpacity) }
                        /* [Overlay] */ options.hasOwnProperty("overlay") && (this.overlay = options.overlay);
                        /* [Transforms] */ if (options.hasOwnProperty("transforms")) { const transforms = Object(options.transforms); if (transforms.hasOwnProperty("rotation")) { const rotation = Object(transforms.rotation); if (rotation.hasOwnProperty("anchor")) { const anchor = Object(rotation.anchor); anchor.hasOwnProperty('x') && (this.transforms.rotation.anchor.x = anchor.x); anchor.hasOwnProperty('y') && (this.transforms.rotation.anchor.y = anchor.y) } else { rotation.hasOwnProperty('x') && (this.transforms.rotation.anchor.x = rotation.x); rotation.hasOwnProperty('y') && (this.transforms.rotation.anchor.y = rotation.y) } rotation.hasOwnProperty("angle") && (this.transforms.rotation.angle = rotation.angle) } if (transforms.hasOwnProperty("translation")) { const translation = Object(transforms.translation); translation.hasOwnProperty('x') && (this.transforms.translation.x = translation.x); translation.hasOwnProperty('y') && (this.transforms.translation.y = translation.y) } if (transforms.hasOwnProperty("scale")) { const scale = Object(transforms.scale); scale.hasOwnProperty('x') && (this.transforms.scale.x = scale.x); scale.hasOwnProperty('y') && (this.transforms.scale.y = scale.y) } if (transforms.hasOwnProperty("skew")) { const skew = Object(transforms.skew); skew.hasOwnProperty('x') && (this.transforms.skew.x = skew.x); skew.hasOwnProperty('y') && (this.transforms.skew.y = skew.y) } } else { if (options.hasOwnProperty("rotation")) { const rotation = Object(options.rotation); if (rotation.hasOwnProperty("anchor")) { const anchor = Object(rotation.anchor); anchor.hasOwnProperty('x') && (this.transforms.rotation.anchor.x = anchor.x); anchor.hasOwnProperty('y') && (this.transforms.rotation.anchor.y = anchor.y) } else { rotation.hasOwnProperty('x') && (this.transforms.rotation.anchor.x = rotation.x); rotation.hasOwnProperty('y') && (this.transforms.rotation.anchor.y = rotation.y) } rotation.hasOwnProperty("angle") && (this.transforms.rotation.angle = rotation.angle) } if (options.hasOwnProperty("translation")) { const translation = Object(options.translation); translation.hasOwnProperty('x') && (this.transforms.translation.x = translation.x); translation.hasOwnProperty('y') && (this.transforms.translation.y = translation.y) } if (options.hasOwnProperty("scale")) { const scale = Object(options.scale); scale.hasOwnProperty('x') && (this.transforms.scale.x = scale.x); scale.hasOwnProperty('y') && (this.transforms.scale.y = scale.y) } if (options.hasOwnProperty("skew")) { const skew = Object(options.skew); skew.hasOwnProperty('x') && (this.transforms.skew.x = skew.x); skew.hasOwnProperty('y') && (this.transforms.skew.y = skew.y) } }
                    }

                    get fillColor() { return this.colors.fill }
                    set fillColor(color) { return (this.colors.fill = color) }
                    get fillOpacity() { return this.opacity.fill }
                    set fillOpacity(range) { return (this.opacity.fill = range) }
                    get gradient() { return this.colors.gradient }
                    get lineCap() { return this.line.cap }
                    set lineCap(cap) { return (this.line.cap = cap) }
                    get lineDashOffset() { return this.line.dashOffset }
                    set lineDashOffset(size) { return (this.line.dashOffset = size) }
                    get lineJoin() { return this.line.join }
                    set lineJoin(join) { return (this.line.join = join) }
                    get lineWidth() { return this.line.width }
                    set lineWidth(size) { return (this.line.width = size) }
                    get rotation() { return this.transforms.rotation }
                    set rotation(angle) { return (this.transform.rotation = angle) }
                    get scale() { return this.transforms.scale }
                    set scale(size) { return (this.transform.scale = size) }
                    get skew() { return this.transforms.skew }
                    set skew(sizes) { return (this.transform.skew = sizes) }
                    get strokeColor() { return this.colors.stroke }
                    set strokeColor(color) { return (this.colors.stroke = color) }
                    get strokeOpacity() { return this.opacity.stroke }
                    set strokeOpacity(range) { return (this.opacity.stroke = range) }
                    get translation() { return this.transforms.translation }
                    set translation(coordinates) { return (this.transform.translation = coordinates) }
                    get x() { return this.coordinates.x }
                    set x(coordinate) { return (this.coordinates.x = coordinate) }
                    get y() { return this.coordinates.y }
                    set y(coordinate) { return (this.coordinates.y = coordinate) }
                };
                static #Drawable = class Drawable { // CONSIDER (Lapys) -> Probably should be called `Entity`.
                    static toCoordinates(drawable, coordinates) { const coordinates = Object(DynamicCoordinates);
                        let evaluation = new Graphics.Coordinate;

                        if (coordinates instanceof Graphics.Coordinate) evaluation = coordinates;
                        else if (coordinates instanceof Graphics.DrawOptions.DynamicCoordinates) {
                            let height = null, width = null;

                            if (coordinates & Graphics.Positions.CENTER) { evaluation.x = (null === width ? drawable.getWidth() : width) / 2; evaluation.y = (null === height ? drawable.getHeight() : height) / 2 }
                            (coordinates & Graphics.Positions.BOTTOM) && (evaluation.y = null === height ? drawable.getHeight() : height);
                            (coordinates & Graphics.Positions.LEFT) && (evaluation.x = +0);
                            (coordinates & Graphics.Positions.RIGHT) && (evaluation.x = null === width ? drawable.getWidth() : width);
                            (coordinates & Graphics.Positions.TOP) && (evaluation.y = +0);
                        }

                        return evaluation
                    }
                };

                /* [Derived] */
                static Arc = class Arc extends Graphics.Drawable {};
                static Image = class Image extends Graphics.Drawable {};
                static Particle = class Particle extends Graphics.Drawable {};
                static #Shape = class Shape extends Graphics.Drawable {};
                static Text = class Text extends Graphics.Drawable {};

                static Circle = function Circle() { return new Graphics.Ellipse() };
                static Ellipse = class Ellipse extends Graphics.Shape {};
                static Line = function Line() { return new Arc() };
                static Polygon = class Polygon extends Graphics.Shape {};
                static Rectangle = class Rectangle extends Graphics.Shape {
                    beveled = false;
                    chamfered = false;
                    cornerRadii = [+0, +0, +0, +0];
                    height = +0;
                    rounded = false;
                    width = +0;

                    constructor(height, width, details) { if ((arguments.length || 1) ^ 1) {
                        const details = Object(arguments[2]);

                        this.height = height;
                        this.width = width;

                        (details.hasOwnProperty("beveled") && (+0 === this.beveled + this.chamfered + this.rounded)) && (this.beveled = Boolean(details.beveled));
                        (details.hasOwnProperty("chamfered") && (+0 === this.beveled + this.chamfered + this.rounded)) && (this.chamfered = Boolean(details.chamfered));
                        (details.hasOwnProperty("rounded") && (+0 === this.beveled + this.chamfered + this.rounded)) && (this.rounded = Boolean(details.rounded));

                        if (details.hasOwnProperty("cornerRadii")) { const radii = Array.from(details.cornerRadii);
                            for (let iterator = +0, length = radii.length; ~iterator; --iterator)
                            this.cornerRadii = radii[iterator]
                        }
                    } }

                    getHeight() { return this.height }
                    getWidth() { return this.width }
                };
                static Square = function Square(size, details) { return new Rectangle(size, size, details) };
                static Star = function Star() { return new Polygon() };
                static Triangle = function Triangle() { return new Polygon() };

            /* Function */
                // : Create Buffer --- NOTE (Lapys) -> Buffers are `CanvasRenderingContext2D` objects.
                // : Has Available Buffer
                // : To Next Buffer
                #CreateBuffer() { return document.createElement("canvas").getContext("2d") }
                #HasAvailableBuffer() { return +0 == this.BufferList.length }
                #ToNextBuffer() {
                    // Logic > ...
                    if (~this.CurrentBufferIndex) {
                        (this.BufferList.length == ++this.CurrentBufferIndex) &&
                        (this.CurrentBufferIndex = +0); // WARN (Lapys) -> Might be slow here.
                    } else this.CurrentBufferIndex = +0;

                    // Return
                    return this.BufferList[this.CurrentBufferIndex]
                }

                // Draw ... --- CHECKPOINT (Lapys) -> Implement skew transformation.
                draw(drawable, options, operation) { if (this.HasAvailableBuffer()) {
                    // Constant > (Buffer (Render), Options, Render)
                    const buffer = this.ToNextBuffer();
                    const bufferRender = buffer.canvas;
                    const options = new Graphics.DrawOptions(arguments[1]);
                    const render = this.Render;

                    options.coordinates = Graphics.Drawable.toCoordinates(drawable, options.coordinates);
                    options.transforms.rotation.anchor = Graphics.Drawable.toCoordinates(drawable, options.transforms.rotation.anchor);
                    options.transforms.translation = Graphics.Drawable.toCoordinates(drawable, options.transforms.translation);

                    transforms = {rotation: {anchor: new Graphics.Coordinate, angle: +0}, translation: new Graphics.Coordinate, scale: new Graphics._2D_Vector, skew: new Graphics._2D_Vector};

                    this.GlobalCompositeOperation = arguments.length > 2 ? operation : "source-over";

                    (bufferRender.height ^ render.height) && (bufferRender.height = render.height);
                    (bufferRender.width ^ render.width) && (bufferRender.width = render.width);

                    buffer.moveTo(options.coordinates.x, options.coordinates.y);
                    buffer.scale(options.transforms.scale.x, options.transforms.scale.y);
                    buffer.translate(options.transforms.translate.x, options.transforms.translate.y);
                    if (360 == (options.transforms.rotation.angle || 360)) {
                        const drawableCenterCoordinates = drawable.getCenterCoordinates();

                        buffer.moveTo(drawableCenterCoordinates.x + options.coordinates.x, drawableCenterCoordinates.y + options.coordinates.y);
                        buffer.rotate(options.transforms.rotation * (Math.PI / 180));
                        buffer.moveTo(options.coordinates.x, options.coordinates.y);
                    }

                    (null === options.gradient.type) || (buffer.fillStyle = options.color.fill.toString());
                    if (options.line.width) {
                        buffer.lineCap = options.line.cap.toString();
                        buffer.lineDashOffset = options.line.dashOffset;
                        buffer.lineJoin = options.line.join.toString();
                        buffer.lineWidth = options.line.width;
                        buffer.strokeStyle = options.color.stroke.toString()
                    }

                    (buffer.globalAlpha == this.GlobalAlpha) || (buffer.globalAlpha = this.GlobalAlpha);
                    (buffer.globalCompositeOperation == this.GlobalCompositeOperation) || (buffer.globalCompositeOperation = this.GlobalCompositeOperation);

                    // ...
                    this["draw" + drawable.constructor.name](drawable, this.BufferList[this.CurrentBufferIndex], options);

                    /* ROTATION */
                    buffer.translate(-options.transforms.translate.x, -options.transforms.translate.y);
                    buffer.scale(-options.transforms.scale.x, -options.transforms.scale.y);

                    for (let iterator = +0, length = options.overlay.length; iterator ^ length; ++iterator)
                    this.draw(options.overlay[iterator])
                } }

                drawArc(arc, buffer, options) {}
                drawEllipse(ellipse, buffer, options) {}
                drawImage(image, buffer, options) {}
                drawParticle(particle, buffer, options) {}
                drawPolygon(polygon, buffer, options) {}
                drawRectangle(rectangle, buffer, options) {
                    options.color.fill, options.color.gradient
                    options.opacity.fill, options.opacity.stroke

                    buffer.fillRect()
                    buffer.strokeRect()

                    options = {
                        transforms = {rotation: +0, translation: {x: +0, y: +0}, scale: +0, skew: {x: +0, y: +0}};
                    }
                }

                // Clear Buffer(s) --- NOTE (Lapys) -> Erase any drawings on the buffer.
                clearBuffer(index) { const buffer = this.BufferList[index]; buffer.clearRect(+0, +0, buffer.canvas.width, buffer.canvas.height) }
                clearBuffers() { for (let iterator = this.BufferList.length - 1; ~iterator; --iterator) clearBuffer(iterator) }

                // : Erase
                // : Get Random Color
                // : Set Buffer Count
                erase(drawable, options) { this.draw(drawable, options, "destination-out") }
                getRandomColor() { let color = new Graphics.Color(); let value = Math.random(); color.blue = Math.trunc(value *= 255); value -= Math.trunc(value); color.green = Math.trunc(value *= 255); value -= Math.trunc(value); color.red = Math.trunc(value *= 255); return color }
                setBufferCount(count) { let iterator = this.BufferList.length; if (iterator < count) { while (count ^ iterator++) this.BufferList.add(this.CreateBuffer()) } }

            /* Phase */
                /* Initiate */
                INITIATE(render) {
                    // Modification > Target > ...
                    this.Coordinate = this.Coordinate(this);
                    this.Render = render;
                    this.SubPixelRendering = true;

                    // ...
                    RESET()
                }

                /* Reset */
                RESET() {
                    // Modification > Target > ...
                    this.BufferList = new List;
                    this.CurrentBufferIndex = -1;
                    this.GlobalCompositeOperation = "source-over";
                    this.Opacity = 1;

                    this.setBufferCount(3 /* CHECKPOINT (Lapys) -> Should be `2`. */)
                }
        }
    }

    /* Constant > Game --- REDACT (Lapys) */
    const Game = new class Game {
        /* Function */
            // Add Entity Type
            static addEntityType(constructor) {};

            // Remove Entity Type
            static removeEntityType(constructor) {};
    };

    /* [Public Interface] Modification > Global > ... */
    Object.defineProperty(global, "Game", {configurable: false, enumerable: true, value: Game, writable: false});
    Object.defineProperty(global, "Graphics", {configurable: true, enumerable: true, value: Graphics, writable: false})
}("undefined" == typeof(self) ? ("undefined" == typeof(window) ? ("undefined" == typeof(global) ? (function() { return this })() : global) : window) : self);

const canvas = document.createElement("canvas");
const context = canvas.getContext("2d");
const graphics = new Graphics(canvas);

canvas.height = 500;
canvas.width = 500;

document.body.appendChild(canvas);
