/* Game
    --- NOTE (Lapys) -> May utilize older JavaScript features for clearer & more efficient programming.
    --- WARN (Lapys) -> Assertion (or exception handling) is minimal due to JavaScript's design.
*/
; void function Game(Global) {
    /* Class */
        /* Enum... --- NOTE (Lapys) -> Keyed list of enumerable (whole integer) values. */
        class Enumeration {
            // : Constant > Maximum Unique Enumerable Size --- NOTE (Lapys) -> Maximum number of `Enumerable` values that can be stored within a `Number`.
            // : Class > Enumerable
            static MAX_UNIQUE_ENUMERABLE_SIZE = Enumeration.getLeastRepresentableByteSize(Number.MAX_SAFE_INTEGER);
            static Enumerable;

            // [Constructor]
            constructor() {
                // Constant > (Length, ...)
                // : Class > Integer
                const length = arguments.length;
                const isUniquelyRepresentable = length < Enumeration.MAX_UNIQUE_ENUMERABLE_SIZE;

                const Integer = isUniquelyRepresentable ? Number : BigInt;

                // Loop > Modification > Target; Continue
                for (let index = Integer(1), iterator = length - 1; ~iterator; --iterator) {
                    this[arguments[iterator]] = index;
                    isUniquelyRepresentable ? index *= Integer(2) : ++index
                }
            }

            // Function > (Get Least Representable Byte Size, Of)
            static getLeastRepresentableByteSize(number) { let iterator = number, size = +0; while (iterator) { ++size; iterator /= 2; iterator = Math.trunc(iterator) } return size ? size + 1 : 1 }
            of(constructor) { for (let enumerable in this) this[enumerable] = new constructor(this[enumerable]); return this }
        }; const Enumerable = (Enumeration.Enumerable = class Enumerable extends Number { constructor(value) { super(Math.trunc(Number.parseFloat(value) || +0)) } });

        /* List --- NOTE (Lapys) -> List of values. */
        class List extends Array {
            // Initialization > (First, Last)
            get first() { return this.length ? this[+0] : undefined }
            set first(value) { this[+0] = value }

            get last() { return this.length ? this[this.length - 1] : undefined }
            set last(value) { this[(this.length || 1) - 1] = value }

            // Function
            // : From --- NOTE (Lapys) -> Create `List` object from `list` argument.
            static from(list) { if ("object" == typeof(list) && null !== list) { if (list instanceof Array) return list; else { const evaluation = new this; for (let iterator = +0, length = list.length; iterator ^ length; ++iterator) evaluation.push(list[iterator]); return evaluation } } return new this }

            // : Add, Build, ... Index Of, For Each, Free, Includes, Pop ..., Push, Remove ..., Shrink, Resize
            add() { Array.prototype.push.apply(this, arguments); return this }
            build(handler) { const list = this; list.foreach(function _build(element, index) { list[index] = handler(element, index, list) }); return list }
            firstIndexOf(value) { for (let iterator = +0, length = this.length; iterator ^ length; ++iterator) if (value === this[iterator]) return iterator; return -1 }
            foreach() { Array.prototype.forEach.apply(this, arguments); return this }
            free() { List.prototype.resize.call(this, +0); return this }
            includes(value) { return +0 != ~(this.length >>> 14 ? List.prototype.indexOf.call(this, value) : List.prototype.firstIndexOf.call(this, value)) }
            indexOf(value) { const length = this.length; if (length >>> 14) { for (let endIterator = length - 1, middleStartIterator = Math.trunc(length / 2), middleEndIterator = middleStartIterator + !(length % 2), startIterator = +0; endIterator >= middleEndIterator || startIterator <= middleStartIterator; (--endIterator, ++middleEndIterator, --middleStartIterator, ++startIterator)) switch (value) { case this[endIterator]: return endIterator; case this[middleEndIterator]: return middleEndIterator; case this[middleStartIterator]: return middleStartIterator; case this[startIterator]: return startIterator } } else { switch (length) { case 0: return -1; case 2: if (value == array[1]) return 1; case 1: if (value == array[0]) return +0 } for (let endIterator = length - 1, startIterator = +0; endIterator >= startIterator; (--endIterator, ++startIterator)) switch (value) { case this[endIterator]: return endIterator; case this[startIterator]: return startIterator } } return -1 }
            lastIndexOf(value) { for (let iterator = this.length - 1; ~iterator; --iterator) if (value === this[iterator]) return iterator; return -1 }
            pop(value) { const index = List.prototype.indexOf.call(this, value); ~index && Array.prototype.splice.call(this, index, 1); return this }
            popFirst(value) { const index = List.prototype.firstIndexOf.call(this, value); ~index && Array.prototype.splice.call(this, index, 1); return this }
            popLast(value) { const index = List.prototype.lastIndexOf.call(this, value); ~index && Array.prototype.splice.call(this, index, 1); return this }
            push(value) { Array.prototype.push.call(this, value); return this }
            remove() { for (let iterator = +0, length = arguments.length; iterator ^ length; ++iterator) length = this.pop(arguments[iterator]); return this }
            removeFirst() { for (let iterator = +0, length = arguments.length; iterator ^ length; ++iterator) length = this.popFirst(arguments[iterator]); return this }
            removeLast() { for (let iterator = +0, length = arguments.length; iterator ^ length; ++iterator) length = this.popLast(arguments[iterator]); return this }
            shrink(count) { undefined === count ? Array.prototype.pop.call(this) : this.length -= count; return this }
            resize(length) { this.length = length; return this }
        };

        // (Immutable, Static) Object --- NOTE (Lapys) -> Deeply qualifies properties to be immutable. --- MINIFY (Lapys)
        function ImmutableObject(object) { if (this instanceof ImmutableObject) throw new TypeError("`ImmutableObject` is not a constructor"); else for (const identifier in object) { const descriptor = Object.getOwnPropertyDescriptor(object, identifier); descriptor.configurable = false; descriptor.writable = false; ("value" in descriptor && (null !== descriptor.value && "object" == typeof(descriptor.value))) && ImmutableObject(descriptor.value); Object.defineProperty(object, identifier, descriptor) } return ImmutableReference(object) }
        function StaticObject(object) { if (this instanceof ImmutableObject) throw new TypeError("`StaticObject` is not a constructor"); else for (const identifier in object) { const descriptor = Object.getOwnPropertyDescriptor(object, identifier); descriptor.configurable = false; descriptor.writable = false; ("value" in descriptor && (null !== descriptor.value && "object" == typeof(descriptor.value))) && ImmutableObject(descriptor.value); Object.defineProperty(object, identifier, descriptor) } return StaticReference(object) }

        // (Immutable, Static) Reference --- NOTE (Lapys) -> Qualifies immediate properties to be immutable. --- MINIFY (Lapys)
        function ImmutableReference(object) { if (this instanceof ImmutableReference) throw new TypeError("`ImmutableReference` is not a constructor"); else Object.freeze(object); return object }
        function StaticReference(object) { if (this instanceof ImmutableReference) throw new TypeError("`StaticReference` is not a constructor"); else Object.seal(object); return object }

    /* Namespace */
        /* Scroll Wheel Direction... */
        const ScrollWheelDirection = class ScrollWheelDirection extends Enumerable {};
        const ScrollWheelDirections = ImmutableReference(new class ScrollWheelDirectionEnumeration extends Enumeration {}(
            "DOWN", "UP"
        ).of(ScrollWheelDirection));

        /* Primitive --- NOTE (Lapys) -> Private wrapper for `Object` methods. */
        const Primitive = new class Primitive {
            /* Class > Class --- NOTE (Lapys) -> Universal JavaScript style for creating classes.
                - Additional check for construction/ initialization via `new` done to prevent ambiguous/ redundant code.
                - Useful for actually declaring private variables.
            */
            Class = function Class(constructor, prototype) { (undefined === prototype) || (constructor.prototype = prototype); return this instanceof Class ? new constructor : constructor };

            // Function
            // : Define
            define(object, identifier, descriptor) {
                // Logic > ...
                if (undefined === descriptor) Object.defineProperty(object, identifier, {configurable: true, enumerable: false, value: undefined, writable: true});
                else if (
                    null === descriptor ||
                    "object" != typeof(descriptor) ||
                    Object.prototype !== Object.getPrototypeOf(descriptor)
                ) Object.defineProperty(object, identifier, {configurable: true, enumerable: true, value: descriptor, writable: true});
                else {
                    // Constant > (Accessor, Mutator), Evaluation
                    const accessor = "get" in descriptor ? descriptor.get : null, mutator = "set" in descriptor ? descriptor.set : null;
                    const evaluation = {configurable: true, enumerable: true, get: undefined, set: undefined, value: undefined, writable: true};

                    // Modification > Evaluation > (Configurable, Enumerable, Writable)
                    ("mutable" in descriptor) && (evaluation.configurable = evaluation.writable = Boolean(descriptor.mutable));
                    ("configurable" in descriptor) && (evaluation.configurable = Boolean(descriptor.configurable));
                    ("enumerable" in descriptor) && (evaluation.enumerable = Boolean(descriptor.enumerable));
                    ("writable" in descriptor) && (evaluation.writable = Boolean(descriptor.writable));

                    // Logic
                    if ("internal" in descriptor && descriptor.internal && (null !== accessor || null !== mutator)) {
                        // Initialization > Internal
                        let internal = "value" in descriptor ? descriptor.value : undefined;

                        // Modification > Evaluation > (Get, Set)
                        evaluation.get = null === accessor ? function() { return internal } : function() { return accessor.call(this, internal) };
                        evaluation.set = null === mutator ? function(value) { internal = value } : function(value) { internal = mutator.call(this, value, internal) };

                        // Deletion
                        delete evaluation.value;
                        delete evaluation.writable
                    }

                    else if ("value" in descriptor) {
                        // Modification > Evaluation > Value; Deletion
                        evaluation.value = descriptor.value;
                        delete evaluation.get; delete evaluation.set
                    }

                    else if (null !== accessor || null !== mutator) {
                        // Modification > Evaluation > (Get, Set); Deletion
                        null === accessor ? delete evaluation.get : evaluation.get = accessor;
                        null === mutator ? delete evaluation.set : evaluation.set = mutator;

                        delete evaluation.value;
                        delete evaluation.writable
                    }

                    else {
                        // Modification > Evaluation > Value; Deletion
                        evaluation.value = undefined;
                        delete evaluation.get; delete evaluation.set
                    }

                    // Modification > Object > [Identifier]
                    Object.defineProperty(object, identifier, evaluation)
                }
            }

            // : (Is) Defined
            // : Describe
            // : From
            defined(object, identifier) { return Object.hasOwnProperty.call(object, identifier) }
            describe(object, identifier) { return undefined === identifier ? Object.getOwnPropertyDescriptors(object) : Object.getOwnPropertyDescriptor(object, identifier) }
            from(argument) { return Object(argument) }

            // : Undefine
            undefine(object, identifier) {
                // Deletion; Logic
                delete object[identifier];
                if (Object.hasOwnProperty.call(object, identifier)) {
                    // Modification > Object > [Identifier]; Deletion
                    Object.defineProperty(object, identifier, {configurable: true, enumerable: true, value: undefined, writable: true});
                    return delete object[identifier]
                }

                // Return
                return true
            }
        };

        /* Key... */
        const Key = class Key extends Enumerable {
            // Function > To String
            toString() { switch (this) {
                case Keys.ADD: return '+';
                case Keys.AMPERSAND: return '&';
                case Keys.AT: return '@';
                case Keys.BACKQUOTE: return '`';
                case Keys.BACKSLASH: return '\\';
                case Keys.BACKSPACE: return '\b';
                case Keys.CARET: return '^';
                case Keys.COLON: return ':';
                case Keys.COMMA: return ',';
                case Keys.DECIMAL: case Keys.PERIOD: return '.';
                case Keys.DIGIT0: return '0';
                case Keys.DIGIT1: return '1';
                case Keys.DIGIT2: return '2';
                case Keys.DIGIT3: return '3';
                case Keys.DIGIT4: return '4';
                case Keys.DIGIT5: return '5';
                case Keys.DIGIT6: return '6';
                case Keys.DIGIT7: return '7';
                case Keys.DIGIT8: return '8';
                case Keys.DIGIT9: return '9';
                case Keys.DIVIDE: return '/';
                case Keys.DOLLAR: return '$';
                case Keys.DOUBLE_QUOTE: return '"';
                case Keys.ENTER: return '\n';
                case Keys.EQUAL: return '=';
                case Keys.ESCAPE: return '\r';
                case Keys.EXCLAMATION: return '!';
                case Keys.GREATER_THAN: return '>';
                case Keys.HASH: return '#';
                case Keys.LEFT_BRACE: return '{';
                case Keys.LEFT_BRACKET: return '[';
                case Keys.LEFT_PARENTHESIS: return '(';
                case Keys.LESSER_THAN: return '<';
                case Keys.LOWERCASE_A: return 'a';
                case Keys.LOWERCASE_B: return 'b';
                case Keys.LOWERCASE_C: return 'c';
                case Keys.LOWERCASE_D: return 'd';
                case Keys.LOWERCASE_E: return 'e';
                case Keys.LOWERCASE_F: return 'f';
                case Keys.LOWERCASE_G: return 'g';
                case Keys.LOWERCASE_H: return 'h';
                case Keys.LOWERCASE_I: return 'i';
                case Keys.LOWERCASE_J: return 'j';
                case Keys.LOWERCASE_K: return 'k';
                case Keys.LOWERCASE_L: return 'l';
                case Keys.LOWERCASE_M: return 'm';
                case Keys.LOWERCASE_N: return 'n';
                case Keys.LOWERCASE_O: return 'o';
                case Keys.LOWERCASE_P: return 'p';
                case Keys.LOWERCASE_Q: return 'q';
                case Keys.LOWERCASE_R: return 'r';
                case Keys.LOWERCASE_S: return 's';
                case Keys.LOWERCASE_T: return 't';
                case Keys.LOWERCASE_U: return 'u';
                case Keys.LOWERCASE_W: return 'w';
                case Keys.LOWERCASE_X: return 'x';
                case Keys.LOWERCASE_Y: return 'y';
                case Keys.LOWERCASE_Z: return 'z';
                case Keys.MULTIPLY: return '*';
                case Keys.NUMBER_PAD0: return '0';
                case Keys.NUMBER_PAD1: return '1';
                case Keys.NUMBER_PAD2: return '2';
                case Keys.NUMBER_PAD3: return '3';
                case Keys.NUMBER_PAD4: return '4';
                case Keys.NUMBER_PAD5: return '5';
                case Keys.NUMBER_PAD6: return '6';
                case Keys.NUMBER_PAD7: return '7';
                case Keys.NUMBER_PAD8: return '8';
                case Keys.NUMBER_PAD9: return '9';
                case Keys.PERCENTAGE: return '%';
                case Keys.QUESTION: return '?';
                case Keys.QUOTE: return '\'';
                case Keys.RIGHT_BRACE: return '}';
                case Keys.RIGHT_BRACKET: return ']';
                case Keys.RIGHT_PARENTHESIS: return ')';
                case Keys.SEMICOLON: return ';';
                case Keys.SINGLE_QUOTE: return '\'';
                case Keys.SLASH: return '/';
                case Keys.SPACEBAR: return ' ';
                case Keys.SUBTRACT: return '-';
                case Keys.TAB: return '\t';
                case Keys.TILDE: return '`';
                case Keys.UNDERSCORE: return '_';
                case Keys.UPPERCASE_A: return 'A';
                case Keys.UPPERCASE_B: return 'B';
                case Keys.UPPERCASE_C: return 'C';
                case Keys.UPPERCASE_D: return 'D';
                case Keys.UPPERCASE_E: return 'E';
                case Keys.UPPERCASE_F: return 'F';
                case Keys.UPPERCASE_G: return 'G';
                case Keys.UPPERCASE_H: return 'H';
                case Keys.UPPERCASE_I: return 'I';
                case Keys.UPPERCASE_J: return 'J';
                case Keys.UPPERCASE_K: return 'K';
                case Keys.UPPERCASE_L: return 'L';
                case Keys.UPPERCASE_M: return 'M';
                case Keys.UPPERCASE_N: return 'N';
                case Keys.UPPERCASE_O: return 'O';
                case Keys.UPPERCASE_P: return 'P';
                case Keys.UPPERCASE_Q: return 'Q';
                case Keys.UPPERCASE_R: return 'R';
                case Keys.UPPERCASE_S: return 'S';
                case Keys.UPPERCASE_T: return 'T';
                case Keys.UPPERCASE_U: return 'U';
                case Keys.UPPERCASE_W: return 'W';
                case Keys.UPPERCASE_X: return 'X';
                case Keys.UPPERCASE_Y: return 'Y';
                case Keys.UPPERCASE_Z: return 'Z';
                case Keys.VERTICAL_BAR: return '|';
                default: return ""
            } }
        };
        const Keys = ImmutableReference(new class KeyEnumeration extends Enumeration {}(
            // [Application Selector]
            "LAUNCH_CALCULATOR", "LAUNCH_CALENDER", "LAUNCH_CONTACTS",
            "LAUNCH_MAIL", "LAUNCH_MEDIA_PLAYER", "LAUNCH_MUSIC_PLAYER", "LAUNCH_MY_COMPUTER",
            "LAUNCH_PHONE",
            "LAUNCH_SCREEN_SAVER", "LAUNCH_SPREADSHEET",
            "LAUNCH_WEB_BROWSER", "LAUNCH_WEB_CAMERA", "LAUNCH_WORD_PROCESSOR",
            "LAUNCH_APPLICATION1", "LAUNCH_APPLICATION2", "LAUNCH_APPLICATION3", "LAUNCH_APPLICATION4", "LAUNCH_APPLICATION5", "LAUNCH_APPLICATION6", "LAUNCH_APPLICATION7", "LAUNCH_APPLICATION8", "LAUNCH_APPLICATION9", "LAUNCH_APPLICATION10", "LAUNCH_APPLICATION11", "LAUNCH_APPLICATION12", "LAUNCH_APPLICATION13", "LAUNCH_APPLICATION14", "LAUNCH_APPLICATION15", "LAUNCH_APPLICATION16",

            // [Audio Control]
            "AUDIO_BALANCE_LEFT", "AUDIO_BALANCE_RIGHT",
            "AUDIO_BASS_DOWN", "AUDIO_BASS_BOOST_DOWN", "AUDIO_BASS_BOOST_TOGGLE", "AUDIO_BASS_BOOST_UP", "AUDIO_BASS_UP",
            "AUDIO_FADER_FRONT", "AUDIO_FADER_REAR",
            "AUDIO_SURROUND_MODE_NEXT",
            "AUDIO_TREBLE_DOWN", "AUDIO_TREBLE_UP",
            "AUDIO_VOLUME_DOWN", "AUDIO_VOLUME_MUTE", "AUDIO_VOLUME_UP",
            "MICROPHONE_TOGGLE",
            "MICROPHONE_VOLUME_DOWN", "MICROPHONE_VOLUME_MUTE", "MICROPHONE_VOLUME_UP",

            // [Browser Control]
            "BROWSER_BACK",
            "BROWSER_FAVORITES", "BROWSER_FORWARD",
            "BROWSER_HOME", "BROWSER_REFRESH",
            "BROWSER_SEARCH", "BROWSER_STOP",

            // [Composition & Input Method Editing]
            "ALL_CANDIDATES", "ALPHANUMERIC",
            "CODE_INPUT", "COMPOSE", "CONVERT",
            "DEAD", "EISU", "FINAL_MODE",
            "GROUP_FIRST", "GROUP_LAST", "GROUP_NEXT", "GROUP_PREVIOUS",
            "HANGUL_MODE", "HANKAKU", "HANJA_MODE", "HIRAGANA", "HIRAGANA_KATAKANA",
            "JUNJA_MODE",
            "KANA_MODE", "KANJI_MODE", "KATAKANA",
            "MODE_CHANGE",
            "NEXT_CANDIDATE", "NON_CONVERT",
            "PREVIOUS_CANDIDATE", "PROCESS",
            "ROMAJI", "SINGLE_CANDIDATE",
            "ZENKAKU", "ZENKAKU_HANAKU",

            // [Control]
            "ALT_GRAPH", "CAPS_LOCK",
            "FUNCTION", "FUNCTION_LOCK",
            "HYPER",
            "LEFT_ALT", "LEFT_CONTROL", "LEFT_SHIFT",
            "META", "NUMBER_LOCK",
            "RIGHT_ALT", "RIGHT_CONTROL", "RIGHT_SHIFT",
            "SCROLL_LOCK", "SUPER", "SYMBOL", "SYMBOL_LOCK",

            // [Device]
            "BRIGHTNESS_DOWN", "BRIGHTNESS_UP",
            "EJECT", "HIBERNATE", "LOG_OFF",
            "POWER", "POWER_OFF", "PRINT_SCREEN",
            "STANDBY", "WAKE_UP",

            // [Document]
            "CLOSE",
            "MAIL_FORWARD", "MAIL_REPLY", "MAIL_SEND",
            "NEW", "OPEN", "PRINT",
            "SAVE", "SPELL_CHECK",

            // [Edit]
            "BACKSPACE",
            "CLEAR", "COPY", "CURSOR_SELECT", "CUT",
            "DELETE",
            "ERASE_END_OF_FIELD", "EXTEND_SELECT",
            "INSERT", "PASTE", "REDO", "UNDO",

            // [Function]
            "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24",
            "SOFT1", "SOFT2", "SOFT3", "SOFT4",

            // [Media Controller]
            "AVR_INPUT", "AVR_POWER",
            "COLOR_F0_RED", "COLOR_F1_GREEN", "COLOR_F2_YELLOW", "COLOR_F3_BLUE", "COLOR_F4_GRAY", "COLOR_F5_BROWN",
            "CLOSED_CAPTION_TOGGLE", "DIMMER", "DISPLAY_SWAP", "DVR", "EXIT",
            "FAVORITE_CLEAR0", "FAVORITE_CLEAR1", "FAVORITE_CLEAR2", "FAVORITE_CLEAR3",
            "FAVORITE_RECALL0", "FAVORITE_RECALL1", "FAVORITE_RECALL2", "FAVORITE_RECALL3",
            "FAVORITE_STORE0", "FAVORITE_STORE1", "FAVORITE_STORE2", "FAVORITE_STORE3",
            "GUIDE", "GUIDE_NEXT_DAY", "GUIDE_PREVIOUS_DAY",
            "INFORMATION", "INSTANT_REPLAY",
            "LINK", "LIST_PROGRAM", "LIVE_CONTENT", "LOCK",
            "MEDIA_APPLICATIONS", "MEDIA_AUDIO_TRACK",
            "MEDIA_LAST",
            "MEDIA_SKIP_BACKWARD", "MEDIA_SKIP_FORWARD",
            "MEDIA_STEP_BACKWARD", "MEDIA_STEP_FORWARD",
            "MEDIA_TOP_MENU",
            "NAVIGATE_IN", "NAVIGATE_NEXT", "NAVIGATE_OUT", "NAVIGATE_PREVIOUS",
            "NEXT_FAVORITE_CHANNEL", "NEXT_USER_PROFILE",
            "ON_DEMAND", "PAIRING",
            "PIN_P_DOWN", "PIN_P_MOVE", "PIN_P_TOGGLE", "PIN_P_UP",
            "PLAY_SPEED_DOWN", "PLAY_SPEED_RESET", "PLAY_SPEED_UP",
            "RANDOM_TOGGLE", "RECORD_SPEED_NEXT", "REMOTE_CONTROL_LOW_BATTERY", "RADIO_FREQUENCY_BYPASS",
            "SCAN_CHANNELS_TOGGLE", "SCREEN_MODE_NEXT", "SETTINGS", "SPLIT_SCREEN_TOGGLE",
            "SET_TOP_BOX_INPUT", "SET_TOP_BOX_POWER",
            "SUBTITLE", "TELETEXT", "VIDEO_MODE_NEXT", "WINK", "ZOOM_TOGGLE",

            // [Multimedia Keys]
            "CHANNEL_DOWN", "CHANNEL_UP",
            "MEDIA_FAST_FORWARD", "MEDIA_PAUSE", "MEDIA_PLAY", "MEDIA_PLAY_PAUSE", "MEDIA_RECORD", "MEDIA_REWIND", "MEDIA_STOP", "MEDIA_TRACK_NEXT", "MEDIA_TRACK_PREVIOUS",

            // [Navigation]
            "ARROW_DOWN", "ARROW_LEFT", "ARROW_RIGHT", "ARROW_UP",
            "END", "HOME",
            "PAGE_DOWN", "PAGE_UP",

            // [Numeric]
            "ADD", "CLEAR",
            "DECIMAL", "DIVIDE", "EQUAL",
            "KEY11", "KEY12",
            "MULTIPLY",
            "NUMBER_PAD0", "NUMBER_PAD1", "NUMBER_PAD2", "NUMBER_PAD3", "NUMBER_PAD4", "NUMBER_PAD5", "NUMBER_PAD6", "NUMBER_PAD7", "NUMBER_PAD8", "NUMBER_PAD9",
            "SEPARATOR", "SUBTRACT",

            // [Phone]
            "APP_SWITCH",
            "CALL", "CAMERA", "CAMERA_FOCUS",
            "END_CALL",
            "GO_BACK", "GO_HOME",
            "HEADSET_HOOK", "LAST_NUMBER_REDIAL", "NOTIFICATION", "MANNER_MODE", "VOICE_DIAL",

            // [Special]
            "UNIDENTIFIED",

            // [Speech Recognition]
            "SPEECH_CORRECTION_LIST", "SPEECH_INPUT_TOGGLE",

            // [TV Control]
            "TV", "TV_3D_MODE",
            "TV_ANTENNA_CABLE",
            "TV_AUDIO_DESCRIPTION", "TV_AUDIO_DESCRIPTION_MIX_DOWN", "TV_AUDIO_DESCRIPTION_MIX_UP",
            "TV_CONTENTS_MENU", "TV_DATA_SERVICE",
            "TV_INPUT",
            "TV_INPUT_COMPONENT1", "TV_INPUT_COMPONENT2", "TV_INPUT_COMPOSITE1", "TV_INPUT_COMPOSITE2",
            "TV_INPUT_HDMI1", "TV_INPUT_HDMI2", "TV_INPUT_HDMI3", "TV_INPUT_HDMI4",
            "TV_INPUT_VGA1", "TV_MEDIA_CONTEXT", "TV_NETWORK", "TV_NUMBER_ENTRY", "TV_POWER", "TV_RADIO_SERVICE",
            "TV_SATELLITE", "TV_SATELLITE_BROADCAST", "TV_SATELLITE_COMMUNICATION", "TV_SATELLITE_TOGGLE",
            "TV_TERRESTRIAL_ANALOG", "TV_TERRESTRIAL_DIGITAL",
            "TV_TIMER",

            // [User Interface]
            "ACCEPT", "AGAIN", "ATTENTION",
            "CANCEL", "CONTEXT_MENU",
            "ESCAPE", "EXECUTE",
            "FIND", "FINISH",
            "HELP",
            "PAUSE", "PLAY", "PROPERTIES",
            "SELECT",
            "ZOOM_IN", "ZOOM_OUT",

            // [Whitespace]
            "ENTER", "SPACEBAR", "TAB",

            // [...]
            "AMPERSAND", "AT",
            "BACKSLASH", "BACKQUOTE",
            "CARET", "COLON", "COMMA",
            "DIGIT0", "DIGIT1", "DIGIT2", "DIGIT3", "DIGIT4", "DIGIT5", "DIGIT6", "DIGIT7", "DIGIT8", "DIGIT9",
            "DOLLAR",
            "EJECT", "EXCLAMATION",
            "GREATER_THAN", "HASH",
            "LEFT_BRACE", "LEFT_BRACKET", "LEFT_PARENTHESIS",
            "LESSER_THAN",
            "LOWERCASE_A", "LOWERCASE_B", "LOWERCASE_C", "LOWERCASE_D", "LOWERCASE_E", "LOWERCASE_F", "LOWERCASE_G", "LOWERCASE_H", "LOWERCASE_I", "LOWERCASE_J", "LOWERCASE_K", "LOWERCASE_L", "LOWERCASE_M", "LOWERCASE_N", "LOWERCASE_O", "LOWERCASE_P", "LOWERCASE_Q", "LOWERCASE_R", "LOWERCASE_S", "LOWERCASE_T", "LOWERCASE_U", "LOWERCASE_W", "LOWERCASE_X", "LOWERCASE_Y", "LOWERCASE_Z",
            "PERCENTAGE", "PERIOD",
            "QUESTION", "QUOTE",
            "RIGHT_BRACE", "RIGHT_BRACKET", "RIGHT_PARENTHESIS",
            "SEMICOLON", "SLASH",
            "TILDE", "UNDERSCORE",
            "UPPERCASE_A", "UPPERCASE_B", "UPPERCASE_C", "UPPERCASE_D", "UPPERCASE_E", "UPPERCASE_F", "UPPERCASE_G", "UPPERCASE_H", "UPPERCASE_I", "UPPERCASE_J", "UPPERCASE_K", "UPPERCASE_L", "UPPERCASE_M", "UPPERCASE_N", "UPPERCASE_O", "UPPERCASE_P", "UPPERCASE_Q", "UPPERCASE_R", "UPPERCASE_S", "UPPERCASE_T", "UPPERCASE_U", "UPPERCASE_W", "UPPERCASE_X", "UPPERCASE_Y", "UPPERCASE_Z",
            "VERTICAL_BAR"
        ).of(Key));

        /* Game */
        const Game = new Primitive.Class(function Game() { const Game = this;
            // Initialization > (Initiator, Pending Count, Tick Speed, Updater)
            let initiator;
            let pendingCount = 0n;
            let tickSpeed = 1000 / 60;
            let updater;

            // Update > (Updater, Initiator)
            updater = function UPDATE() {};
            initiator = function GameInitiateMainLoop() { initiator = function GameInitiateMainLoop() {};
                // Initialization > (Current, Recent) Timestamp
                let currentTimestamp = Clock.now();
                let recentTimestamp = currentTimestamp;

                // ...
                Game.INITIATE(); void function _ongametick() {
                    // Update > Current Timestamp
                    // Logic > ... Updater
                    currentTimestamp = Clock.now();
                    if (currentTimestamp - recentTimestamp >= tickSpeed) {
                        recentTimestamp = currentTimestamp;
                        updater(true)
                    } else updater(false);

                    // ...
                    Clock.tick(_ongametick)
                }()
            };

            // Modification > Game > ...
            Game.getTickSpeed = function getTickSpeed() { return tickSpeed };
            Game.isPending = function isPending() { return 0n != pendingCount };
            Game.pend = function pend() { return ++pendingCount };
            Game.preload = ("undefined" == typeof(XMLHttpRequest) ?
                function preload(url) {
                    // Constant > Request
                    const request = new Request(url, {cache: "force-cache", method: "GET", mode: "cors"});

                    // ...; Fetch
                    Game.pend();
                    fetch(request, {
                        cache: request.cache,
                        credentials: request.credentials,
                        headers: request.headers,
                        integrity: request.integrity,
                        keepalive: request.keepalive,
                        method: request.method,
                        mode: request.mode,
                        redirect: request.redirect,
                        referrer: request.referrer,
                        referrerPolicy: request.referrerPolicy,
                        signal: request.signal
                    }).then(Game.unpend)
                } : function preload(url) {
                    // Constant > (Request, ...)
                    const request = new XMLHttpRequest;
                    let onunpend;

                    // Update > ...
                    onunpend = function unpend() { Game.unpend(); onunpend = function unpend() {} };
                    Game.pend();

                    // Event > Request > (Error, Load End, Timeout)
                    request.addEventListener("error", onunpend);
                    request.addEventListener("loadend", onunpend);
                    request.addEventListener("timeout", onunpend);

                    // Request > (Open, Send)
                    request.open("GET", url, true, null, null);
                    request.send(null)
                }
            );
            Game.unpend = function unpend() { return 0n == (pendingCount ? --pendingCount : pendingCount) };
            Game.setTickSpeed = function setTickSpeed(speed) { return tickSpeed = speed };

            Primitive.define(Game, "INITIATE", {internal: true, set(value, internal) { initiator(); return "function" == typeof(value) ? value : internal }, value: function INITIATE() { initiator() }});
            Primitive.define(Game, "RESET", {internal: true, set(value, internal) { return "function" == typeof(value) ? value : internal }, value: function RESET() {}});
            Primitive.define(Game, "UPDATE", {internal: false, get() { return updater }, set(value) { ("function" == typeof(value)) && (updater = value) }});
            Primitive.define(Game, "TERMINATE", {internal: true, set(value, internal) { return "function" == typeof(value) ? value : internal }, value: function TERMINATE() {}})
        }, {
            // Class > (Animations, Components, Entity, Events, Graphics, Scene)
            // : ...
            Animations: null, Clock: null, Components: {Renderable: null}, Entity: null, Events: null, Graphics: null, Scene: null,
            getTickSpeed: null, isPending: null, pend: null, preload: null, unpend: null, setTickSpeed: null
        });

        /* Graphics --- CONSIDER (Lapys) -> Multiple buffering? --- NOTE (Lapys) -> 2D graphics only. */
        const Graphics = (Game.Graphics = Primitive.Class(function Graphics() { const graphics = this;
            // Constant > (Render, Renderer)
            let render = null;
            let renderer = null;

            /* Modification > Graphics */ {
                // Composite Operation
                Primitive.define(graphics, "compositeOperation", {
                    mutable: false,
                    get() { switch (renderer.globalCompositeOperation) {
                        case "color": return Graphics.CompositeOperations.COLOR;
                        case "color-burn": return Graphics.CompositeOperations.COLOR_BURN;
                        case "color-dodge": return Graphics.CompositeOperations.COLOR_DODGE;
                        case "copy": return Graphics.CompositeOperations.COPY;
                        case "darken": return Graphics.CompositeOperations.DARKEN;
                        case "destination-atop": return Graphics.CompositeOperations.DESTINATION_ATOP;
                        case "destination-in": return Graphics.CompositeOperations.DESTINATION_IN;
                        case "destination-over": return Graphics.CompositeOperations.DESTINATION_OVER;
                        case "destination-out": return Graphics.CompositeOperations.DESTINATION_OUT;
                        case "difference": return Graphics.CompositeOperations.DIFFERENCE;
                        case "exclusion": return Graphics.CompositeOperations.EXCLUSION;
                        case "hard-light": return Graphics.CompositeOperations.HARD_LIGHT;
                        case "hue": return Graphics.CompositeOperations.HUE;
                        case "lighten": return Graphics.CompositeOperations.LIGHTEN;
                        case "lighter": return Graphics.CompositeOperations.LIGHTER;
                        case "luminosity": return Graphics.CompositeOperations.LUMINOSITY;
                        case "multiply": return Graphics.CompositeOperations.MULTIPLY;
                        case "overlay": return Graphics.CompositeOperations.OVERLAY;
                        case "saturation": return Graphics.CompositeOperations.SATURATION;
                        case "screen": return Graphics.CompositeOperations.SCREEN;
                        case "soft-light": return Graphics.CompositeOperations.SOFT_LIGHT;
                        case "source-atop": return Graphics.CompositeOperations.SOURCE_ATOP;
                        case "source-in": return Graphics.CompositeOperations.SOURCE_IN;
                        case "source-over": return Graphics.CompositeOperations.SOURCE_OVER;
                        case "source-out": return Graphics.CompositeOperations.SOURCE_OUT;
                        case "xor": return Graphics.CompositeOperations.XOR
                    } },
                    set(operation) { switch (operation) {
                        case Graphics.CompositeOperations.COLOR: renderer.globalCompositeOperation = "color"; break;
                        case Graphics.CompositeOperations.COLOR_BURN: renderer.globalCompositeOperation = "color-burn"; break;
                        case Graphics.CompositeOperations.COLOR_DODGE: renderer.globalCompositeOperation = "color-dodge"; break;
                        case Graphics.CompositeOperations.COPY: renderer.globalCompositeOperation = "copy"; break;
                        case Graphics.CompositeOperations.DARKEN: renderer.globalCompositeOperation = "darken"; break;
                        case Graphics.CompositeOperations.DESTINATION_ATOP: renderer.globalCompositeOperation = "destination-atop"; break;
                        case Graphics.CompositeOperations.DESTINATION_IN: renderer.globalCompositeOperation = "destination-in"; break;
                        case Graphics.CompositeOperations.DESTINATION_OVER: renderer.globalCompositeOperation = "destination-over"; break;
                        case Graphics.CompositeOperations.DESTINATION_OUT: renderer.globalCompositeOperation = "destination-out"; break;
                        case Graphics.CompositeOperations.DIFFERENCE: renderer.globalCompositeOperation = "difference"; break;
                        case Graphics.CompositeOperations.EXCLUSION: renderer.globalCompositeOperation = "exclusion"; break;
                        case Graphics.CompositeOperations.HARD_LIGHT: renderer.globalCompositeOperation = "hard-light"; break;
                        case Graphics.CompositeOperations.HUE: renderer.globalCompositeOperation = "hue"; break;
                        case Graphics.CompositeOperations.LIGHTEN: renderer.globalCompositeOperation = "lighten"; break;
                        case Graphics.CompositeOperations.LIGHTER: renderer.globalCompositeOperation = "lighter"; break;
                        case Graphics.CompositeOperations.LUMINOSITY: renderer.globalCompositeOperation = "luminosity"; break;
                        case Graphics.CompositeOperations.MULTIPLY: renderer.globalCompositeOperation = "multiply"; break;
                        case Graphics.CompositeOperations.OVERLAY: renderer.globalCompositeOperation = "overlay"; break;
                        case Graphics.CompositeOperations.SATURATION: renderer.globalCompositeOperation = "saturation"; break;
                        case Graphics.CompositeOperations.SCREEN: renderer.globalCompositeOperation = "screen"; break;
                        case Graphics.CompositeOperations.SOFT_LIGHT: renderer.globalCompositeOperation = "soft-light"; break;
                        case Graphics.CompositeOperations.SOURCE_ATOP: renderer.globalCompositeOperation = "source-atop"; break;
                        case Graphics.CompositeOperations.SOURCE_IN: renderer.globalCompositeOperation = "source-in"; break;
                        case Graphics.CompositeOperations.SOURCE_OVER: renderer.globalCompositeOperation = "source-over"; break;
                        case Graphics.CompositeOperations.SOURCE_OUT: renderer.globalCompositeOperation = "source-out"; break;
                        case Graphics.CompositeOperations.XOR: renderer.globalCompositeOperation = "xor"
                    } }
                });

                // Anti-Aliasing, Opacity, Sub-Pixel Rendering
                Primitive.define(graphics, "antiAliasing", {mutable: false, get() { return render.imageSmoothingEnabled }, set(value) { renderer.imageSmoothingEnabled = Boolean(value) }});
                Primitive.define(graphics, "opacity", {mutable: false, get() { return renderer.globalAlpha }, set(range) { renderer.globalAlpha = Math.wrap(Number.from(range), 1) }});
                Primitive.define(graphics, "subPixelRendering", {internal: true, mutable: false});

                // Set Render
                graphics.setRender = function setRender() {
                    render = arguments[0];
                    renderer = Graphics.Renderer(render)
                }
            }

            // Graphics > Set Render
            // : Modification > Graphics > ...
            graphics.setRender(arguments.length ? arguments[0] ?? new Graphics.Render : new Graphics.Render);
            graphics.compositeOperation = Graphics.CompositeOperations.SOURCE_OVER
        }, {
            resolveCoordinate(coordinate) { return this.subPixelRendering ? coordinate : Math.trunc(coordinate) },
            resolveCoordinates(coordinates) { return new Graphics.Coordinates(this.resolveCoordinate(coordinates.x), this.resolveCoordinate(coordinates.y)) },
            setRender: null
        })); {
            /* ... */
            class ColorValue extends Number {};
            class Scalar extends Number {};

            // Composite Operations, Colors, Filters, Gradient Patterns, Line (Caps, Joins), Positions
            Primitive.define(Graphics, "CompositeOperations", {configurable: true, set(value) { Primitive.define(Graphics, "CompositeOperations", {mutable: false, value: value}) }});
            Primitive.define(Graphics, "Colors", {configurable: true, set(value) { Primitive.define(Graphics, "Colors", {mutable: false, value: value}) }});
            Primitive.define(Graphics, "Filters", {configurable: true, set(value) { Primitive.define(Graphics, "Filters", {mutable: false, value: value}) }});
            Primitive.define(Graphics, "GradientPatterns", {configurable: true, set(value) { Primitive.define(Graphics, "GradientPatterns", {mutable: false, value: value}) }});
            Primitive.define(Graphics, "LineCaps", {configurable: true, set(value) { Primitive.define(Graphics, "LineCaps", {mutable: false, value: value}) }});
            Primitive.define(Graphics, "LineJoins", {configurable: true, set(value) { Primitive.define(Graphics, "LineJoins", {mutable: false, value: value}) }});
            Primitive.define(Graphics, "Positions", {configurable: true, set(value) { Primitive.define(Graphics, "Positions", {mutable: false, value: value}) }});

            // Color
            Primitive.define(Graphics, "Color", {mutable: false, value:
                class Color {
                    // Initialization > (Alpha, Blue, Green, Red, ...)
                    get alpha() { return this.value >>> 24 }
                    set alpha(range) { this.value &= 0x0FFFFFF; return (this.value |= range ? 0x1000000 : 0x0000000) }
                    get blue() { return this.value & 0xFF }
                    set blue(range) { this.value = new ColorValue(Math.wrap(range, 255) + (this.value & 0x1FFFF00)); return range }
                    get green() { return (this.value >>> 8) & 0xFF }
                    set green(range) { this.value = new ColorValue((-~0x0000FF * Math.wrap(range, 255)) + (this.value & 0x1FF00FF)); return range }
                    get red() { return (this.value >>> 16) & 0xFF }
                    set red(range) { this.value = new ColorValue((-~0x00FFFF * Math.wrap(range, 255)) + (this.value & 0x100FFFF)); return range }
                    value = new ColorValue(0x0000000);

                    // [Constructor] --- REDACT (Lapys)
                    constructor(red, green, blue, alpha) { this.value = Color.RGBA(red ?? +0, green ?? +0, blue ?? +0, alpha ?? 1) }

                    // Function > (CMYK, Hex, HSL, RGB, RGBA, ...) --- MINIFY (Lapys) --- REDACT (Lapys)
                    static CMYK(cyan, magenta, yellow, black) { const normalized = {black: Math.abs(black) / 100, cyan: Math.abs(cyan) / 100, magenta: Math.abs(magenta) / 100, yellow: Math.abs(yellow) / 100}; return Color.RGB(Math.ceil(255 * (1 - normalized.cyan) * (1 - normalized.black)), Math.ceil(255 * (1 - normalized.magenta) * (1 - normalized.black)), Math.ceil(255 * (1 - normalized.yellow) * (1 - normalized.black))) }
                    static Hex(red, green, blue) { return Color.RGB(red, green, blue) }
                    static RGB(red, green, blue) { return Color.RGBA(red, green, blue, 1) }
                    static RGBA(red, green, blue, alpha) { return new ColorValue(Math.wrap(blue, 0xFF) + (-~0x0000FF * Math.wrap(green, 0xFF)) + (-~0x00FFFF * Math.wrap(red, 0xFF)) + (alpha << 0x18)) }
                    static HSL(hue, saturation, luminosity) { // UPDATE (Lapys)
                        let blue, green, red;
                        const normalized = {hue: Math.wrap(Math.abs(hue), 360), luminosity: Math.abs(luminosity) / 100, saturation: Math.abs(saturation) / 100};

                        const C = (1 - Math.abs((normalized.luminosity * 2) - 1)) * normalized.saturation;
                        const X = C * (1 - Math.abs(((normalized.hue / 60) % 2) - 1));
                        const m = normalized.luminosity - (C / 2);

                        if (+0 <= hue && hue < 60) { blue = +0; green = X; red = C }
                        else if (60 <= hue && hue < 120) { blue = +0; green = C; red = X }
                        else if (120 <= hue && hue < 180) { blue = X; green = C; red = +0 }
                        else if (180 <= hue && hue < 240) { blue = C; green = X; red = +0 }
                        else if (240 <= hue && hue < 300) { blue = C; green = +0; red = X }
                        else if (300 <= hue && hue < 360) { blue = x; green = +0; red = C }

                        return Color.RGB((red + m) * 255, (green + m) * 255, (blue + m) * 255, 1)
                    }

                    toString() { return "rgba(" + this.red + ", " + this.green + ", " + this.blue + ", " + this.alpha + ')' }
                    valueOf() { return this.value }
                }
            });

            // Coordinates, Dynamic Coordinates, Vector
            Primitive.define(Graphics, "Vector", {mutable: false, value:
                Primitive.Class(function Vector() { const vector = this;
                    // Modification > Vector > (X, Y)
                    Primitive.define(vector, 'x', {internal: true, set: function x(scalar) { return Number.from(scalar) }, value: +0});
                    Primitive.define(vector, 'y', {internal: true, set: function y(scalar) { return Number.from(scalar) }, value: +0})
                }, {
                    x: +0, y: +0,
                    toScalar() { new Scalar(Math.sqrt((this.x * this.x) + (this.y * this.y))) }
                })
            });
            Primitive.define(Graphics, "DynamicCoordinates", {enumerable: false, mutable: false, value: class DynamicCoordinates extends Enumerable {}});
            Primitive.define(Graphics, "Coordinates", {mutable: false, value: class Coordinates extends Graphics.Vector {}});

            // Filter ...
            Primitive.define(Graphics, "FilterList", {mutable: false, value: class FilterList extends List {}});
            Primitive.define(Graphics, "Filter", {mutable: false, value:
                class Filter {
                    // [Constructor]
                    // : Function > To String
                    constructor(name, parameters) {
                        // Constant > Length
                        const length = arguments.length;

                        // Logic > ... Modification > Target > To String
                        if (length) {
                            let source = String(name) + '('; for (let iterator = 1; iterator ^ length; ++iterator) source += arguments[iterator]; source += ')';
                            this.toString = function toString() { return source }
                        } else this.toString = function toString() { return Filter.prototype.toString.call(this) }
                    }
                    toString() { return "none" }
                }
            });

            // Gradient ...
            Primitive.define(Graphics, "GradientPattern", {enumerable: false, mutable: false, value: class GradientPattern extends Enumerable {}});
            Primitive.define(Graphics, "GradientStop", {mutable: false, value: class GradientStop extends Graphics.Color { range = +0; constructor(red, green, blue, alpha, range) { super(red, green, blue, alpha); this.range = range } get range() { return this.range } set range(range) { return (this.range = range % 2) } }});
            Primitive.define(Graphics, "GradientStopList", {mutable: false, value: class GradientStopList extends List { add() { for (var iterator = +0, length = arguments.length; iterator ^ length; ++iterator) GradientStopList.prototype.push.call(this, arguments[iterator]) } getLastStopRange() { const last = this.last; return last ? last.range : +0 } push(stop) { const range = this.getLastStopRange(); List.prototype.push.call(this, stop); (range > stop.range) && List.prototype.sort.call(this, (x, y) => { return (x.range < y.range) * -1 }) } }});

            // Graphic ...
            Primitive.define(Graphics, "GraphicCollection", {mutable: false, value: class GraphicCollection extends List {}});
            Primitive.define(Graphics, "Graphic", {enumerable: false, mutable: false, value:
                Primitive.Class(function Graphic() { const graphic = this;
                    // Initialization > ...
                    let rotationAngle = +0;

                    // Modification > Target > (Coordinates, Filters, Opacity, Overlays, Transforms)
                    Primitive.define(graphic, "coordinates", {mutable: false, value: new Graphics.Coordinates});
                    Primitive.define(graphic, "filters", {mutable: false, value: new Graphics.FilterList});
                    Primitive.define(graphic, "opacity", {internal: true, mutable: false, set(value) { return Math.wrap(Number.from(value), 1) }, value: 1});
                    Primitive.define(graphic, "overlays", {mutable: false, value: new Graphics.GraphicCollection});
                    Primitive.define(graphic, "transforms", {mutable: false,
                        value: ImmutableReference({
                            rotation: ImmutableReference({
                                anchor: new Graphics.Coordinates,
                                get angle() { return rotationAngle },
                                set angle(angle) { rotationAngle = Math.wrap(Number.from(angle), 360) }
                            }),
                            translation: new Graphics.Coordinates,
                            scale: new Graphics.Vector,
                            skew: new Graphics.Vector
                        })
                    })
                }, {
                    // Initialization > ...
                    coordinates: null, filters: null, opacity: null, overlays: null, transforms: null,
                    get rotation() { return this.rotation },
                    set rotation(angle) { return this.rotation.angle = angle },
                    get translation() { return this.translation },
                    get scale() { return this.scale },
                    get skew() { return this.skew },
                    get x() { return this.coordinates.x },
                    set x(coordinate) { this.coordinates.x = coordinate },
                    get y() { return this.coordinates.y },
                    set y(coordinate) { this.coordinates.y = coordinate },

                    // Function > Draw --- CHECKPOINT (Lapys)
                    draw() {}
                })
            });

            // Geometry
            Primitive.define(Graphics, "Geometry", {enumerable: false, mutable: false, value:
                class Geometry extends Graphics.Graphic {
                    // Initialization > (Colors, Gradients, Line, Patterns, ...)
                    colors; gradients; line; patterns;

                    get color() { return this.colors.stroke }
                    set color(color) { this.colors.stroke = color }
                    get gradients() { return this.gradients.stroke }
                    get lineCap() { return this.line.cap }
                    set lineCap(cap) { this.line.cap = cap }
                    get lineDashOffset() { return this.line.dashOffset }
                    set lineDashOffset(offset) { this.line.dashOffset = offset }
                    get lineJoin() { return this.line.join }
                    set lineJoin(join) { this.line.join = join }
                    get lineWidth() { return this.line.width }
                    set lineWidth(size) { this.line.width = size }
                    get pattern() { return this.patterns.stroke }
                    set pattern(image) { this.patterns.stroke = image }

                    // [Constructor]
                    constructor() { super(); const geometry = this;
                        // Constant > ...
                        const paintPlaceholder = {get fill() { return null }, stroke: null};

                        // Modification > Geometry > ...
                        Primitive.define(geometry, "colors", {mutable: false, value: paintPlaceholder});
                        Primitive.define(geometry.colors, "stroke", {internal: true, mutable: false, set(color, internal) { return Primitive.from(color) instanceof Graphics.Color ? color : internal }, value: Graphics.Colors.BLACK});

                        Primitive.define(geometry, "gradients", {mutable: false, value: paintPlaceholder});
                        Primitive.define(geometry.gradients, "stroke", {mutable: false, value: {stops: null, type: null}});
                        Primitive.define(geometry.gradients.stroke, "stops", {mutable: false, value: new Graphics.GradientStopList});
                        Primitive.define(geometry.gradients.stroke, "type", {internal: true, mutable: false, set(pattern, internal) { return Primitive.from(pattern) instanceof Graphics.GradientPattern ? pattern : internal }, value: null});

                        Primitive.define(geometry, "line", {cap: null, dashOffset: null, join: null, width: null});
                        Primitive.define(geometry.line, "cap", {internal: true, mutable: false, set(cap, internal) { return Primitive.from(cap) instanceof Graphics.LineCap ? cap : internal }, value: Graphics.LineCaps.BUTT});
                        Primitive.define(geometry.line, "dashOffset", {internal: true, mutable: false, set(offset) { return Number.from(offset) }, value: +0});
                        Primitive.define(geometry.line, "join", {internal: true, mutable: false, set(join, internal) { return Primitive.from(join) instanceof Graphics.LineJoin ? join : internal }, value: Graphics.LineJoins.BUTT});
                        Primitive.define(geometry.line, "width", {internal: true, mutable: false, set(size) { return Number.from(size) }, value: 1});

                        Primitive.define(geometry, "patterns", {mutable: false, value: paintPlaceholder});
                        Primitive.define(geometry.patterns, "stroke", {internal: true, mutable: false, set(image, internal) { return Primitive.from(image) instanceof Graphics.Image ? image : internal }, value: null});
                    }
                }
            });

            // Image
            Primitive.define(Graphics, "Image", {mutable: false, value:
                class Image extends Global.Image {
                    // [Constructor]
                    constructor(url) { if (arguments.length) {
                        // Constant > (Image, Target)
                        const image = this;
                        const target = Events.onready.target;

                        // Event > Image > Ready
                        Events.onready.listen(image).invoke(event => {
                            // Logic > Modification > Image > ...
                            if (event.success) {
                                image.height = image.naturalHeight;
                                image.width = image.naturalWidth
                            } else image.src = ""
                        }).listen(target)
                    } }
                }
            });

            // Line (Cap, Join)
            Primitive.define(Graphics, "LineCap", {enumerable: false, mutable: false, value: class LineCap extends Enumerable {}});
            Primitive.define(Graphics, "LineJoin", {enumerable: false, mutable: false, value: class LineJoin extends Enumerable {}});

            // Preset Filter
            Primitive.define(Graphics, "PresetFilter", {enumerable: false, mutable: false, value: function PresetFilter(name) { return function PresetFilter(parameters) { return new Graphics.Filter(name, parameters ?? "") } }});

            // Render, Renderer
            Primitive.define(Graphics, "Render", {enumerable: false, mutable: false, value: function Render(height, width) { const canvas = document.createElement("canvas"); canvas.height = height ?? +0; canvas.width = width ?? +0; return canvas }});
            Primitive.define(Graphics, "Renderer", {enumerable: false, mutable: false, value: function Renderer(render) { return HTMLCanvasElement.prototype.getContext.call(render, "2d") }});

            // Shape
            Primitive.define(Graphics, "Shape", {enumerable: false, mutable: false, value:
                class Shape extends Graphics.Geometry {
                    // Initialization > ...
                    get color() { return this.colors.fill }
                    set color(color) { this.colors.fill = color }
                    get gradients() { return this.gradients.fill }
                    get pattern() { return this.patterns.fill }
                    set pattern(image) { this.patterns.fill = image }

                    // [Constructor]
                    constructor() { super(); const shape = this;
                        // Modification > Target > ...
                        Primitive.define(shape.colors, "fill", {internal: true, mutable: false, set(color, internal) { return Primitive.from(color) instanceof Graphics.Color ? color : internal }, value: Graphics.Colors.TRANSPARENT});
                        Primitive.define(shape.gradients, "fill", {mutable: false, value: {stops: null, type: null}});
                        Primitive.define(shape.gradients.fill, "stops", {mutable: false, value: new Graphics.GradientStopList});
                        Primitive.define(shape.gradients.fill, "type", {internal: true, mutable: false, set(pattern, internal) { return Primitive.from(pattern) instanceof Graphics.GradientPattern ? pattern : internal }, value: null});
                        Primitive.define(shape.patterns, "fill", {internal: true, mutable: false, set(image, internal) { return Primitive.from(image) instanceof Graphics.Image ? image : internal }, value: null})
                    }
                }
            });

            /* ... */ {
                // Line
                Primitive.define(Graphics, "Line", {mutable: false, value: class Line extends Graphics.Geometry {}});
                Primitive.define(Graphics, "Spline", {enumerable: false, mutable: false, value: class Spline extends Graphics.Geometry {}}); {
                    Primitive.define(Graphics, "BezierSpline", {mutable: false, value: class BezierSpline extends Graphics.Spline {}});
                    Primitive.define(Graphics, "QuadraticSpline", {mutable: false, value: class QuadraticSpline extends Graphics.Spline {}})
                }

                // Shape
                Primitive.define(Graphics, "Arc", {mutable: false, value: class Arc extends Graphics.Shape {}});
                Primitive.define(Graphics, "Circle", {mutable: false, value: class Circle extends Graphics.Shape {}});
                Primitive.define(Graphics, "Ellipse", {mutable: false, value: class Ellipse extends Graphics.Shape {}});
                Primitive.define(Graphics, "Oval", {mutable: false, value: class Oval extends Graphics.Shape {}});
                Primitive.define(Graphics, "Polygon", {mutable: false, value: class Polygon extends Graphics.Shape {}});
                Primitive.define(Graphics, "Rectangle", {mutable: false, value: class Rectangle extends Graphics.Shape {}}); {
                    Primitive.define(Graphics, "BeveledRectangle", {mutable: false, value: class BeveledRectangle extends Graphics.Rectangle {}});
                    Primitive.define(Graphics, "ChamferedRectangle", {mutable: false, value: class ChamferedRectangle extends Graphics.Rectangle {}});
                    Primitive.define(Graphics, "RoundedRectangle", {mutable: false, value: class RoundedRectangle extends Graphics.Rectangle {}})
                }
                Primitive.define(Graphics, "Square", {mutable: false, value: class Square extends Graphics.Shape {}}); {
                    Primitive.define(Graphics, "BeveledSquare", {mutable: false, value: class BeveledSquare extends Graphics.Square {}});
                    Primitive.define(Graphics, "ChamferedSquare", {mutable: false, value: class ChamferedSquare extends Graphics.Square {}});
                    Primitive.define(Graphics, "RoundedSquare", {mutable: false, value: class RoundedSquare extends Graphics.Square {}})
                }
                Primitive.define(Graphics, "Star", {mutable: false, value: class Star extends Graphics.Shape {}});

                // Graphic
                Primitive.define(Graphics, "Text", {mutable: false, value: class Text extends Graphics.Shape {}})
            }
        }

        /* Events --- NOTE (Lapys) -> Event management system. */
        const Events = new (Game.Events = Primitive.Class(function Events() { const Events = this;
            // Class > Event (Listener)
            class Event { /* NOTE (Lapys) -> Base implementation for handling event data. */ };
            const EventListener = Primitive.Class(function EventListener(invocator, constructor) {
                // Constant > Invoker
                const invoker = invocator ?? function() {};

                // Modification > Target > (Invoke, Target)
                Primitive.define(this, "invoke", {enumerable: false, mutable: false, value: function invoke(handler) { invoker(handler, this.target, constructor); return this }});
                this.target = Global
            }, {
                invoke: null, target: null,
                invoke(handler) { this.invocator(handler, this.target, this.constructor); return this },
                listen(target) { this.target = target; return this }
            });

            // Class --- NOTE (Lapys) -> Event-specific constructs.
                // Event Duration Metric
                class EventDurationMetric extends Number { elapsed; constructor(value) { super(this.elapsed = value || +0) } };

                // Key Press Metric ...
                class KeyPressMetricList extends List {};
                class KeyPressMetric extends EventDurationMetric { key; constructor(key) { this.key = key } };

                // Pointer ...
                class PointerCoordinates { x; y; constructor(x, y) { this.x = x; this.y = y } };
                class PointerCoordinatesList extends List {};
                class PointerPressMetricList extends List {};
                class PointerPressMetric extends EventDurationMetric { coordinates; constructor(coordinates) { this.coordinates = coordinates } };

            // Modification > Events > ...
            Events.EventListener = EventListener; {
                // ...
                Events.BlurEvent = class BlurEvent extends Event {};
                Events.FocusEvent = class FocusEvent extends Event {};
                Events.KeyEvent = class KeyEvent extends Event { key; constructor(key) { super(); this.key = key } };
                Events.KeyPressEvent = class KeyPressEvent extends Events.KeyEvent { metrics = new KeyPressMetricList; constructor(key) { super(key); this.metrics.push(new KeyPressMetric(key)) } };
                Events.KeyPushEvent = class KeyPushEvent extends Events.KeyEvent {};
                Events.KeyReleaseEvent = class KeyReleaseEvent extends Events.KeyEvent {};
                Events.LoadEvent = class LoadEvent extends Event {};
                Events.PointerEvent = class PointerEvent extends Event { coordinates = new PointerCoordinatesList; get x() { return this.coordinates[0].x } get y() { return this.coordinates[0].y } constructor(x, y) { super(); this.coordinates.push(new PointerCoordinates(x, y)) } };
                Events.PointerMoveEvent = class PointerMoveEvent extends Events.PointerEvent {};
                Events.PointerPressEvent = class PointerPressEvent extends Events.PointerEvent { metrics = new PointerPressMetricList; constructor(x, y) { super(x, y); this.metrics.push(new PointerPressMetric(this.coordinates[0])) } };
                Events.PointerPushEvent = class PointerPushEvent extends Events.PointerEvent {};
                Events.PointerReleaseEvent = class PointerReleaseEvent extends Events.PointerEvent {};
                Events.ResourceLoadEvent = class ResourceLoadEvent extends Events.LoadEvent { success = false; url; constructor(url) { super(); this.url = url } };
                Events.ResizeEvent = class ResizeEvent extends Event { currentHeight; currentWidth; recentHeight = +0; recentWidth = +0; constructor(height, width) { super(); this.currentHeight = height; this.currentWidth = width } };
                Events.ScrollWheelEvent = class ScrollWheelEvent extends Event { direction; constructor(direction) { this.direction = direction } }
            }
        }, {
            // Class > (..., Event Listener)
            // : ...
            BlurEvent: null, FocusEvent: null,
            KeyEvent: null, KeyPushEvent: null, KeyPressEvent: null, KeyReleaseEvent: null,
            LoadEvent: null,
            PointerEvent: null, PointerMoveEvent: null, PointerPressEvent: null, PointerPushEvent: null, PointerReleaseEvent: null,
            ResizeEvent: null, ResourceLoadEvent: null,
            ScrollWheelEvent: null,

            EventListener: null,

            onblur: null, onclick: null, ondoubleclick: null, onfocus: null,
            onready: null, onresize: null,
            onscrollwheel: null
        }));

        /* Entity */
        const Entity = (Game.Entity = class Entity extends Graphics.Graphic {
            // Class > Entity Collection
            static EntityCollection = class EntityCollection extends List {};

            // Initialization > (Children, Parents)
            children = new EntityCollection;
            parents = new EntityCollection;

            // Function > (Add Component, (Append, Remove) Child)
            addComponent(component) { const descriptors = Object.getOwnPropertyDescriptors(component); for (const identifier in descriptors) ("constructor" == identifier) || Object.defineProperty(this, identifier, descriptors[identifier]); component.call(this) }
            appendChild(entity) { (false == entity.parents.includes(this) && false == this.parents.includes(entity)) && this.children.push(entity) }
            removeChild(entity) { entity.parents.pop(this); this.children.pop(entity) }
        });

        /* Scene */
        const Scene = (Game.Scene = class Scene extends Graphics.Rectangle {
            // Function > ((Add, Remove) (Entity, Graphic), Set Background Color)
            addEntity(entity) { this.overlays.push(entity) }
            addGraphic(graphic) { this.overlays.push(graphic) }

            removeEntity(entity) { this.overlays.pop(entity) }
            removeGraphic(graphic) { this.overlays.pop(graphic) }

            setBackgroundColor(color) { this.colors.fill = color }
            setBackgroundImage(image) { this.patterns.fill = image }
        });

        /* Clock */
        const Clock = new (Game.Clock = Primitive.Class(function Clock() { const Clock = this;
            // Constant > (Ticker, Unwinder)
            const ticker = "undefined" == typeof(requestAnimationFrame) ? requestAnimationFrame : setTimeout;
            const unwinder = "undefined" == typeof(cancelAnimationFrame) ? cancelAnimationFrame : clearTimeout;

            // Modification > Clock > ... --- REDACT (Lapys)
            Clock.delay = (setTimeout === ticker ?
                function delay(callback, delay) { return ticker(callback, Number.from(delay)) } :
                function delay(callback, delay) { let start = null; const identity = ticker(function _ontick(timestamp) {
                    // Update > Start
                    // : Logic > ...
                    (null === start) && (start = timestamp);

                    if (timestamp - start < delay) ticker(_ontick);
                    else { unwinder(identity); callback(timestamp) }
                }); return identity }
            );
            Clock.now = Primitive.defined(Date, "now") && "function" == typeof(Date.now) ? Date.now : function now() { return (new Date).getTime() };
            Clock.now = ("undefined" != typeof(performance) ? (
                Primitive.defined(performance, "now") && "function" == typeof(performance.now) ? function now() { return performance.now() } : (
                    Primitive.defined(performance, "clearMarks") &&
                    Primitive.defined(performance, "getEntriesByName") &&
                    Primitive.defined(performance, "mark") &&
                    (Primitive.defined(performance, "timing") && Primitive.defined(Primitive.from(performance.timing), "navigationStart"))
                ) ? function now() {
                    performance.clearMarks("__PERFORMANCE_NOW__"); performance.mark("__PERFORMANCE_NOW__");
                    return performance.getEntriesByName("__PERFORMANCE_NOW__")[0].startTime
                } : Clock.now
            ) : Clock.now);
            Clock.pause = function pause(delay) { if (delay && "number" == typeof(delay)) { const start = Clock.now(); while (Clock.now() - start < delay) continue } };
            Clock.tick = function tick(callback) { return ticker(callback) };
            Clock.unwind = function unwind(identity) { unwinder(identity) };
            Clock.wind = ("function" == typeof(setInterval) ?
                function wind(callback, delay) { setInterval(callback, Number.from(delay)) } :
                function wind(callback, delay) { return Clock.delay(function _onwind() { Clock.delay(_onwind, delay); callback.apply(Global, arguments) }, delay) }
            )
        }, {delay: null, now: null, pause: null, tick: null, unwind: null, wind: null}));

    /* Modification */ {
        /* ... */ {
            Primitive.define(Global, "Clock", Clock);
            Primitive.define(Global, "Entity", Entity);
            Primitive.define(Global, "Enumerable", Enumerable);
            Primitive.define(Global, "Enumeration", Enumeration);
            Primitive.define(Global, "Events", Events);
            Primitive.define(Global, "Keys", Keys);
            Primitive.define(Global, "List", List);
            Primitive.define(Global, "Game", Game);
            Primitive.define(Global, "Graphics", Graphics);
            Primitive.define(Global, "Scene", Scene);

            Primitive.defined(Math, "clamp") || Primitive.define(Math, "clamp", function clamp(number, minimum, maximum) { return number <= minimum ? minimum : number >= maximum ? maximum : number });
            Primitive.defined(Math, "perc") || Primitive.define(Math, "perc", function perc(base, exponent) { return base * (exponent / 100) });
            Primitive.defined(Math, "wrap") || Primitive.define(Math, "wrap", function wrap(number, range) { return number % (range + 1) });
            Primitive.defined(Math, "unsign") || Primitive.define(Math, "unsign", function unsign(number) { return ((number >> 53) ^ number) - (number >> 53) });

            Primitive.defined(Number, "from") || Primitive.define(Number, "from", function from(argument) { return Number.parseFloat(argument) || +0 });

            Primitive.defined(String.prototype, "remove") || Primitive.define(String.prototype, "remove", function from(match) { return String.prototype.replace.call(this, match, "") })
        }

        /* Events */ { const EventListener = Events.EventListener;
            function cancelEvent(event) { if (event.cancelable) { event.preventDefault(); event.stopPropagation() } }
            function PointerEvent(event, Event = Events.PointerEvent) { // WARN (Lapys) -> Not a constructor.
                let pointerPushEvent;

                if (event instanceof TouchEvent) { const eventTouches = event.touches; pointerPushEvent = new Event; for (let iterator = +0, length = eventTouches.length; iterator ^ length; ++iterator) pointerPushEvent.addCoordinates(eventTouches[iterator].clientX, eventTouches[iterator].clientY) }
                else pointerPushEvent = new Event(event.clientX, event.clientY);

                return pointerPushEvent
            }

            // On ... --- NOTE (Lapys) -> General event listener functionality.
            Events.onblur = new EventListener((handler, target, Event) => {
                if (target instanceof EventTarget) target.addEventListener("blur", function _onblur(event) {
                    cancelEvent(event);
                    handler(ImmutableReference(new Event), target)
                }, {capture: true, once: false, passive: false}, true)
            }, Events.BlurEvent);

            Events.onclick = new EventListener((handler, target, Event) => { // WARN (Lapys) -> Does not track right clicks.
                if (target instanceof EventTarget) target.addEventListener("click", function _onclick(event) {
                    cancelEvent(event);
                    handler(ImmutableReference(new Event(event.clientX, event.clientY)), target)
                })
            }, Events.PointerEvent);

            Events.ondoubleclick = new EventListener((handler, target, Event) => { // WARN (Lapys) -> Does not track right double-clicks.
                if (target instanceof EventTarget) target.addEventListener("dblclick", function _ondoubleclick(event) {
                    cancelEvent(event);
                    handler(ImmutableReference(new Event(event.clientX, event.clientY)), target)
                })
            }, Events.PointerEvent);

            Events.onfocus = new EventListener((handler, target, Event) => {
                if (target instanceof EventTarget) target.addEventListener("focus", function _onfocus(event) {
                    cancelEvent(event);
                    handler(ImmutableReference(new Event), target)
                }, {capture: true, once: false, passive: false}, true)
            }, Events.FocusEvent);

            Events.onkeypress = new EventListener((handler, target, Event) => {
                target.addEventListener("keypress", function _onkeypress(event) {
                    cancelEvent(event);
                    handler(ImmutableReference(new Event(Events.getAssociatedKey(event))), target)
                }, {capture: true, once: false, passive: false}, true)
            }, Events.KeyPressEvent);

            Events.onkeyup = new EventListener((handler, target, Event) => {
                target.addEventListener("keyup", function _onkeyup(event) {
                    cancelEvent(event);
                    handler(ImmutableReference(new Event(Events.getAssociatedKey(event))), target)
                }, {capture: true, once: false, passive: false}, true)
            }, Events.KeyReleaseEvent);

            Events.onscrollwheel = new EventListener((handler, target, Event) => {
                if (target instanceof EventTarget)
                target.addEventListener("wheel", function _onscrollwheel(event) {
                    cancelEvent(event);
                    handler(ImmutableReference(new Event(event.deltaY < 0 ? Events.ScrollWheelEvent.Directions.DOWN : Events.ScrollWheelEvent.Directions.UP)), target)
                }, {capture: true, once: false, passive: false}, true)
            }, Events.ScrollWheelEvent);

            // On Key Down
            Events.onkeydown = new EventListener((handler, target, Event) => {
                // Initialization > Is Pushing
                // : Constant > ...
                let isPushing = false;
                const targets = {blur: Events.onblur.target, keypress: Events.onkeypress.target, keyup: Events.onkeyup.target};

                // Function > ...
                function unpush() { isPushing = false }

                // Event > Target > (Blur, Key (Press, Up))
                Events.onblur.listen(target).invoke(unpush).listen(targets.blur);
                Events.onkeypress.listen(target).invoke(function(event) { if (false == isPushing) { isPushing = true; handler(ImmutableReference(new Event(event.key)), target) } }).listen(targets.keypress);
                Events.onkeyup.listen(target).invoke(unpush).listen(targets.keyup)
            }, Events.KeyPushEvent);

            // On Pointer Down
            Events.onpointerdown = new EventListener((handler, target, Event) => {
                // Initialization > Is Pending
                let isPending = false;

                // Function > ... --- REDACT (Lapys)
                function _onpointerdown(event) { if (false == isPending) {
                    isPending = true; Clock.tick(unpend);
                    cancelEvent(event); handler(ImmutableReference(new PointerEvent(event, Event)), target)
                } } function unpend() { isPending = false }

                // Event > Target > (Mouse Down, Pointer Down, Touch Start)
                target.addEventListener("mousedown", _onpointerdown, {capture: true, once: false, passive: false}, true);
                target.addEventListener("pointerdown", _onpointerdown, {capture: true, once: false, passive: false}, true);
                target.addEventListener("touchstart", _onpointerdown, {capture: true, once: false, passive: false}, true)
            }, Events.PointerPushEvent);

            // On Pointer Move
            Events.onpointermove = new EventListener((handler, target, Event) => { // CONSIDER (Lapys) -> Is this efficient?
                // Initialization > Is Pending
                let isPending = false;

                // Function > ... --- REDACT (Lapys)
                function _onpointermove(event) { if (false == isPending) {
                    isPending = true; Clock.tick(unpend);
                    cancelEvent(event); handler(ImmutableReference(new PointerEvent(event, Event)), target)
                } } function unpend() { isPending = false }

                // Event > Target > (Mouse Move, Pointer Move, Touch Move)
                target.addEventListener("mousemove", _onpointermove, {capture: true, once: false, passive: false}, true);
                target.addEventListener("pointermove", _onpointermove, {capture: true, once: false, passive: false}, true);
                target.addEventListener("touchmove", _onpointermove, {capture: true, once: false, passive: false}, true)
            }, Events.PointerMoveEvent);

            // On Pointer Press
            Events.onpointerpress = new EventListener((handler, target, Event) => {
                // Initialization
                // : Is (Moving, Pushing)
                // : Pointer Press Event
                let isMoving = false, isPushing = false;
                let pointerPressEvent;

                // Constant > Targets
                const targets = {
                    blur: Events.onblur.target,
                    pointerdown: Events.onpointerdown.target,
                    pointermove: Events.onpointermove.target,
                    pointerup: Events.onpointerup.target
                };

                // Function > (On Pointer Press..., ...) --- CHECKPOINT (Lapys)
                function _onpointerpress() {
                    handler(ImmutableReference(pointerPressEvent), target)
                }
                function _onpointerpressed(event) { pointerPressEvent = new Event; pointerPressEvent.coordinates = event.coordinates }
                function _onpointerpressing() { if (isPushing) { Clock.tick(_onpointerpressing); _onpointerpress() } }
                function move() { isMoving = true }
                function unpend() { isMoving = isPushing = false }

                // Event > Target > (Blur, Pointer ...)
                Events.onblur.listen(target).invoke(unpend).listen(targets.blur);
                Events.onpointerdown.listen(target).invoke(function(event) { isPushing = true; _onpointerpressed(event); Clock.tick(_onpointerpressing) }).listen(targets.pointermove);
                Events.onpointermove.listen(target).invoke(function(event) { if (isMoving) _onpointerpressed(event); else if (isPushing) Clock.tick(move) }).listen(targets.pointermove);
                Events.onpointerup.listen(target).invoke(unpend).listen(targets.pointerup)
            }, Events.PointerPressEvent);

            // On Pointer Up
            Events.onpointerup = new EventListener((handler, target, Event) => {
                // Initialization > Is Pending
                let isPending = false;

                // Function > ... --- REDACT (Lapys)
                function _onpointerup(event) { if (false == isPending) {
                    isPending = true; Clock.tick(unpend);
                    cancelEvent(event); handler(ImmutableReference(new PointerEvent(event, Event)), target)
                } } function unpend() { isPending = false }

                // Event > Target > (Mouse Down, Pointer Down, Touch Start)
                target.addEventListener("mouseup", _onpointerup, {capture: true, once: false, passive: false}, true);
                target.addEventListener("pointerup", _onpointerup, {capture: true, once: false, passive: false}, true);
                target.addEventListener("touchend", _onpointerup, {capture: true, once: false, passive: false}, true)
            }, Events.PointerReleaseEvent);

            // On Ready
            Events.onready = new EventListener((handler, target, Event) => {
                // Logic
                if (target instanceof Document || target instanceof HTMLDocument) {
                    // Constant > Resource Load Event
                    const resourceLoadEvent = new Event(target.location.href);

                    // Function > Ready
                    // : ...
                    function ready() { resourceLoadEvent.loaded = true; handler(ImmutableReference(resourceLoadEvent), target) }
                    "complete" == target.readyState ? ready() : target.addEventListener("readystatechange", function _onready(event) { if ("complete" == target.readyState) { cancelEvent(event); ready() } })
                }

                else if (target instanceof Image) {
                    // Constant > Resource Load Event
                    const resourceLoadEvent = new Event(target.src);

                    // Event > Target > (Error, Load)
                    target.addEventListener("error", function _onready(event) { target.removeEventListener("error", _onready); resourceLoadEvent.loaded = false; cancelEvent(event); handler(ImmutableReference(resourceLoadEvent), target) }, {capture: true, once: true, passive: false}, true);
                    target.addEventListener("load", function _onready(event) { target.removeEventListener("load", _onready); resourceLoadEvent.loaded = true; cancelEvent(event); handler(ImmutableReference(resourceLoadEvent), target) }, {capture: true, once: true, passive: false}, true)
                }
            }, Events.ResourceLoadEvent);

            // On Resize
            Events.onresize = new EventListener((handler, target, Event) => {
                // Constant > Target Size
                const targetSize = {height: null, width: null};

                // Function > (..., Request Target Size) --- REDACT (Lapys)
                function resize() {
                    // Constant > Resize Event
                    const resizeEvent = new Event(targetSize.height, targetSize.width);

                    // ...; Modification > Resize Event > Current (Height, Width)
                    requestTargetSize();
                    resizeEvent.currentHeight = targetSize.height;
                    resizeEvent.currentWidth = targetSize.width;

                    // ...
                    handler(ImmutableReference(resizeEvent), target)
                }
                function requestTargetSize() {
                    if (target instanceof Window) { targetSize.height = target.innerHeight; targetSize.width = target.innerWidth }
                    else if (target instanceof Element || target instanceof HTMLElement) {
                        const boundingClientRectangle = target.getBoundingClientRect();

                        targetSize.height = boundingClientRectangle.height;
                        targetSize.width = boundingClientRectangle.width
                    }

                    else if (target instanceof Document || target instanceof HTMLDocument) {
                        const bodyElement = target.body;
                        const documentElement = target.documentElement;

                        targetSize.height = Math.max(bodyElement.offsetHeight, bodyElement.scrollHeight, documentElement.clientHeight, documentElement.offsetHeight, documentElement.scrollHeight);
                        targetSize.width = Math.max(bodyElement.offsetWidth, bodyElement.scrollWidth, documentElement.clientWidth, documentElement.offsetWidth, documentElement.scrollWidth)
                    }

                    return targetSize
                }

                // Logic
                if (target instanceof SVGElement || target instanceof Window) {
                    // Event > Target > Resize
                    target.addEventListener("resize", function _onresize(event) {
                        // ...
                        cancelEvent(event);
                        resize()
                    }, {capture: true, once: false, passive: false}, true)
                }

                else if ("undefined" == typeof(ResizeObserver)) {
                    // Constant > Recent Target Size
                    const recentTargetSize = {height: +0, width: +0};

                    // ...; Modification > Recent Target Size > (Height, Width)
                    requestTargetSize();
                    recentTargetSize.height = targetSize.height;
                    recentTargetSize.width = targetSize.width;

                    // ...
                    Clock.tick(function resized() {
                        // ...; Logic
                        requestTargetSize();
                        if ((targetSize.height != recentTargetSize.height) || (targetSize.width != recentTargetSize.width)) {
                            // Modification > Recent Target Size > (Height, Width)
                            recentTargetSize.height = targetSize.height;
                            recentTargetSize.width = targetSize.width;

                            // ...
                            resize()
                        }

                        // ...
                        Clock.tick(resized)
                    })
                }

                else {
                    // ...
                    new ResizeObserver(resize).observe(target)
                }
            }, Events.ResizeEvent)
        }

        /* Game */ {
            /* Components */ {
                // Renderable
                Game.Components.Renderable = function Renderable() { Entity.define(this, "graphics", new Graphics.GraphicList) };
                Game.Components.Renderable.prototype = {
                    draw(renderer, parameters, graphics) {
                        graphics.resolveParameters(parameters);
                        Graphics.Graphic.prototype.draw.call(this.graphic, renderer ?? graphics.renderer, resolvedParameters, graphics);
                    }
                };
            }
        }

        /* Graphics */ {
            // Colors
            Graphics.Colors = ImmutableObject({
                "BLACK": new Graphics.Color(+0, +0, +0, 1),
                "BLUE": new Graphics.Color(+0, +0, 255, 1),
                "CYAN": new Graphics.Color(+0, 255, 255, 1),
                "GRAY": new Graphics.Color(127, 127, 127, 1),
                "GREY": new Graphics.Color(127, 127, 127, 1),
                "GREEN": new Graphics.Color(+0, 255, +0, 1),
                "MAGENTA": new Graphics.Color(255, +0, 255, 1),
                "RED": new Graphics.Color(255, +0, +0, 1),
                "TRANSPARENT": new Graphics.Color(+0, +0, +0, +0),
                "WHITE": new Graphics.Color(255, 255, 255, 1),
                "YELLOW": new Graphics.Color(255, 255, +0, 1)
            });

            // Composite Operations
            Graphics.CompositeOperations = ImmutableReference(new class CompositeOperationEnumeration extends Enumeration {}(
                "COLOR", "COLOR_BURN", "COLOR_DODGE", "COPY",
                "DARKEN", "DESTINATION_ATOP", "DESTINATION_IN", "DESTINATION_OVER", "DESTINATION_OUT", "DIFFERENCE",
                "EXCLUSION",
                "HARD_LIGHT", "HUE",
                "LIGHTEN", "LIGHTER", "LUMINOSITY",
                "MULTIPLY", "OVERLAY",
                "SATURATION", "SCREEN", "SOFT_LIGHT", "SOURCE_ATOP", "SOURCE_IN", "SOURCE_OVER", "SOURCE_OUT",
                "XOR"
            ).of(class CompositeOperation extends Enumerable {}));

            // Filters
            Graphics.Filters = ImmutableReference({
                "BLUR": new Graphics.PresetFilter("blur"),
                "BRIGHTNESS": new Graphics.PresetFilter("brightness"),
                "CONTRAST": new Graphics.PresetFilter("contrast"),
                "DROP_SHADOW": new Graphics.PresetFilter("drop-shadow"),
                "GRAYSCALE": new Graphics.PresetFilter("grayscale"),
                "HUE_ROTATE": new Graphics.PresetFilter("hue-rotate"),
                "INVERT": new Graphics.PresetFilter("invert"),
                "OPACITY": new Graphics.PresetFilter("opacity"),
                "SATURATE": new Graphics.PresetFilter("saturate"),
                "SEPIA": new Graphics.PresetFilter("sepia"),
                "NONE": new Graphics.Filter,
                "URL": new Graphics.PresetFilter("url")
            });

            // Gradient Patterns
            Graphics.GradientPatterns = ImmutableReference(new class GradientPatternEnumeration extends Enumeration {}(
                "LINEAR", "RADIAL"
            ).of(Graphics.GradientPattern));

            // Line Caps
            Graphics.LineCaps = ImmutableReference(new class LineCapEnumeration extends Enumeration {}(
                "BUTT", "ROUND", "SQUARE"
            ).of(Graphics.LineCap));

            // Line Joins
            Graphics.LineJoins = ImmutableReference(new class LineJoinEnumeration extends Enumeration {}(
                "BEVEL", "MITER", "ROUND"
            ).of(Graphics.LineJoin));

            // Positions
            Graphics.Positions = ImmutableReference(new class DynamicCoordinatesEnumeration extends Enumeration {}(
                "BOTTOM", "CENTER", "LEFT", "RIGHT", "UP"
            ).of(Graphics.DynamicCoordinates))
        }
    }
}("undefined" == typeof(self) ? ("undefined" == typeof(window) ? ("undefined" == typeof(global) ? (function() { return this })() : global) : window) : self);
