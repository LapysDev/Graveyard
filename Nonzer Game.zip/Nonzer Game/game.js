/* Constant > (Graphics, Render, Scene) */
const render = document.createElement("canvas");
const graphics = new Graphics(render);
const scene = graphics.scene;

/* Global > ... */
const RENDERABLES = new List;

/* Class */
    // Entity --- NOTE (Lapys) -> All in-game base entities are render-able.
    class Entity extends Game.Entity {
        // [Constructor]
        constructor() { super(); this.addComponent(Game.Components.Renderable) }
    };

/* Function */
    // Adjust Scene Size
    function AdjustSceneSize() {
        // Modification > Canvas > (Height, Width)
        render.height = innerHeight;
        render.width = innerWidth
    }

/* Event */ {
    // Canvas > Resize
    Events.onresize.listen(render).invoke(AdjustSceneSize);
    Events.onresize.listen(window).invoke(AdjustSceneSize)
}

/* Phase */ Events.onready.listen(document).invoke(function() {
    /* Initiate */
    Game.INITIATE = function INITIATE() {
        // ...
        render.id = "render";
        document.body.appendChild(render)
    };

    /* Update --- NOTE (Lapys) -> Main game loop. */
    Game.UPDATE = function UPDATE(elapsed) {}
});
