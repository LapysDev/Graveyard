/* Import */
#include <ctype.h> // Character Type
#include <math.h> // Mathematics
#include <stdio.h> // Standard Input/ Output
#include <stdlib.h> // Standard Library
#include <string.h> // String
#include <windows.h> // Windows

/* Global */
    /* Window ... */
    constexpr unsigned short const WINDOW_HEIGHT = 500u;
    constexpr char const WINDOW_TITLE[] = "Snake | OLC CodeJam (2020)";
    constexpr unsigned short const WINDOW_WIDTH = 500u;

    HWND WINDOW_HANDLE = NULL;
    PAINTSTRUCT WINDOW_PAINT_INFORMATION = {};
    HDC WINDOW_RENDERER = NULL;

    LRESULT CALLBACK WINDOW_PROCEDURE(HWND, UINT, WPARAM, LPARAM);

/* Definition > ... */
namespace Events {}
namespace Game {}
namespace Graphics {}
namespace Utility {}

/* Namespace > ... */
    /* Events */
    namespace Events {
        // Definition > On (Click, Draw, Key)
        void OnClick(HWND, WPARAM) noexcept;
        void OnDraw(HWND, HDC) noexcept;
        void OnKey(HWND, WPARAM) noexcept;
    }

    /* Game */
    namespace Game {
        // Phase > (Initiate, Terminate, Update)
        void Initiate(void);
        void Terminate(char const* const = NULL);
        void Update(void);
    }

    /* Graphics */
    inline namespace Graphics {
        // Definition > ...
        class COllidable;
        class Drawable;

        class BoundingRectangle;
        class Color;
        class Composition;
        class Coordinates2D;
        class Coordinates3D;
        class Coordinates4D;
        template <unsigned short, class = signed long> class Vector;

        class Image;
        class Line;
        class Shape;
        class Text;

        class Circle;
        class Ellipse;
        class Square;
        class Rectangle;
    }

    /* Utility */
    inline namespace Utility {
        // Definition > ...
        template <bool, class, class> struct assert_t;
        template <class true_t, class false_t> struct assert_t<false, true_t, false_t>;
        constexpr unsigned char count_of(void) noexcept;
        template <class type, class... types> constexpr unsigned char count_of(type, types...) noexcept;
        struct false_t;
        template <class> struct is_primitive_t;
        template <> struct is_primitive_t<bool>;
        template <> struct is_primitive_t<char>;
        template <> struct is_primitive_t<double>;
        template <> struct is_primitive_t<float>;
        template <> struct is_primitive_t<int>;
        template <> struct is_primitive_t<long>;
        template <> struct is_primitive_t<long double>;
        template <> struct is_primitive_t<signed char>;
        template <> struct is_primitive_t<unsigned char>;
        template <> struct is_primitive_t<unsigned int>;
        template <> struct is_primitive_t<unsigned long>;
        template <> struct is_primitive_t<unsigned short>;
        template <> struct is_primitive_t<wchar_t>;
        template <> struct is_primitive_t<void>;
        template <> template <class type> struct is_primitive_t<type*>;
        struct true_t;
        template <class> struct type_t;

        // Definition > (File, Immutable Accessor, List, String)
        struct file;
        template <class, class, bool> struct immutable_accessor;
        namespace list_namespace { template <class, size_t = 0u> struct list; } using list_namespace::list;
        struct string;
    }

/* Modification */
    /* Utility > Class */
        // ...
        constexpr inline unsigned char Utility::count_of(void) noexcept { return 0u; }
        template <class type, class... types> constexpr inline unsigned char Utility::count_of(type, types... arguments) noexcept { return count_of(arguments...) + 1u; }

        struct Utility::false_t { constexpr inline operator bool(void) const noexcept { return false; } };
        struct Utility::true_t { constexpr inline operator bool(void) const noexcept { return true; } };
        template <class type_t> struct Utility::type_t { typedef type_t type; };

        template <bool, class true_t, class = type_t<true_t>*> struct Utility::assert_t : type_t<true_t> {};
        template <class true_t, class false_t = type_t<false_t>*> struct Utility::assert_t<false, true_t, false_t> : type_t<false_t> {};

        template <class> struct Utility::is_primitive_t : false_t {};
        template <> struct Utility::is_primitive_t<bool> : true_t {};
        template <> struct Utility::is_primitive_t<char> : true_t {};
        template <> struct Utility::is_primitive_t<double> : true_t {};
        template <> struct Utility::is_primitive_t<float> : true_t {};
        template <> struct Utility::is_primitive_t<int> : true_t {};
        template <> struct Utility::is_primitive_t<long> : true_t {};
        template <> struct Utility::is_primitive_t<long double> : true_t {};
        template <> struct Utility::is_primitive_t<signed char> : true_t {};
        template <> struct Utility::is_primitive_t<unsigned char> : true_t {};
        template <> struct Utility::is_primitive_t<unsigned int> : true_t {};
        template <> struct Utility::is_primitive_t<unsigned long> : true_t {};
        template <> struct Utility::is_primitive_t<unsigned short> : true_t {};
        template <> struct Utility::is_primitive_t<wchar_t> : true_t {};
        template <> struct Utility::is_primitive_t<void> : true_t {};
        template <> template <class type> struct Utility::is_primitive_t<type*> : true_t {};

        // Immutable Accessor --- NOTE (Lapys) -> Immutable to non-friends; Primitives are optimized to not perform heap allocation.
        template <class base, class type, bool primitive = is_primitive_t<type>()>
        struct Utility::immutable_accessor final { friend base; friend string;
            // [...]
            private:
                // Definition > Value
                typename assert_t<primitive, type, type*>::type value;

                // [Constructor]
                template <typename assert_t<true == primitive, int>::type = 0x0> constexpr inline immutable_accessor(immutable_accessor const& accessor) : value{accessor.value} {}

                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline immutable_accessor(immutable_accessor const& accessor) : value{new type(*accessor.value)} {}
                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline immutable_accessor(immutable_accessor&& accessor) : value{accessor.value} { accessor.value = NULL; }

                // [Operator] > [=]
                template <typename assert_t<true == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator =(immutable_accessor const& accessor) const noexcept { this -> value = accessor.value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator =(immutable_accessor const& accessor) const noexcept { *(this -> value) = *accessor.value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator =(immutable_accessor&& accessor) const noexcept { this -> value = accessor.value; accessor.value = NULL; return *this; }
                template <typename assert_t<true == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator =(subtype value) { this -> value = value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator =(subtype value) { *(this -> value) = value; return *this; }

                template <typename assert_t<true == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator +=(immutable_accessor const& accessor) const noexcept { this -> value += accessor.value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator +=(immutable_accessor const& accessor) const noexcept { *(this -> value) += *accessor.value; return *this; }
                template <typename assert_t<true == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator +=(subtype value) { this -> value += value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator +=(subtype value) { *(this -> value) += value; return *this; }

                template <typename assert_t<true == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator -=(immutable_accessor const& accessor) const noexcept { this -> value -= accessor.value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator -=(immutable_accessor const& accessor) const noexcept { *(this -> value) -= *accessor.value; return *this; }
                template <typename assert_t<true == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator -=(subtype value) { this -> value -= value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator -=(subtype value) { *(this -> value) -= value; return *this; }

                template <typename assert_t<true == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator *=(immutable_accessor const& accessor) const noexcept { this -> value *= accessor.value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator *=(immutable_accessor const& accessor) const noexcept { *(this -> value) *= *accessor.value; return *this; }
                template <typename assert_t<true == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator *=(subtype value) { this -> value *= value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator *=(subtype value) { *(this -> value) *= value; return *this; }

                template <typename assert_t<true == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator /=(immutable_accessor const& accessor) const noexcept { this -> value /= accessor.value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator /=(immutable_accessor const& accessor) const noexcept { *(this -> value) /= *accessor.value; return *this; }
                template <typename assert_t<true == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator /=(subtype value) { this -> value /= value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator /=(subtype value) { *(this -> value) /= value; return *this; }

                template <typename assert_t<true == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator %=(immutable_accessor const& accessor) const noexcept { this -> value %= accessor.value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator %=(immutable_accessor const& accessor) const noexcept { *(this -> value) %= *accessor.value; return *this; }
                template <typename assert_t<true == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator %=(subtype value) { this -> value %= value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator %=(subtype value) { *(this -> value) %= value; return *this; }

                template <typename assert_t<true == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator ^=(immutable_accessor const& accessor) const noexcept { this -> value ^= accessor.value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator ^=(immutable_accessor const& accessor) const noexcept { *(this -> value) ^= *accessor.value; return *this; }
                template <typename assert_t<true == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator ^=(subtype value) { this -> value ^= value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator ^=(subtype value) { *(this -> value) ^= value; return *this; }

                template <typename assert_t<true == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator &=(immutable_accessor const& accessor) const noexcept { this -> value &= accessor.value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator &=(immutable_accessor const& accessor) const noexcept { *(this -> value) &= *accessor.value; return *this; }
                template <typename assert_t<true == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator &=(subtype value) { this -> value &= value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator &=(subtype value) { *(this -> value) &= value; return *this; }

                template <typename assert_t<true == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator |=(immutable_accessor const& accessor) const noexcept { this -> value |= accessor.value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator |=(immutable_accessor const& accessor) const noexcept { *(this -> value) |= *accessor.value; return *this; }
                template <typename assert_t<true == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator |=(subtype value) { this -> value |= value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator |=(subtype value) { *(this -> value) |= value; return *this; }

                template <typename assert_t<true == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator <<=(immutable_accessor const& accessor) const noexcept { this -> value <<= accessor.value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator <<=(immutable_accessor const& accessor) const noexcept { *(this -> value) <<= *accessor.value; return *this; }
                template <typename assert_t<true == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator <<=(subtype value) { this -> value <<= value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator <<=(subtype value) { *(this -> value) <<= value; return *this; }

                template <typename assert_t<true == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator >>=(immutable_accessor const& accessor) const noexcept { this -> value >>= accessor.value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline immutable_accessor& operator >>=(immutable_accessor const& accessor) const noexcept { *(this -> value) >>= *accessor.value; return *this; }
                template <typename assert_t<true == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator >>=(subtype value) { this -> value >>= value; return *this; }
                template <typename assert_t<false == primitive, int>::type = 0x0, class subtype> constexpr inline immutable_accessor& operator >>=(subtype value) { *(this -> value) >>= value; return *this; }

            // [...]
            protected:
                // Function > Value Of
                template <typename assert_t<true == primitive, int>::type = 0x0> constexpr inline type& valueOf(void) const noexcept { return (type&) this -> value; }
                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline type& valueOf(void) const noexcept { return *(this -> value); }

                // Phase > Terminate
                template <typename assert_t<true == primitive, int>::type = 0x0> constexpr inline void terminate(void) const noexcept {}
                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline void terminate(void) const noexcept { delete this -> value; }

            // [...]
            public:
                // [Constructor]
                template <typename assert_t<true == primitive, int>::type = 0x0> constexpr inline immutable_accessor(type value) : value{value} {}
                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline immutable_accessor(type& value) : value{new type(value)} {}
                template <typename assert_t<false == primitive, int>::type = 0x0> constexpr inline immutable_accessor(type&& value) : value{new type((type&&) value)} {}

                template <class... types, typename assert_t<true == primitive, int>::type = 0x0> constexpr inline immutable_accessor(types... values) : value{values...} {}
                template <class... types, typename assert_t<false == primitive, int>::type = 0x0> constexpr inline immutable_accessor(types... values) : value{new type(values...)} {}

                // : [Destructor]
                // : [Operator] > [...]
                inline ~immutable_accessor(void) { terminate(); }
                constexpr inline operator type&(void) const noexcept { return immutable_accessor::valueOf(); }
        };

        // List
        namespace Utility { namespace list_namespace {
            template <bool, size_t, class> struct list__stack { public: constexpr inline list__stack(void) {} };
            template <size_t length, class type> struct list__stack<false, length, type> { public: constexpr inline operator type*(void) const noexcept { return NULL; } };
            template <size_t length, class type> struct list__stack<true, length, type> { type value[length] = {}; public: constexpr inline operator type*(void) const noexcept { return (type*) this -> value; } };

            template <class type, size_t stack_length>
            struct list { friend file; friend string;
                // [...]
                private:
                    // Definition > (Heap, Stack)
                    type *heap;
                    list__stack<0u != stack_length, stack_length, type> stack;

                // [...]
                protected:
                    // Function > (Allocate, Assert, At, Compare, Copy, First, Free, Get, Last, Move, Push, Search, Set)
                    inline void allocate(size_t const length, bool const SAFE = false) noexcept {
                        // Logic > Modification > Target > (Size, Heap)
                        if (length > stack_length && length > this -> size) {
                            this -> size = 0u == length || 1u == length ? 2u : ((((length - stack_length) * (size_t) ::ceil(1.61803398875f / (SAFE ? 1.61803398875f : 1.0f))) >> 1u) << 1u);
                            this -> heap = (type*) ::realloc(this -> heap, this -> size * sizeof(type));
                        }
                    }

                    inline bool assert(type* const index, type& value) const { return list::compare(index, value) || value == *index; }
                    constexpr inline type& at(size_t const index) const noexcept { return (type&) *list::get(index); }
                    inline bool compare(type* const index, type& value) const { return index == &value; }
                    inline void copy(type* const index, type& value) { *index = value; }
                    constexpr inline type* first(void) const noexcept { return stack_length ? this -> stack : this -> heap; }
                    inline void free(void) { ::free(this -> heap); this -> heap = NULL; this -> size = 0u; }
                    constexpr inline type* get(size_t const index) const noexcept { return (index < stack_length ? this -> stack + index : this -> heap + (index - stack_length)); }
                    constexpr inline type* last(void) const noexcept { return this -> length < stack_length ? this -> stack + (this -> length - 1u) : this -> heap + (this -> length - stack_length - 1u); }
                    inline void move(type* const index, type& value) { ::memcpy(index, &value, sizeof(type)); }

                    inline void push(type& value, void (list<type, stack_length>::* mutator)(type* const, type&)) noexcept {
                        // Logic > ...
                        if (this -> length < stack_length) (this ->* mutator)(this -> stack + this -> length++, value);
                        else { list::allocate(this -> length + 1u); (this ->* mutator)(this -> heap + (this -> length - stack_length), value); ++(this -> length); }
                    }

                    constexpr inline signed search(type& value, bool (list<type, stack_length>::* const comparator)(type* const, type&) const) const {
                        // Initialization > (End, Iterator)
                        type *end = NULL, *iterator = NULL;

                        // Loop > Logic > Return
                        // : [Stack]
                        for (
                            end = (type*) this -> stack + (this -> length > stack_length ? stack_length : (size_t) this -> length), iterator = (type*) this -> stack;
                            end != iterator; ++iterator
                        ) if ((this ->* comparator)(iterator, value)) return iterator - this -> stack;

                        // : [Heap]
                        if (this -> length > stack_length)
                        for (
                            end = (type*) this -> heap + (this -> length - stack_length), iterator = (type*) this -> heap;
                            end != iterator; ++iterator
                        ) if ((this ->* comparator)(iterator, value)) return iterator - this -> heap;

                        // Return
                        return -1;
                    }

                    constexpr inline void set(size_t const index, type& value, void (list<type, stack_length>::* mutator)(type* const, type&) = list::copy) noexcept { (this ->* mutator)(list::get(index), value); }
                    template <class subtype> constexpr inline void set(size_t const index, subtype value) const noexcept { *list::get(index) = value; }

                    // Phase > Initiate --- MINIFY (Lapys)
                    constexpr inline void initiate(void) const noexcept {}
                    inline void initiate(type* const list, size_t const length) noexcept { if (0u == length) list::free(); else { this -> length = length; list::allocate(length, true); if (length < stack_length) ::memcpy(this -> stack, list, length * sizeof(type)); else { ::memcpy(this -> heap, list + stack_length, (length - stack_length) * sizeof(type)); ::memcpy(this -> stack, list, stack_length * sizeof(type)); } } }
                    inline void initiate(Utility::list<type, stack_length> const& list) noexcept { list::allocate((this -> length = list.length), true); ::memcpy(this -> stack, list.stack, stack_length * sizeof(type)); (list.length >= stack_length) && ::memcpy(this -> heap, list.heap, (list.length - stack_length) * sizeof(type)); }
                    inline void initiate(Utility::list<type, stack_length>&& list) noexcept { this -> length = list.length; this -> heap = list.heap; this -> size = list.size; ::memcpy(this -> stack, list.stack, stack_length * sizeof(type)); list.heap = NULL; list.length = 0u; list.size = 0u; }
                    template <class subtype, size_t substack_length> inline void initiate(Utility::list<subtype, substack_length> const& list) noexcept { size_t const length = list.length; list::empty(0u); list::allocate(length, true); for (size_t iterator = 0u; iterator ^ length; ++iterator) list::add(list.at(iterator)); }
                    template <class subtype, class... subtypes> inline void initiate(subtype value, subtypes... values) noexcept { list::add(value); initiate(values...); }

                // [...]
                public:
                    // Definition > (Length, Size)
                    immutable_accessor<list, size_t> length;
                    immutable_accessor<list, size_t> size;

                    // [Constructor]
                    inline list(size_t const length) : heap{NULL}, stack{}, length{length}, size{0u} { list::allocate(length, true); }
                    inline list(type* const list, size_t const length) : heap{NULL}, stack{}, length{0u}, size{0u} { initiate(list, length); }
                    inline list(Utility::list<type, stack_length>&& list) : heap{NULL}, stack{}, length{0u}, size{0u} { initiate((Utility::list<type, stack_length>&&) list); }
                    template <class subtype, size_t substack_length> inline list(Utility::list<subtype, substack_length> const& list) : heap{NULL}, stack{}, length{0u}, size{0u} { initiate(list); }
                    template <class... subtypes> inline list(subtypes... values) : heap{NULL}, stack{}, length{0u}, size{0u} { list::allocate(count_of(values...), true); initiate(values...); }

                    // [Destructor]
                    inline ~list(void) { list::free(); }

                    // Function > (Add, Empty, Includes, Index, Pop, Remove, Resize, Splice) --- MINIFY (Lapys)
                    constexpr inline void add(type& value) noexcept { list::push(value, &list::move); }
                    constexpr inline void add(type&& value) noexcept { list::push(value, &list::copy); }
                    constexpr inline void empty(void) noexcept { this -> length = 0u; }
                    constexpr inline bool includes(type& value) const noexcept { return ~list::index(value); }
                    constexpr inline signed index(type& value, bool const SAFE = false) const noexcept { return list::search(value, SAFE ? &list::compare : &list::assert); }
                    constexpr inline signed index(type&& value) const noexcept { return list::search(value, &list::assert); }
                    constexpr inline bool pop(void) noexcept { return this -> length && --(this -> length); }
                    constexpr inline bool remove(type& value) noexcept { constexpr signed const index = list::index(value); return ~index && list::splice((size_t) index); }
                    constexpr inline void resize(size_t const length) noexcept { list::allocate((this -> length = length), true); }
                    constexpr inline bool splice(size_t const index) noexcept { if (index < this -> length) { ::memcpy(index < stack_length ? this -> stack + index : this -> heap + (index - stack_length), list::last(), sizeof(type)); --(this -> length); return true; } return false; }

                    // [Operator] > ([=], [[]], [...])
                    inline list<type, stack_length>& operator =(Utility::list<type, stack_length>&& list) noexcept { Utility::list<type, stack_length>::empty(); Utility::list<type, stack_length>::free(); initiate((Utility::list<type, stack_length>&&) list); return *this; }
                    template <class subtype, size_t substack_length> inline list<type, stack_length>& operator =(Utility::list<subtype, substack_length> const& list) noexcept { Utility::list<subtype, substack_length>::empty(); Utility::list<subtype, substack_length>::free(); initiate(list); return *this; }
                    constexpr inline type& operator [](int const index) const { return index < 0 || 0u == this -> length ? Game::Terminate("[Error]: Indexed `list` out of range"), *(type*) NULL : list::at((size_t) index); }
                    constexpr inline operator type*(void) const noexcept = delete;
            };
        } }

        // String
        namespace Utility {
            constexpr unsigned char const string__stack_length = ((32u * sizeof(char)) >> 1u) << 1u;
            struct string final : public list<char, string__stack_length> { friend file;
                /* Class > String Iterator */
                struct string_iterator {
                    // [...]
                    private:
                        // Definition > (Type, String)
                        enum {collective, null, primitive, utility} const type;
                        void const *const string;

                    // [...]
                    public:
                        // [Constructor]
                        constexpr inline string_iterator(char const string) : type{primitive}, string{(void const*) (int) string} {}
                        constexpr inline string_iterator(char* const string) : type{collective}, string{string} {}
                        constexpr inline string_iterator(char const* const string) : type{collective}, string{string} {}
                        constexpr inline string_iterator(int const) : type{null}, string{NULL} {}
                        constexpr inline string_iterator(Utility::string const& string) : type{utility}, string{&string} {}

                        // Function > (Character, Length, Stack) Of
                        constexpr inline char charof(size_t const index) const noexcept { switch (this -> type) { case collective: return *(((char const*) this -> string) + index); case null: return 0u == index ? '\0' : *(char*) NULL; case primitive: return 0u == index ? (char) (int) this -> string : *(char*) NULL; case utility: return ((Utility::string const*) this -> string) -> at(index); } return '\0'; }
                        constexpr inline size_t lengthof(void) const noexcept { switch (this -> type) { case collective: return ::strlen((char const*) this -> string); case null: return 0u; case primitive: return '\0' == (char) (int) this -> string ? 0u : 1u; case utility: return ((Utility::string const*) this -> string) -> length; } return 0u; }
                        constexpr inline char const* stackof(void) const noexcept { switch (this -> type) { case collective: return (char const*) this -> string; case null: return ""; case primitive: return (char const*) &(this -> string); case utility: return ((Utility::string const*) this -> string) -> stack; } return NULL; }
                };

                // [...]
                protected:
                    // Phase > Initiate
                    inline void initiate(char* const value) noexcept { list::initiate(value, ::strlen(value)); }
                    inline void initiate(char const* const value) noexcept { list::initiate((char*) value); }
                    inline void initiate(int const) noexcept { list::empty(); list::free(); }
                    void initiate(file const&) noexcept;

                // [...]
                public:
                    // [Constructor]
                    inline string(char* const value) : list() { initiate(value); }
                    inline string(char const* const value) : list() { initiate(value); }
                    inline string(int const = 0x0) : list() {}
                    inline string(file const& file) : list() { initiate(file); }

                    // Function > (Begins With, Concatenate, Includes, Index, Remove, Replace, (Slice, Trim) (Begin, End), To (Lower, Upper), ...) --- MINIFY (Lapys)
                    inline bool beginsWith(string_iterator const& string) const noexcept { size_t const length = string.lengthof(); if (this -> length >= length) { for (size_t iterator = 0u; iterator ^ length; ++iterator) if (string::at(iterator) != string.charof(iterator)) return false; else if (iterator == length - 1u) return true; } return false; }
                    inline void concatenate(string_iterator const& string) noexcept { size_t const length = string.lengthof(); string::allocate(length + this -> length, true); for (size_t iterator = 0u; iterator ^ length; ++iterator) string::add(string.charof(iterator)); }
                    inline bool endsWith(string_iterator const& string) const noexcept { size_t const length = string.lengthof(); if (this -> length >= length) { for (size_t iterator = length; iterator--; ) if (string::at((this -> length - length) + iterator) != string.charof(iterator)) return false; else if (0u == iterator) return true; } return false; }
                    inline bool includes(string_iterator const& string) { return ~string::index(string); }
                    inline signed index(string_iterator const& string) const noexcept { if (this -> length) { size_t const length = string.lengthof(); if (length) for (size_t iterator = 0u; iterator ^ this -> length; ++iterator) { if (iterator + length > this -> length) break; else if (string::at(iterator) == string.charof(0u)) { for (size_t subiterator = iterator; subiterator != iterator + length; ++subiterator) { if (string::at(subiterator) != string.charof(subiterator - iterator)) break; else if (length - 1u == subiterator - iterator) return iterator; } } } } return -1; }
                    inline void remove(string_iterator const& substring) noexcept { string::replace(substring, 0x0 /* -> NULL */); }
                    inline void replace(string_iterator const& substring, string_iterator const& substitute) noexcept { signed const index = string::index(substring); if (~index) { size_t iterator; size_t const substringLength = substring.lengthof(); size_t const substituteLength = substitute.lengthof(); if (substituteLength < substringLength) { iterator = (size_t) index; this -> length -= substringLength - substituteLength; if (substituteLength) { for (; iterator != index + substituteLength; ++iterator) string::set(iterator, substitute.charof(iterator - index)); } for (; iterator ^ this -> length; ++iterator) { string::set(iterator, string::at(iterator + (substringLength - substituteLength))); } string::allocate(this -> length, true); } else { this -> length += substituteLength - substringLength; iterator = this -> length; string::allocate(this -> length, true); while (iterator-- != index + substituteLength) { string::set(iterator, string::at(iterator - (substituteLength - substringLength))); } iterator -= substituteLength; while (++iterator != index + substituteLength) string::set(iterator, substitute.charof(iterator - index)); } } }
                    inline void slice(size_t const length) noexcept { string::sliceEnd(length); string::sliceBegin(length); }
                    inline void slice(size_t const beginLength, size_t const endLength) noexcept { string::sliceEnd(endLength); string::sliceBegin(beginLength); }
                    inline void sliceBegin(size_t const length) noexcept { if (this -> length > length) { for (size_t iterator = 0u; this -> length != iterator + length; ++iterator) { string::set(iterator, string::at(iterator + length)); } string::resize(this -> length - length); } else string::resize(0u); }
                    inline void sliceEnd(size_t const length) noexcept { string::resize(this -> length > length ? this -> length - length : 0u); }
                    inline void toLower(void) noexcept { for (size_t iterator = this -> length; iterator--; ) string::set(iterator, ::tolower(string::at(iterator))); }
                    inline void toUpper(void) noexcept { for (size_t iterator = this -> length; iterator--; ) string::set(iterator, ::toupper(string::at(iterator))); }
                    inline void trim(void) noexcept { string::trimEnd(); string::trimBegin(); }
                    inline void trim(string_iterator const& string) noexcept { string::trimEnd(string); string::trimBegin(string); }
                    inline void trim(string_iterator const& beginString, string_iterator const& endString) noexcept { string::trimEnd(endString); string::trimBegin(beginString); }
                    inline void trimBegin(void) noexcept { while (string::beginsWith(' ') || string::beginsWith('\n') || string::beginsWith('\r') || string::beginsWith('\t')) { string::trimBegin(' '); string::trimBegin('\n'); string::trimBegin('\r'); string::trimBegin('\t'); } }
                    inline void trimBegin(string_iterator const& string) noexcept { while (string::beginsWith(string)) string::sliceBegin(string.lengthof()); }
                    inline void trimEnd(void) noexcept { while (string::endsWith(' ') || string::endsWith('\n') || string::endsWith('\r') || string::endsWith('\t')) { string::trimEnd(' '); string::trimEnd('\n'); string::trimEnd('\r'); string::trimEnd('\t'); } }
                    inline void trimEnd(string_iterator const& string) noexcept { while (string::endsWith(string)) string::sliceEnd(string.lengthof()); }

                    inline char* load(void) const noexcept {
                        // Logic
                        if (this -> length) {
                            // Initialization > (Evaluation, Length)
                            char *const evaluation = (char*) ::calloc(this -> length + 1u, sizeof(char));

                            // Logic > Update > Evaluation
                            if (this -> length < string__stack_length) ::strncpy(evaluation, this -> stack, this -> length);
                            else {
                                ::strncpy(evaluation, this -> stack, string__stack_length);
                                ::strncpy(evaluation + string__stack_length, this -> heap, this -> length - string__stack_length);
                            }

                            // Return
                            return evaluation;
                        }

                        // Return
                        return NULL;
                    }

                    // [Operator] > ([+], [-], [*], [+=], [-=], [*=], [=], [...])
                    inline string operator +(string_iterator const& string) const noexcept { Utility::string concatenation = {}; concatenation.list::initiate((list<char, string__stack_length> const&) *this); concatenation.operator+=(string); return concatenation; }
                    inline string& operator +=(string_iterator const& string) noexcept { string::concatenate(string); return *this; }

                    inline string operator -(string_iterator const& string) const noexcept { Utility::string reduction = {}; reduction.list::initiate((list<char, string__stack_length> const&) *this); reduction.operator-=(string); return reduction; }
                    friend inline string operator -(string const& string, size_t const length) noexcept { Utility::string trim = {}; trim.list::initiate((list<char, string__stack_length> const&) string); trim.sliceEnd(length); return trim; }
                    friend inline string operator -(size_t const length, string const& string) noexcept { Utility::string trim = {}; trim.list::initiate((list<char, string__stack_length> const&) string); trim.sliceBegin(length); return trim; }
                    inline string& operator -=(size_t const length) noexcept { string::sliceEnd(length); return *this; }
                    inline string& operator -=(string_iterator const& string) noexcept { if (string::endsWith(string)) { string::resize(this -> length - string.lengthof()); } return *this; }

                    friend inline string operator *(string const& string, size_t const count) noexcept { Utility::string multiplication = {}; multiplication.list::initiate((list<char, string__stack_length> const&) string); multiplication.operator*=(count); return multiplication; }
                    friend inline string operator *(size_t const count, string const& string) noexcept { return operator *(string, count); }
                    inline string& operator *=(size_t count) noexcept { if (count > 1u) { string copy = {}; string::allocate(count * this -> length, true); copy.heap = this -> heap; copy.length = this -> length; ::strncpy(copy.stack, this -> stack, string__stack_length); while (--count) { string::concatenate(copy); } copy.heap = NULL; } return *this; }

                    inline string& operator =(char* const value) noexcept { list::empty(); list::free(); initiate(value); return *this; }
                    inline string& operator =(char const* const value) noexcept { list::empty(); list::free(); initiate((char*) value); return *this; }
                    inline string& operator =(int const) noexcept { list::empty(); list::free(); initiate(0x0); return *this; }
                    inline string& operator =(file const& file) noexcept { list::empty(); list::free(); initiate(file); return *this; }

                    inline operator char*(void) const noexcept { return string::load(); }
            };
        }

        /* File
                --- NOTE (Lapys) -> Always open in binary mode.
                --- WARN (Lapys) -> Incompatible with `Utility::string` :'(
        */
        struct Utility::file {
            // [...]
            private:
                // Definition > (Mode, Stream)
                struct mode_t {
                    private: unsigned char value;
                    public: static mode_t const append, read, update, write;
                        constexpr inline mode_t(void) : value{0x0} {}
                        constexpr inline mode_t(unsigned char const value) : value{value} {}

                        constexpr inline operator unsigned char&(void) const noexcept { return (unsigned char&) this -> value; }
                } mode;
                FILE *stream;

            // [...]
            protected:
                // Function > (Close, Open, Translate)
                inline void close(void) noexcept { ::fclose(this -> stream); }
                inline void open(char const* const path, file::mode_t const mode) noexcept { this -> stream = ::fopen(path, file::translate(mode)); }
                constexpr inline static char const* translate(file::mode_t const mode) noexcept {
                    // ... Return
                    if (mode & mode_t::append) return mode & mode_t::update ? "ab+" : "ab";
                    else if (mode & mode_t::read) return mode & mode_t::update ? "rb+" : "rb";
                    else if (mode & mode_t::write) return mode & mode_t::update ? "wb+" : "wb";

                    return NULL;
                }

            // [...]
            public:
                // Definition > (Path, Position)
                immutable_accessor<file, char const*> path;
                struct seek_accessor {
                    private: FILE *&stream;
                    public:
                        constexpr inline seek_accessor(void) : stream{this -> stream} {}
                        constexpr inline seek_accessor(FILE*& stream) : stream{stream} {}

                        inline operator long(void) const noexcept { return ::ftell(this -> stream); }
                } const position;

                // [Constructor]
                inline file(void) : mode{0x0}, stream{::tmpfile()}, path{(char*) NULL}, position{this -> stream} {}
                inline file(file::mode_t const mode) : mode{mode}, stream{NULL}, path{(char*) NULL}, position{this -> stream} { file::open((char const*) ::tmpnam(NULL), mode); }
                inline file(char* const path, file::mode_t const mode = mode_t::read | mode_t::update) : mode{mode}, stream{NULL}, path{(char const*) path}, position{this -> stream} { file::open(path, mode); }
                inline file(char const* const path, file::mode_t const mode = mode_t::read | mode_t::update) : mode{mode}, stream{NULL}, path{path}, position{this -> stream} { file::open(path, mode); }

                // [Destructor]
                inline ~file(void) { file::close(); }

                // Function > ...
                inline void empty(void) noexcept {
                    // Terminate
                    file::close();

                    // Logic > ...
                    if (0x0 == this -> mode) this -> stream = ::tmpfile();
                    else if (NULL == this -> path) {
                        file::open((char const*) ::tmpnam(NULL), this -> mode | mode_t::write);
                        file::close();
                        file::open((char const*) ::tmpnam(NULL), this -> mode);
                    } else {
                        file::open((char const*) this -> path, this -> mode | mode_t::write);
                        file::close();
                        file::open((char const*) this -> path, this -> mode);
                    }
                }

                inline char* read(void) const noexcept { return file::readInto((char*) ::calloc((file::size() - this -> position) + 1u, sizeof(char))); }
                inline char* read(size_t const length) const noexcept { return file::readInto((char*) ::calloc(length + 1u, sizeof(char)), length); }
                inline char* readInto(char* const buffer) const noexcept { return file::readInto(buffer, file::size() - this -> position); }
                inline char* readInto(char* const buffer, size_t const length) const noexcept { ::fread(buffer, sizeof(char), length, this -> stream); return buffer; }
                inline char* readIntoLine(char* const buffer) const noexcept { return file::readIntoUntil(buffer, '\n'); }
                inline char* readIntoUntil(char* const buffer, char const match) const noexcept { char *iterator = buffer; for (int character; character = ::fgetc(this -> stream), EOF != character && match != character; ++iterator) *iterator = character; return buffer; }
                inline char* readIntoUntil(char* const buffer, char* const match) const noexcept { return file::readIntoUntil(buffer, (char const*) match); }
                inline char* readIntoUntil(char* const buffer, char const* const match) const noexcept {
                    // Initialization > (End, Length)
                    char *end = buffer;
                    size_t const length = ::strlen(match);

                    // Loop
                    for (int character; character = ::fgetc(this -> stream), EOF != character; ) {
                        // Initialization > Iterator
                        // : Update > End; Loop
                        char *iterator = end + 1;

                        *end++ = character;
                        for (char const *subiterator = match + (length - 1u); buffer != iterator--; --subiterator) {
                            // Logic > ...
                            if (*iterator != *subiterator) break;
                            else if (match == subiterator) { *(end -= length) = '\0'; return buffer; }
                        }
                    }

                    // Return
                    return buffer;
                }
                inline char* readLine(void) const noexcept { return file::readUntil('\n'); }
                inline int readNext(void) const noexcept { return ::fgetc(this -> stream); }
                inline char* readUntil(char const match) const noexcept { string buffer; for (int character; character = ::fgetc(this -> stream), EOF != character && match != character; ) buffer.add(character); return buffer.load(); }
                inline char* readUntil(char* const match) const noexcept { return file::readUntil((char const*) match); }
                inline char* readUntil(char const* const match) const noexcept {
                    // Initialization > (Buffer, Length)
                    string buffer;
                    size_t const length = ::strlen(match);

                    // Loop
                    for (int character; character = ::fgetc(this -> stream), EOF != character; ) {
                        // Initialization > Iterator
                        // : Loop
                        size_t iterator = buffer.length;
                        for (char const *subiterator = match + (length - 1u); iterator--; --subiterator) {
                            // Logic > ...
                            if (buffer.at(iterator) != *subiterator) break;
                            else if (match == subiterator) { buffer.resize(buffer.length - length); return buffer.load(); }
                        }

                        // Continue
                        buffer.add(character);
                    }

                    // Return
                    return buffer.load();
                }

                inline void seekBegin(void) const noexcept { ::fseek(this -> stream, 0L, SEEK_SET); }
                inline void seekBy(size_t const length) const noexcept { ::fseek(this -> stream, length, SEEK_CUR); }
                inline void seekTo(size_t const position) const noexcept { ::fseek(this -> stream, position, SEEK_SET); }
                inline void seekEnd(void) const noexcept { ::fseek(this -> stream, 0L, SEEK_END); }

                inline long size(void) const noexcept {
                    // Constant > (Current, Size)
                    long const current = this -> position;
                    long const size = (file::seekEnd(), this -> position);

                    // Return
                    return file::seekTo(current), size;
                }

                inline bool remove(void) noexcept { return 0 == ::remove(this -> path); }
                inline bool rename(char* const name) noexcept { return file::rename((char const*) name); }
                inline bool rename(char const* const name) noexcept { return 0 == ::rename(this -> path, name); this -> path = name; }

                inline void write(char* const content) noexcept { file::write((char const*) content); }
                inline void write(char const* const content) noexcept { ::fwrite(content, sizeof(char), ::strlen(content), this -> stream); }
                inline void write(void* const content, size_t const length) noexcept { ::fwrite(content, sizeof(unsigned char), length, this -> stream); }
                inline void write(file const& file) noexcept {
                    // Logic
                    if (NULL == file.stream) file::empty();
                    else {
                        // Constant > (Current, Length, Content)
                        long const current = ::ftell(file.stream);
                        long const length = file.size();
                        void *const content = ::calloc(length + 1u, sizeof(char));

                        // ...
                        file.seekBegin();
                        ::fread(content, sizeof(char), length, file.stream);
                        ::fwrite(content, sizeof(char), length, this -> stream);
                        file.seekTo(current);
                    }
                }
        };

        // ...
        inline void string::initiate(file const& file) noexcept { long const position = file.position; list::allocate((this -> length = file.size()), true); file.seekBegin(); file.readInto(this -> stack, string__stack_length); file.readInto(this -> heap); file.seekTo(position); }

        Utility::file::mode_t const Utility::file::mode_t::append = 0x1;
        Utility::file::mode_t const Utility::file::mode_t::read = 0x2;
        Utility::file::mode_t const Utility::file::mode_t::update = 0x4;
        Utility::file::mode_t const Utility::file::mode_t::write = 0x8;

    /* Events > Function */
        // Click
        void Events::OnPointerClick(WPARAM const button, POINT const& point) noexcept {
            button & MK_CONTROL
            button & MK_LBUTTON
            button & MK_MBUTTON
            button & MK_RBUTTON
            button & MK_SHIFT
            button & MK_XBUTTON1
            button & MK_XBUTTON2
        }

        void Events::OnPointerDrag(WPARAM const button, POINT const& initialPoint, POINT const& recentPoint) noexcept;
        void Events::OnPointerPush(WPARAM const button, POINT const& point) {}
        void Events::OnPointerRelease(WPARAM const button, POINT const& point) {}

        // Draw
        void Events::OnDraw(HWND, HDC) noexcept;

        // Key
        void Events::OnKey(WPARAM const key) noexcept;

    /* Graphics */
        /* Class */
            // Vector
            template <unsigned short count, class type>
            class Graphics::Vector { typedef type vector_t;
                // [...] ...
                private: type elements[count];
                public:
                    template <class... types> constexpr inline Vector(types... elements) : elements{elements...} {}
                    template <unsigned short subcount, class subtype> constexpr inline Vector(Vector<subcount, subtype> const& vector) : elements{vector.elements...} {}
            };

            // Collidable
            class Graphics::Collidable { public:
                inline virtual bool contains(Collidable const&) const noexcept = delete;
                inline virtual bool intersects(Collidable const&) const noexcept = delete;
                inline virtual bool within(Collidable const&) const noexcept = delete;
            };

            // Bounding Rectangle
            class Graphics::BoundingRectangle final : public Collidable, Vector<4u, unsigned short> { public:
                // Definition > (Bottom, Left, Right, Top)
                // [Constructor]
                Vector<4u, unsigned short>::vector_t &left, &top, &right, &bottom;
                constexpr inline BoundingRectangle(unsigned short const left = 0u, unsigned short const top = 0u, unsigned short const right = 0u, unsigned short const bottom = 0u) : Vector<4u, unsigned short>(left, top, right, bottom), left{*(this -> elements)}, top{*(this -> elements + 1)}, right{*(this -> elements + 2)}, bottom{*(this -> elements + 3)} {}
                constexpr inline BoundingRectangle(POINT const& point) : Vector<4u, unsigned short>(point.x, point.y, point.x, point.y), left{*(this -> elements)}, top{*(this -> elements + 1)}, right{*(this -> elements + 2)}, bottom{*(this -> elements + 3)} {}
                constexpr inline BoundingRectangle(RECT const& rectangle) : Vector<4u, unsigned short>(rectangle.left, rectangle.top, rectangle.right, rectangle.bottom), left{*(this -> elements)}, top{*(this -> elements + 1)}, right{*(this -> elements + 2)}, bottom{*(this -> elements + 3)} {}

                // Function > (Contains, Intersects, (Pad, Resize, Shrink) ..., Within)
                constexpr inline bool contains(BoundingRectangle const& rectangle) const noexcept override { return this -> bottom > rectangle.bottom && this -> left < rectangle.left && this -> right > rectangle.right && this -> top < rectangle.top; }
                constexpr inline bool intersects(BoundingRectangle const& rectangle) const noexcept override { return this -> bottom < rectangle.top && this -> left < rectangle.right && this -> right > rectangle.left && this -> top > rectangle.bottom; }

                constexpr inline void pad(unsigned short const length) noexcept { BoundingRectangle::pad(length, length); }
                constexpr inline void pad(unsigned short const height, unsigned short const width) noexcept { BoundingRectangle::padHeight(height); BoundingRectangle::padHeight(width); }
                constexpr inline void padHeight(unsigned short const length) noexcept { this -> bottom += length - (length / 2u); this -> top -= length / 2u; }
                constexpr inline void padWidth(unsigned short const length) noexcept { this -> left -= length / 2u; this -> right += length - (length / 2u); }

                constexpr inline void resize(float const proportion) noexcept { BoundingRectangle::resize(proportion, proportion); }
                constexpr inline void resize(float const height, float const width) noexcept {}
                constexpr inline void resizeHeight(float const proportion) noexcept { if (1.0f != proportion) { float size = this -> bottom - this -> top; size = ((proportion * size) - size) / 2.0f; this -> bottom += ::ceilf(size); this -> top -= ::floorf(size); } }
                constexpr inline void resizeWidth(float const proportion) noexcept { if (1.0f != proportion) { float size = this -> right - this -> left; size = ((proportion * size) - size) / 2.0f; this -> left -= ::floorf(size); this -> right += ::ceilf(size); } }

                constexpr inline void shrink(unsigned short const length) noexcept { BoundingRectangle::shrink(length, length); }
                constexpr inline void shrink(unsigned short const height, unsigned short const width) noexcept { BoundingRectangle::shrinkHeight(height); BoundingRectangle::shrinkWidth(width); }
                constexpr inline void shrinkHeight(unsigned short const length) noexcept { unsigned short const bottom = this -> bottom, top = this -> top; this -> bottom -= length - (length / 2u); this -> top += length / 2u; (this -> bottom < this -> top) && (this -> bottom = this -> top = (bottom + top) / 2u); }
                constexpr inline void shrinkWidth(unsigned short const length) noexcept { unsigned short const left = this -> left, right = this -> right; this -> left += length / 2u; this -> right -= length - (length / 2u); (this -> left > this -> right) && (this -> left = this -> right = (left + right) / 2u); }

                constexpr inline bool within(BoundingRectangle const& rectangle) const noexcept override { return rectangle.bottom > this -> bottom && rectangle.left < this -> left && rectangle.right > this -> right && rectangle.top < this -> top; }
            };

            // Color --- WARN (Lapys) -> RGBA color scheme only.
            class Graphics::Color final {
                // [...] ...
                private: unsigned int value;
                public:
                    // [Constructor]
                    constexpr inline Color(unsigned int const value = 0x0000000) : value{value} {}
                    constexpr inline Color(unsigned char const red, unsigned char const green, unsigned char const blue, bool const alpha = 1u) : value{((unsigned int) blue) + (-~0x0000FF * (unsigned int) green) + (-~0x00FFFF * (unsigned int) red) + (((unsigned int) alpha) << 0x18)} {}

                    // Function > (Get, Set) (Alpha, Blue, Green, Red), To (RGB, RGBA)
                    constexpr inline unsigned char getAlpha(void) const noexcept { return this -> value >> 24u; }
                    constexpr inline unsigned char getBlue(void) const noexcept { return this -> value & 0xFF; }
                    constexpr inline unsigned char getGreen(void) const noexcept { return (this -> value >> 8u) & 0xFF; }
                    constexpr inline unsigned char getRed(void) const noexcept { return (this -> value >> 16u) & 0xFF; }

                    constexpr inline void setAlpha(bool const range) noexcept { this -> value &= 0x0FFFFFF; this -> value |= range ? 0x1000000 : 0x0000000; }
                    constexpr inline void setBlue(unsigned char const range) noexcept { this -> value = range + (this -> value & 0x1FFFF00); }
                    constexpr inline void setGreen(unsigned char const range) noexcept { this -> value = (-~0x0000FF * range) + (this -> value & 0x1FF00FF); }
                    constexpr inline void setRed(unsigned char const range) noexcept { this -> value = (-~0x00FFFF * range) + (this -> value & 0x100FFFF); }

                    constexpr inline unsigned int toRGB(void) const noexcept { return this -> value & 0x0FFFFFF; }
                    constexpr inline unsigned int toRGBA(void) const noexcept { return this -> value; }

                    // [Operator] > ...
                    constexpr inline operator unsigned int(void) const noexcept { return Color::toRGBA(); }
            };

            // Coordinates ... --- MINIFY (Lapys) --- NOTE (Lapys) -> 3D and 4D are for laughs XD
            class Graphics::Coordinates2D final : public Vector<2u, long> { public: Vector<2u>::vector_t &x, &y; constexpr inline Coordinates2D(long const x = 0L, long const y = 0L) : Vector<2u, long>(x, y), x{*(this -> elements)}, y{*(this -> elements + 1)} {} };
            class Graphics::Coordinates3D final : public Vector<3u, long> { public: Vector<3u>::vector_t &x, &y, &z; constexpr inline Coordinates3D(long const x = 0L, long const y = 0L, long const z = 0L) : Vector<3u, long>(x, y, z), x{*(this -> elements)}, y{*(this -> elements + 1)}, z{*(this -> elements + 2)} {} };
            class Graphics::Coordinates4D final : public Vector<4u, long> { public: Vector<4u>::vector_t &x, &y, &z, &w; constexpr inline Coordinates4D(long const x = 0L, long const y = 0L, long const z = 0L, long const w = 0L) : Vector<4u, long>(x, y, z, w), x{*(this -> elements)}, y{*(this -> elements + 1)}, z{*(this -> elements + 2)}, w{*(this -> elements + 3)} {} };

            // Drawable
            class Graphics::Drawable { public: inline virtual void draw(HDC const, Coordinates2D const&) const noexcept {} };

            // Image --- NOTE (Lapys) -> Assets, sprites, and the like...
            class Graphics::Image {
                private:
                public:
                    constexpr inline Image(void) {}
                    // /* Now, for images (which must all be `.bmp` bitmaps) >_< */ {
                    // BITMAP bitmap = {};
                    // HBITMAP bitmapHandle;
                    // HGDIOBJ bitmapDummy;
                    // HDC bitmapRenderer;

                    // bitmapHandle = (HBITMAP) ::LoadImage(::GetModuleHandle(NULL), "image.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_LOADFROMFILE);
                    // ::GetObject(bitmapHandle, sizeof(BITMAP), &bitmap);
                    // bitmapRenderer = ::CreateCompatibleDC(renderer);
                    // bitmapDummy = ::SelectObject(bitmapRenderer, bitmapHandle);

                    // { ::BitBlt(renderer, 100, 0, bitmap.bmWidth, bitmap.bmHeight, bitmapRenderer, 0, 0, SRCCOPY); }

                    // ::SelectObject(bitmapRenderer, bitmapDummy);
                    // ::DeleteObject(bitmapDummy);
                    // ::DeleteDC(bitmapRenderer);
                    // ::DeleteObject(bitmapHandle);
            };

            class Graphics::Line {};
            class Graphics::Shape {};
            class Graphics::Text {};

            class Graphics::Circle {};
            class Graphics::Ellipse {};
            class Graphics::Square {};
            class Graphics::Rectangle {};

            // Point
            inline namespace Graphics { typedef Graphics::Coordinates2D Point; }

    /* Window Procedure */
    LRESULT CALLBACK WINDOW_PROCEDURE(HWND const windowHandle, UINT message, WPARAM parameter, LPARAM subparameter) {
        // Initialization > Points
        static struct { POINT push = {}, release = {}; } points = {};

        // ...; Logic --- REDACT (Lapys)
        Game::Update();
        switch (message) {
            case WM_CLOSE: case WM_DESTROY: goto Terminate; break;
            case WM_QUIT: ::DestroyWindow(windowHandle); break;
            case WM_SYSCOMMAND: if (parameter == SC_CLOSE) goto Terminate; break;
            case WM_SYSKEYDOWN: if (parameter == VK_F4) goto Terminate; break;

            case WM_LBUTTONDOWN: {
                points.push.x = ::GET_X_LPARAM(subparameter);
                points.push.y = ::GET_Y_LPARAM(subparameter);

                Events::OnPointerPush(parameter, points.push);
            } break;
            case WM_MOUSEMOVE: break;
            case WM_LBUTTONUP: {
                points.release.x = ::GET_X_LPARAM(subparameter);
                points.release.y = ::GET_Y_LPARAM(subparameter);

                Events::OnPointerRelease(parameter, points.release);
                Events::OnPointerClick(
                    parameter, points.release
                );
            } break;
            case WM_KEYDOWN: Events::OnKey(parameter); break;
            case WM_PAINT: {
                WINDOW_RENDERER = ::BeginPaint(windowHandle, &WINDOW_PAINT_INFORMATION);
                Events::OnDraw();

                ::ReleaseDC(windowHandle, WINDOW_RENDERER);
                ::EndPaint(windowHandle, &WINDOW_PAINT_INFORMATION);
            } break;
        }

        // [Evaluate, Terminate]
        Evaluate: return ::DefWindowProc(windowHandle, message, parameter, additionalParameter);
        Terminate: Game::Terminate(); ::PostQuitMessage(0x0); goto Evaluate;
    }

/* Phase */
    /* Initiate */
    void Game::Initiate(void) {}

    /* Terminate */
    void Game::Terminate(char const* const) {}

    /* Update */
    void Game::Update(void) {}

/* Main */
int main(void) { Game::Initiate();
}
