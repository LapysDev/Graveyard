// /* Works, this would be for tiles... */ {
    //     HANDLE const brush = ::CreateSolidBrush(RGB(0, 127, 255));
    //     RECT const rectangle = {0, 0, 100, 100};

    //     { ::FillRect(renderer, &rectangle, (HBRUSH) brush); }
    //     ::DeleteObject(brush);
    // }

    // /* Now, for images (which must all be `.bmp` bitmaps) >_< */ {
    //     BITMAP bitmap = {};
    //     HBITMAP bitmapHandle;
    //     HGDIOBJ bitmapDummy;
    //     HDC bitmapRenderer;

    //     bitmapHandle = (HBITMAP) ::LoadImage(::GetModuleHandle(NULL), "image.bmp", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_LOADFROMFILE);
    //     ::GetObject(bitmapHandle, sizeof(BITMAP), &bitmap);
    //     bitmapRenderer = ::CreateCompatibleDC(renderer);
    //     bitmapDummy = ::SelectObject(bitmapRenderer, bitmapHandle);

    //     { ::BitBlt(renderer, 100, 0, bitmap.bmWidth, bitmap.bmHeight, bitmapRenderer, 0, 0, SRCCOPY); }

    //     ::SelectObject(bitmapRenderer, bitmapDummy);
    //     ::DeleteObject(bitmapDummy);
    //     ::DeleteDC(bitmapRenderer);
    //     ::DeleteObject(bitmapHandle);
    // }

    // /* And, text */ {
    //     HFONT font = ::CreateFont(
    //         -MulDiv(12, ::GetDeviceCaps(renderer, LOGPIXELSY), 72), FW_DONTCARE, // Height, Width?
    //         FALSE, TRUE, FALSE,
    //         0, 0, 0, 0, 0, 0, 0, 0,
    //         "Times New Roman"
    //     );
    //     RECT rectangle = {300, 0, 0, 0};

    //     ::SelectObject(renderer, font);
    //     ::SetTextColor(renderer, RGB(0, 0, 0));
    //     ::SetBkMode(renderer, TRANSPARENT);
    //     { ::DrawText(renderer, "Hello, World!", -1, &rectangle, DT_LEFT | DT_NOCLIP | DT_SINGLELINE | DT_TOP); }
    //     ::DeleteObject(font);
    // }

/* Import */
#include <math.h> // Mathematics
#include <stdlib.h> // Standard Library
#include <string.h> // String
#include <windows.h> // Windows

/* Global > ... */
constexpr unsigned short const WINDOW_HEIGHT = 500u;
constexpr char const WINDOW_TITLE[] = "Snake | OLC CodeJam (2020)";
constexpr unsigned short const WINDOW_WIDTH = 500u;

/* Namespace */
    /* ... */
    namespace Game {}
    namespace Graphics {}
    namespace Events {}
    namespace Utility {}

    /* Events */
    namespace Events {
        /* Definition > ... */
        void OnDraw(HWND, HDC) noexcept;
        void OnKeyDown(HWND, WPARAM) noexcept;
    }

    /* Game */
    namespace Game {
        /* Definition > Scene */
        class Scene;

        /* Phase > (Initiate, Terminate, Update) */
        void Initiate(void);
        void Terminate(char const* const = NULL);
        LRESULT CALLBACK Update(HWND, UINT, WPARAM, LPARAM);
    }

    /* Utility --- NOTE (Lapys) -> Defined as is. */
    inline namespace Utility {
        // Definition > ...
        struct file;
        template <class, class> struct immutable_accessor;
        template <class, size_t = 0u> struct list;
        struct string;

        // Class
            // Immutable Accessor --- NOTE (Lapys) -> Immutable to non-base objects.
            template <class base, class type>
            struct immutable_accessor final { friend base;
                // [...]
                private:
                    // Definition > Value
                    type& value;

                    // [Constructor]
                    constexpr inline immutable_accessor(immutable_accessor const& accessor) : value{*new type(accessor.value)} {}

                    // [Operator] > [=]
                    constexpr inline immutable_accessor& operator =(immutable_accessor const& accessor) const noexcept { this -> value = accessor.value; return *this; }
                    constexpr inline immutable_accessor& operator =(immutable_accessor&& accessor) const noexcept = delete;
                    template <class subtype> constexpr inline immutable_accessor& operator =(subtype value) { this -> value = value; return *this; }

                // [...]
                public:
                    // [Constructor]
                    constexpr inline immutable_accessor(type& value) : value{*new type(value)} {}
                    constexpr inline immutable_accessor(type&& value) : value{*new type(value)} {}
                    template <class... types> constexpr inline immutable_accessor(types... values) : value {*new type(values...)} {}

                    // : [Destructor] --- WARN (Lapys) -> May be undefined behavior :P
                    // : [Operator] > [...]
                    inline ~immutable_accessor(void) { delete &(this -> value); }
                    constexpr inline operator type&(void) const noexcept { return this -> value; }
            };

            // List
            template <class type, size_t stack_length>
            struct list { friend file; friend string;
                // [...]
                private:
                    // Definition > (Heap, Stack)
                    type *heap;
                    type stack[stack_length ? stack_length : 1u] = {};

                // [...]
                protected:
                    // Function
                    // : Allocate, Free, Resize
                    inline void allocate(size_t length, bool const SAFE = false) noexcept {
                        // Logic > Modification > Target > (Size, Heap)
                        if (length > stack_length && length > this -> size) {
                            this -> size = (length - stack_length) * (size_t) ::ceil(1.61803398875f * !SAFE);
                            this -> heap = (type*) ::realloc(this -> heap, this -> size * sizeof(type));
                        }
                    }
                    inline void free(void) { ::free(this -> heap); this -> heap = NULL; this -> size = 0u; }

                    // : Assert, Compare, Copy, Move
                    inline bool assert(type* const index, type& value) const { return list::compare(index, value) || value == *index; }
                    inline bool compare(type* const index, type& value) const { return index == &value; }

                    inline void copy(type* const index, type& value) { *index = value; }
                    inline void move(type* const index, type& value) { ::memcpy(index, &value, sizeof(type)); }

                    // : At, First, Last
                    constexpr inline type& at(size_t const index) const noexcept { return (type&) *(index < stack_length ? this -> stack + index : this -> heap + (index - stack_length)); }
                    constexpr inline type* first(void) const noexcept { return stack_length ? this -> stack : this -> heap; }
                    constexpr inline type* last(void) const noexcept { this -> length < stack_length ? this -> stack + (this -> length - 1u) : this -> heap + (this -> length - stack_length - 1u); }

                    // : Initiate
                    inline void initiate(type* const list, size_t const length) noexcept {
                        // Logic > ...
                        if (0u == length) list::free();
                        else {
                            // Logic > Modification > Target > (Size, Stack, Heap, Length)
                            list::allocate(length, true);

                            if (length < stack_length) {
                                ::memcpy(this -> stack, list, length * sizeof(type));
                            } else {
                                ::memcpy(this -> stack, list, stack_length * sizeof(type));
                                ::memcpy(this -> heap, list + stack_length, (length - stack_length) * sizeof(type));
                            }

                            this -> length = length;
                        }
                    }
                    inline void initiate(list<type, stack_length> const& list) noexcept {
                        // ...
                        list::allocate((this -> length = list.length), true);

                        ::memcpy(this -> stack, list.stack, stack_length * sizeof(type));
                        (list.length >= stack_length) && ::memcpy(this -> heap, list.heap, (list.length - stack_length) * sizeof(type));
                    }
                    inline void initiate(list<type, stack_length>&& list) noexcept {
                        // Modification > (List, Target) > ...
                        this -> length = list.length;
                        this -> heap = list.heap;
                        this -> size = list.size;
                        ::memcpy(this -> stack, list.stack, stack_length * sizeof(type));

                        list.heap = NULL;
                        list.length = 0u;
                        list.size = 0u;
                    }

                    // : Push, Search
                    constexpr inline void push(type& value, void (list<type, stack_length>::* mutator)(type* const, type&)) noexcept {
                        // Logic > ...
                        if (this -> length < stack_length) (this ->* mutator)(this -> stack + this -> length++, value);
                        else { list::allocate((this -> length - stack_length) + 1u); (this ->* mutator)(this -> heap + (this -> length - stack_length), value); }
                    }

                    constexpr inline signed search(type& value, bool (list<type, stack_length>::* const comparator)(type* const, type&) const) const {
                        // Initialization > (End, Iterator)
                        type *end = NULL, *iterator = NULL;

                        // Loop > Logic > Return
                        // : [Stack]
                        for (
                            end = (type*) this -> stack + (this -> length > stack_length ? stack_length : (size_t) this -> length), iterator = (type*) this -> stack;
                            end != iterator; ++iterator
                        ) if ((this ->* comparator)(iterator, value)) return iterator - this -> stack;

                        // : [Heap]
                        if (this -> length > stack_length)
                        for (
                            end = (type*) this -> heap + (this -> length - stack_length), iterator = (type*) this -> heap;
                            end != iterator; ++iterator
                        ) if ((this ->* comparator)(iterator, value)) return iterator - this -> heap;

                        // Return
                        return -1;
                    }

                // [...]
                public:
                    // Definition > (Length, Size)
                    immutable_accessor<list, size_t> length;
                    immutable_accessor<list, size_t> size;

                    // [Constructor]
                    constexpr inline list(void) : heap{NULL}, stack{}, length{0u}, size{0u} {}
                    inline list(size_t const length) : heap{NULL}, stack{}, length{length}, size{0u} { list::allocate(length, true); }
                    inline list(type* const list, size_t const length) : heap{NULL}, stack{}, length{0u}, size{0u} { list::initiate(list, length); }
                    inline list(list<type, stack_length> const& _list) : heap{NULL}, stack{}, length{0u}, size{0u} { list::initiate(_list); }
                    inline list(list<type, stack_length>&& _list) : heap{NULL}, stack{}, length{0u}, size{0u} { list::initiate((list<type, stack_length>&&) _list); }

                    // [Destructor]
                    inline ~list(void) { list::free(); }

                    // Function > ...
                    constexpr inline void add(type& value) noexcept { list::push(value, &list::move); }
                    constexpr inline void add(type&& value) noexcept { list::push(value, &list::copy); }
                    constexpr inline void empty(void) noexcept { this -> length = 0u; }
                    constexpr inline bool includes(type& value) const noexcept { return ~list::index(value); }
                    constexpr inline signed index(type& value, bool const SAFE = false) const noexcept { return list::search(value, SAFE ? &list::compare : &list::assert); }
                    constexpr inline signed index(type&& value) const noexcept { return list::search(value, &list::assert); }
                    constexpr inline bool pop(void) noexcept { return this -> length && --(this -> length); }
                    constexpr inline bool remove(type& value) noexcept { constexpr signed const index = list::index(value); return ~index && list::splice((size_t) index); }
                    constexpr inline void resize(size_t const length) noexcept { list::allocate((this -> length = length), true); }
                    constexpr inline bool splice(size_t const index) noexcept {
                        // Logic > ... Return
                        if (index < this -> length) {
                            ::memcpy(index < stack_length ? this -> stack + index : this -> heap + (index - stack_length), list::last(), sizeof(type));
                            --(this -> length);

                            return true;
                        } return false;
                    }

                    // [Operator] > ...
                    inline list<type, stack_length>& operator =(list<type, stack_length> const& _list) noexcept { list::empty(); list::free(); list::initiate(_list); return *this; }
                    inline list<type, stack_length>& operator =(list<type, stack_length>&& _list) noexcept { list::empty(); list::free(); list::initiate((list<type, stack_length>&&) _list); return *this; }

                    constexpr inline type& operator [](int const index) const { return index < 0 || 0u == this -> length ? Game::Terminate("[Error]: Indexed `list` out of range"), *(type*) NULL : list::at((size_t) index); }
                    constexpr inline operator type*(void) const noexcept = delete;
            };

            // String
            struct string final : public list<char, 32u * sizeof(char)> { friend file;
                // [...]
                public:
                    // [Constructor]
                    inline string(char* const value) : list(value, ::strlen(value)) {}
                    inline string(char const* const value) : list((char*) value, ::strlen(value)) {}
                    constexpr inline string(int) : list() {}
                    constexpr inline string(void) : list() {}

                    // Function > ...
                    inline bool includes(char const value) const noexcept { return list::includes((char&) value); }
                    inline signed index(char const value) const noexcept { return list::index((char&) value); }
                    inline char* load(void) const noexcept {
                        // Initialization > (Evaluation, Length)
                        char *const evaluation = (char*) ::malloc((this -> length + 1u) * sizeof(char));
                        size_t length = sizeof(this -> stack) / sizeof(char);

                        // Logic > Update > ...
                        if (this -> length < length) ::strncpy(evaluation, this -> stack, length = this -> length);
                        else {
                            ::strncpy(evaluation, this -> stack, length);
                            ::strncpy(evaluation, this -> heap, this -> length - length);

                            length = this -> length;
                        }

                        // ...; Return
                        *(evaluation + length) = '\0';
                        return evaluation;
                    }

                    // [Operator] > [...]
                    inline char& operator [](int const index) const { return list::at(index); }
                    inline operator char*(void) const noexcept { return string::load(); }
            };

            // File --- NOTE (Lapys) -> Always open in binary mode.
            struct file {
                // [...]
                private:
                    // Definition > (Mode, Stream)
                    struct mode_t {
                        private: unsigned char value;
                        public: static mode_t const append, read, update, write;
                            constexpr inline mode_t(void) : value{0x0} {}
                            constexpr inline mode_t(unsigned char const value) : value{value} {}

                            constexpr inline operator unsigned char&(void) const noexcept { return (unsigned char&) this -> value; }
                    } mode;
                    FILE *stream;

                // [...]
                protected:
                    // Function > (Close, Open, Translate)
                    inline void close(void) noexcept { ::fclose(this -> stream); }
                    inline void open(char const* const path, file::mode_t const mode) noexcept { this -> stream = ::fopen(path, file::translate(mode)); }
                    constexpr inline static char const* translate(file::mode_t const mode) noexcept {
                        // ... Return
                        if (mode & mode_t::append) return mode & mode_t::update ? "ab+" : "ab";
                        else if (mode & mode_t::read) return mode & mode_t::update ? "rb+" : "rb";
                        else if (mode & mode_t::write) return mode & mode_t::update ? "wb+" : "wb";

                        return NULL;
                    }

                // [...]
                public:
                    // Definition > Path
                    immutable_accessor<file, char const*> path;

                    // [Constructor]
                    inline file(void) : mode{0x0}, stream{::tmpfile()}, path{(char*) NULL} {}
                    inline file(file::mode_t const mode) : mode{mode}, stream{NULL}, path{(char*) NULL} { file::open((char const*) ::tmpnam(NULL), mode); }
                    inline file(char* const path, file::mode_t const mode = mode_t::read | mode_t::update) : mode{mode}, stream{NULL}, path{(char const*) path} { file::open(path, mode); }
                    inline file(char const* const path, file::mode_t const mode = mode_t::read | mode_t::update) : mode{mode}, stream{NULL}, path{path} { file::open(path, mode); }

                    // [Destructor]
                    inline ~file(void) { file::close(); }

                    // Function > ...
                    inline void empty(void) noexcept {
                        // Terminate
                        file::close();

                        // Logic > ...
                        if (0x0 == this -> mode) this -> stream = ::tmpfile();
                        else if (NULL == this -> path) {
                            file::open((char const*) ::tmpnam(NULL), this -> mode | mode_t::write);
                            file::close();
                            file::open((char const*) ::tmpnam(NULL), this -> mode);
                        } else {
                            file::open((char const*) this -> path, this -> mode | mode_t::write);
                            file::close();
                            file::open((char const*) this -> path, this -> mode);
                        }
                    }

                    inline char* read(void) const noexcept { return file::readInto((char*) ::calloc(file::size() + 1u, sizeof(char))); }
                    inline char* read(size_t const length) const noexcept { return file::readInto((char*) ::calloc(length + 1u, sizeof(char)), length); }
                    inline char* readInto(char* const buffer) const noexcept { return file::readInto(buffer, file::size()); }
                    inline char* readInto(char* const buffer, size_t const length) const noexcept { ::fread(buffer, sizeof(char), length, this -> stream); return buffer; }
                    inline char* readIntoLine(char* const buffer) const noexcept { return file::readIntoUntil(buffer, '\n'); }
                    inline char* readIntoUntil(char* const buffer, char const match) const noexcept { char *iterator = buffer; for (int character; character = ::fgetc(this -> stream), EOF != character && match != character; ++iterator) *iterator = character; return buffer; }
                    inline char* readIntoUntil(char* const buffer, char* const match) const noexcept { return file::readIntoUntil(buffer, (char const*) match); }
                    inline char* readIntoUntil(char* const buffer, char const* const match) const noexcept {
                        // Initialization > (End, Length)
                        char *end = buffer;
                        size_t const length = ::strlen(match);

                        // Loop
                        for (int character; character = ::fgetc(this -> stream), EOF != character; ) {
                            // Initialization > Iterator
                            // : Update > End; Loop
                            char *iterator = end + 1;

                            *end++ = character;
                            for (char const *subiterator = match + (length - 1u); buffer != iterator--; --subiterator) {
                                // Logic > ...
                                if (*iterator != *subiterator) break;
                                else if (match == subiterator) { *(end -= length) = '\0'; return buffer; }
                            }
                        }

                        // Return
                        return buffer;
                    }
                    inline char* readLine(void) const noexcept { return file::readUntil('\n'); }
                    inline char* readUntil(char const match) const noexcept { string buffer; for (int character; character = ::fgetc(this -> stream), EOF != character && match != character; ) buffer.add(character); return buffer.load(); }
                    inline char* readUntil(char* const match) const noexcept { return file::readUntil((char const*) match); }
                    inline char* readUntil(char const* const match) const noexcept {
                        // Initialization > (Buffer, Length)
                        string buffer;
                        size_t const length = ::strlen(match);

                        // Loop
                        for (int character; character = ::fgetc(this -> stream), EOF != character; ) {
                            // Initialization > Iterator
                            // : Loop
                            size_t iterator = buffer.length;
                            for (char const *subiterator = match + (length - 1u); iterator--; --subiterator) {
                                // Logic > ...
                                if (buffer.at(iterator) != *subiterator) break;
                                else if (match == subiterator) { buffer.resize(buffer.length - length); return buffer.load(); }
                            }

                            // Continue
                            buffer.add(character);
                        }

                        // Return
                        return buffer.load();
                    }

                    inline void seekBegin(void) const noexcept { ::fseek(this -> stream, 0L, SEEK_SET); }
                    inline void seekBy(size_t const length) const noexcept { ::fseek(this -> stream, length, SEEK_CUR); }
                    inline void seekTo(size_t const position) const noexcept { ::fseek(this -> stream, position, SEEK_SET); }
                    inline void seekEnd(void) const noexcept { ::fseek(this -> stream, 0L, SEEK_END); }

                    inline long size(void) const noexcept {
                        // Constant > (Current, Size)
                        long const current = ::ftell(this -> stream);
                        long const size = (file::seekEnd(), ::ftell(this -> stream));

                        // Return
                        return file::seekTo(current), size;
                    }

                    inline bool remove(void) noexcept { return 0 == ::remove(this -> path); }
                    inline bool rename(char* const name) noexcept { return file::rename((char const*) name); }
                    inline bool rename(char const* const name) noexcept { return 0 == ::rename(this -> path, name); this -> path = name; }

                    inline void write(char* const content) noexcept { file::write((char const*) content); }
                    inline void write(char const* const content) noexcept { ::fwrite(content, sizeof(char), ::strlen(content), this -> stream); }
                    inline void write(void* const content, size_t const length) noexcept { ::fwrite(content, sizeof(unsigned char), length, this -> stream); }
                    inline void write(file const& file) noexcept {
                        // Logic
                        if (NULL == file.stream) file::empty();
                        else {
                            // Constant > (Current, Length, Content)
                            long const current = ::ftell(file.stream);
                            long const length = file.size();
                            void *const content = ::calloc(length + 1u, sizeof(char));

                            // ...
                            file.seekBegin();
                            ::fread(content, sizeof(char), length, file.stream);
                            ::fwrite(content, sizeof(char), length, this -> stream);
                            file.seekTo(current);
                        }
                    }
            };

            file::mode_t const file::mode_t::append = 0x1;
            file::mode_t const file::mode_t::read = 0x2;
            file::mode_t const file::mode_t::update = 0x4;
            file::mode_t const file::mode_t::write = 0x8;
    }

    /* Graphics */
    inline namespace Graphics {
        /* Definition > ... */
        class Color;
        class Composition;
        class Drawable;

        class Image;
        class Line;
        class Shape;
        class Text;

        class Circle;
        class Ellipse;
        class Rectangle;
        class Square;

        /* Definition > Draw */
        void draw(Drawable const&);
        void setFont(char const* const, unsigned char const) noexcept;
    }

/* Modification */
/* : Events */
    // On Draw
    void Events::OnDraw(HWND, HDC) noexcept {}

    // On Key Down
    void Events::OnKeyDown(HWND, WPARAM key) noexcept {
        // Logic
        switch (key) {
            case VK_ESCAPE: Game::Terminate(); break;
            case VK_DOWN: /* Down arrow movement */ break;
            case VK_LEFT: /* Left arrow movement */ break;
            case VK_RIGHT: /* Right arrow movement */ break;
            case VK_UP: /* Up arrow movement */ break;
        }
    }

/* : Graphics */
    /* Class */
    /* : Color */
    class Graphics::Color final {
        // [...] ...
        private: unsigned int value;
        public:
            // [Constructor]
            constexpr inline Color(unsigned int const value = 0x0000000) : value{value} {}
            constexpr inline Color(unsigned char const red, unsigned char const green, unsigned char const blue, bool const alpha = 1u) : value{((unsigned int) blue) + (-~0x0000FF * (unsigned int) green) + (-~0x00FFFF * (unsigned int) red) + (((unsigned int) alpha) << 0x18)} {}

            // Function > (Get, Set) (Alpha, Blue, Green, Red)
            constexpr inline unsigned char getAlpha(void) const noexcept { return this -> value >> 24u; }
            constexpr inline unsigned char getBlue(void) const noexcept { return this -> value & 0xFF; }
            constexpr inline unsigned char getGreen(void) const noexcept { return (this -> value >> 8u) & 0xFF; }
            constexpr inline unsigned char getRed(void) const noexcept { return (this -> value >> 16u) & 0xFF; }

            constexpr inline void setAlpha(bool const range) noexcept { this -> value &= 0x0FFFFFF; this -> value |= range ? 0x1000000 : 0x0000000; }
            constexpr inline void setBlue(unsigned char const range) noexcept { this -> value = range + (this -> value & 0x1FFFF00); }
            constexpr inline void setGreen(unsigned char const range) noexcept { this -> value = (-~0x0000FF * range) + (this -> value & 0x1FF00FF); }
            constexpr inline void setRed(unsigned char const range) noexcept { this -> value = (-~0x00FFFF * range) + (this -> value & 0x100FFFF); }

            // [Operator] > ...
            constexpr inline operator unsigned int(void) const noexcept { return this -> value & 0x0FFFFFF; }
    };

    /* : Drawable */
    class Graphics::Drawable {
        // [...]
        public:
            // Definition > (X, Y)
            immutable_accessor<Drawable, unsigned short> x;
            immutable_accessor<Drawable, unsigned short> y;

            // [Constructor]
            constexpr inline Drawable(void) : x{0u}, y{0u} {}

            // Function > Draw
            inline virtual void draw(HWND, HDC) const noexcept {}
    };

    /* : Composition */
    class Graphics::Composition final : public Drawable {
        // [...] ...
        private: list<Drawable, 0u> drawables;
        public:
            // [Constructor]
            constexpr inline Composition(void) : Drawable() {}

            // Function > (Append, Draw, Remove)
            inline void append(Drawable const& drawable) { this -> drawables.includes(drawable) || this -> drawables.add(drawable); }
            inline void draw(HWND windowHandle, HDC renderer) const noexcept override {
                // Initialization > Iterator
                // : Loop
                size_t iterator = this -> drawables.length;
                while (iterator--) {
                    // Initialization > Drawable
                    Drawable& drawable = this -> drawables[iterator];

                    // Modification > Drawable > (X, Y); ...
                    drawable.x += this -> x;
                    drawable.y += this -> y;

                    drawable.draw(windowHandle, renderer);

                    drawable.x -= this -> x;
                    drawable.y -= this -> y;
                }
            }
            inline void remove(Drawable const& drawable) { this -> drawables.remove(drawable); }
    };

    /* : Image */
    class Graphics::Image : public Drawable {
        // [...]
        public:
            // Definition > Path
            immutable_accessor<Image, string const> path;
    };

    /* : Line */
    class Graphics::Line : public Drawable {};

    /* : Shape */
    class Graphics::Shape : public Drawable {};

    /* : Text --- NOTE (Lapys) -> ASCII-only. */
    class Graphics::Text : public Drawable {
        // [...]
        public:
            // Definition > (Content, Font)
            immutable_accessor<Text, string> content;
            struct font_t { public:
                char const *family;
                unsigned char size;
            } font;
            static font_t *recentFont;

            // Function > Draw
            inline virtual void draw(HWND windowHandle, HDC renderer) const noexcept {
                HFONT font = ::CreateFont(
                    -MulDiv(12, ::GetDeviceCaps(renderer, LOGPIXELSY), 72), FW_DONTCARE, // Height, Width?
                    FALSE, TRUE, FALSE,
                    0, 0, 0, 0, 0, 0, 0, 0,
                    this -> font.family
                );
                RECT rectangle = {300, 0, 0, 0};

                ::SelectObject(renderer, font);
                ::SetTextColor(renderer, RGB(0, 0, 0));
                ::SetBkMode(renderer, TRANSPARENT);
                { ::DrawText(renderer, "Hello, World!", -1, &rectangle, DT_LEFT | DT_NOCLIP | DT_SINGLELINE | DT_TOP); }
                ::DeleteObject(font);
            }
    };

    /* : Circle */
    class Graphics::Circle : public Shape {};

    /* : Ellipse */
    class Graphics::Ellipse : public Shape {};

    /* : Rectangle */
    class Graphics::Rectangle : public Shape {};

    /* : Square */
    class Graphics::Square : public Shape {};

    /* Function */
        // Draw
        void Graphics::draw(Drawable const&) {}

/* : Game > Phase */
    /* Initiate */
    void Game::Initiate(void) {}

    /* Terminate */
    void Game::Terminate(char const* const errorMessage) {
        // Logic
        if (NULL != errorMessage) {
            // Error
            ::putchar('\r'); ::puts(errorMessage); ::putchar('\0');
            ::PostQuitMessage(0);
            ::exit(EXIT_FAILURE);
        }

        else {
            // ...
            ::PostQuitMessage(0);
        }
    }

    /* Update */
    LRESULT CALLBACK Game::Update(HWND windowHandle, UINT message, WPARAM parameter, LPARAM additionalParameter) {
        // Logic --- REDACT (Lapys)
        switch (message) {
            case WM_CLOSE: { ::DestroyWindow(windowHandle); goto Terminate; } break;
            case WM_QUIT: ::DestroyWindow(windowHandle); break;
            case WM_SYSCOMMAND: if (parameter == SC_CLOSE) { ::DestroyWindow(windowHandle); goto Terminate; } break;
            case WM_SYSKEYDOWN: if (parameter == VK_F4) { ::DestroyWindow(windowHandle); goto Terminate; } break;

            case WM_DESTROY: goto Terminate; break;
            case WM_KEYDOWN: Events::OnKeyDown(windowHandle, parameter); break;
            case WM_PAINT: {
                HDC renderer; PAINTSTRUCT paintInformation = {};

                Events::OnDraw(windowHandle, renderer = ::BeginPaint(windowHandle, &paintInformation));

                ::ReleaseDC(windowHandle, renderer);
                ::EndPaint(windowHandle, &paintInformation);
            } break;
        }

        // [Evaluate, Terminate]
        Evaluate: return ::DefWindowProc(windowHandle, message, parameter, additionalParameter);
        Terminate: Game::Terminate(); goto Evaluate;
    }

/* Main */
int WinMain(HINSTANCE instanceHandle, HINSTANCE, LPSTR programInitiationCommandLine, int windowAppearance) {
    // Global > (Screen, Window) ...
    RECT screenBoundingBox = {};

    WNDCLASS const windowClass {
        CS_HREDRAW | CS_VREDRAW, &Game::Update,
        0, 0, instanceHandle, NULL,
        (HCURSOR) ::LoadCursor(NULL, IDC_ARROW),
        (HBRUSH) COLOR_WINDOW,
        NULL, "DefaultClass"
    };
    HWND windowHandle = NULL;
    MSG windowMessage {windowHandle, 0, EXIT_SUCCESS, 0, 0, {0L, 0L}};

    // : Update > Screen Bounding Box
    // Logic
    ::SystemParametersInfo(SPI_GETWORKAREA, 0, (PVOID) &screenBoundingBox, 0);
    if (::RegisterClass(&windowClass)) {
        // Update > Window Handle
        windowHandle = ::CreateWindow(
            windowClass.lpszClassName, WINDOW_TITLE, WS_OVERLAPPEDWINDOW,

            ((screenBoundingBox.right - screenBoundingBox.left) - WINDOW_WIDTH) / 2u,
            ((screenBoundingBox.bottom - screenBoundingBox.top) - WINDOW_HEIGHT) / 2u,

            WINDOW_WIDTH,
            WINDOW_HEIGHT,

            NULL, NULL, instanceHandle, NULL
        );

        // Logic
        if (windowHandle) {
            /* [Initiate] */
            Game::Initiate();

            /* [Update] */ {
                // Update > Window Handle
                ::ShowWindow(windowHandle, windowAppearance);
                ::UpdateWindow(windowHandle);

                // Loop --- NOTE (Lapys) -> `PeekMessage()` isn't necessary
                while (::GetMessage(&windowMessage, NULL, 0, 0)) {
                    // Update > Window Message
                    ::TranslateMessage(&windowMessage);
                    ::DispatchMessage(&windowMessage);
                }
            }

            /* [Terminate] */
            ::UnregisterClass(windowClass.lpszClassName, windowClass.hInstance);
            ::exit(windowMessage.wParam);
        }

        else {
            // Terminate
            ::UnregisterClass(windowClass.lpszClassName, windowClass.hInstance);
            ::exit(EXIT_SUCCESS);
        }
    }

    // Return
    return EXIT_SUCCESS;
}

