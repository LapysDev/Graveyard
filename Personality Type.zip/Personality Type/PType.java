/* Import */
    // Java > Abstract Window Toolkit > All
    import java.awt.*;
        // Event > All
        import java.awt.event.*;

    // Java Extension > Swing > All
    import javax.swing.*;

/* Class */
    /* Application
            --- NOTE ---
                #Lapys: Keep all details of our application in here.
    */
    class Application {
        // Initialization
            // Author
            String author = "";

            // Copyright
            String copyright = "";

            // Description
            String description = "";

            // Name
            String name = "";
    }

    // Option
    class Option {
        // Initialization > (Personality, Score, Text)
        String[] personality = {};
        int[] score = {};
        String text = "";

        // [Constructor]
        public Option(String newText, String[] newPersonality, int[] newScore) {
            // Update > (Personality, Score, Text)
            personality = newPersonality;
            score = newScore;
            text = newText;
        }
    }

    // Personalities
    class Personalities {
        // Initialization > (...)
        int Architect = 0;
        int Commander = 0;
        int Campaigner = 0;
        int Mediator = 0;

        // Function
            // Get Personality {Score}
            int getPersonality(int personality) {
                // Initialization > Personality Score
                int personalityScore;

                // Logic > Update > Personality Score
                switch (personality) {
                    case 0: personalityScore = getPersonality("Architect"); break;
                    case 1: personalityScore = getPersonality("Campaigner"); break;
                    case 2: personalityScore = getPersonality("Commander"); break;
                    case 3: personalityScore = getPersonality("Mediator"); break;
                    default: personalityScore = 0; break;
                }

                // Return
                return personalityScore;
            }

            int getPersonality(String personality) {
                // Initialization > Personality Score
                int personalityScore;

                // Logic > Update > Personality Score
                switch (personality) {
                    case "Architect": personalityScore = Architect; break;
                    case "Campaigner": personalityScore = Campaigner; break;
                    case "Commander": personalityScore = Commander; break;
                    case "Mediator": personalityScore = Mediator; break;
                    default: personalityScore = 0; break;
                }

                // Return
                return personalityScore;
            }

            // Get Personality Type
            String getPersonalityType(int personality) {
                // Initialization > Personality Score
                String personalityType = "";

                // Logic > Update > Personality Score
                switch (personality) {
                    case 0: personalityType = "Architect"; break;
                    case 1: personalityType = "Campaigner"; break;
                    case 2: personalityType = "Commander"; break;
                    case 3: personalityType = "Mediator"; break;
                }

                // Return
                return personalityType;
            }

            // Set Personality
            int setPersonality(String personality, int value) {
                // Logic > Return
                if (personality == "Architect")
                    return Architect = value;

                else if (personality == "Campaigner")
                    return Campaigner = value;

                else if (personality == "Commander")
                    return Commander = value;

                else if (personality == "Mediator")
                    return Mediator = value;

                else
                    return 0;
            }
    }

    // Question Set
    class QuestionSet {
        // Initialization > (Options, Question)
        Option[] options;
        String question;

        // [Constructor]
        public QuestionSet(String newQuestion) { question = newQuestion; }
        public QuestionSet(String newQuestion, Option[] newOptions) {
            // Update > (Question, Options)
            question = newQuestion;
            options = newOptions;
        }
    }

    /* P Type */
    public class PType {
        /* Global Data */
            // Application
            static Application APP = new Application();

            // Personalities
            static Personalities PERSONALITIES = new Personalities();

            // Questions Complete
            static boolean QUESTIONS_COMPLETE = false;

            // Question Set
            static QuestionSet[] QUESTION_SETS = {
                new QuestionSet("QUESTION A", new Option[]{
                    new Option("OPTION A", new String[]{"Architect"}, new int[]{30}),
                    new Option("OPTION B", new String[]{"Architect", "Campaigner"}, new int[]{15, 45})
                }),

                new QuestionSet("QUESTION B", new Option[]{
                    new Option("OPTION A", new String[]{"Architect"}, new int[]{30})
                })
            };

            // Question Set Index
            static int QUESTION_SET_INDEX = 0;

            // (Question, Result, Title) Screen
            static Panel QUESTION_SCREEN, RESULT_SCREEN, TITLE_SCREEN;

        /* Function */
            /* Configure Settings */
            static void configureSettings() {
                // Modification
                    // Application
                        // Author
                        APP.author = "Lapys Dev Team";

                        // Copyright
                        APP.copyright = "John Akinola";

                        // Description
                        APP.description = "An application built with Java & lots of hard-work.";

                        // Name
                        APP.name = "PType";
            }

            /* Display Questions */
            static void displayQuestions(int questionIndex) {
                /* Logic
                        [if:else statement]
                */
                if (questionIndex > QUESTION_SETS.length - 1)
                    // Prepare Results
                    prepareResults();

                else {
                    // Initialization > Question Set
                    QuestionSet questionSet = QUESTION_SETS[questionIndex];

                    // Initialization > Question Container
                    Panel questionContainer = new Panel();

                    // Initialization > Question Header
                    Label questionHeader = new Label();

                    // Question Header > Set Text
                    questionHeader.setText(questionSet.question);

                    // Insertion
                    questionContainer.add(questionHeader);

                    /* Loop
                            Index (Question Set > Options).
                    */
                    for (int iterator = 0; iterator != questionSet.options.length; iterator += 1) {
                        // Initialization > (Option, Question Button)
                        Option option = questionSet.options[iterator];
                        Button questionButton = new Button();

                        // Question Button > Add Action Listener
                        questionButton.addActionListener(new ActionListener() {public void actionPerformed(ActionEvent event) {
                            // Loop > Personalities > Set Personality
                            for (int iterator = 0; iterator != option.personality.length; iterator += 1)
                                PERSONALITIES.setPersonality(option.personality[iterator], PERSONALITIES.getPersonality(option.personality[iterator]) + option.score[iterator]);

                            // Deletion
                            QUESTION_SCREEN.remove(questionContainer);

                            // Display Questions
                            displayQuestions(QUESTION_SET_INDEX += 1);
                        }});

                        // Initialization > Question Option
                        Label questionOption = new Label();

                        // Question Option > Set Text
                        questionOption.setText(option.text);

                        // Insertion
                        questionContainer.add(questionButton);
                        questionContainer.add(questionOption);
                    }

                    // Insertion
                    QUESTION_SCREEN.add(questionContainer);
                }
            }

            /* Display Results */
            static void displayResults() {
                // Initialization > Iterator --- NOTE (Lapys) -> The four personality types.
                int iterator = 4;

                // Loop
                while (iterator != 0) {
                    // Update > Iterator
                    iterator -= 1;

                    // Initialization > Container
                    Panel container = new Panel();

                    // Initialization > Label
                    Label label = new Label();

                    // Label > Set Text
                    label.setText(PERSONALITIES.getPersonalityType(iterator) + ": " + PERSONALITIES.getPersonality(iterator));

                    // Insertion
                    container.add(label);
                    RESULT_SCREEN.add(container);
                }
            }

            /* Prepare GUI */
            static Frame prepareGUI(Application app) {
                // Initialization
                    // Header Container
                    final Panel headerContainer = new Panel();
                        // Header, Sub Header
                        Label header = new Label(), subheader = new Label();

                    // Options Container
                    final Panel optionsContainer = new Panel();
                        //  Initialize Test Container
                        final Panel initTestContainer = new Panel();
                            // Initialize Test Button
                            Button initTestButton = new Button();

                            // Initialize Test Label
                            Label initTestLabel = new Label();

                        // About Container
                        final Panel aboutContainer = new Panel();
                            // View Result Button
                            Button aboutButton = new Button();

                            // View Result Label
                            Label aboutLabel = new Label();

                    // Message Container
                    final Panel messageContainer = new Panel();
                        // Message
                        Label message = new Label();

                    /* Result Screen */
                    final Panel resultScreen = RESULT_SCREEN = new Panel(),

                    /* Test Screen */
                    testScreen = QUESTION_SCREEN = new Panel(),

                    /* Title Screen */
                    titleScreen = TITLE_SCREEN = new Panel();

                    /* Window */
                    Frame window = new Frame(app.name);

                // Header, Sub Header > (...)
                header.setAlignment(Label.CENTER);
                header.setText(app.name);
                subheader.setAlignment(Label.CENTER);
                subheader.setText(app.description);

                // Insertion
                headerContainer.add(header);
                headerContainer.add(subheader);

                // (Initialize Test, About) Label > (...)
                initTestLabel.setText("Take a Test");
                aboutLabel.setText("About");

                // Insertion
                optionsContainer.add(initTestContainer);
                    initTestContainer.add(initTestButton);
                    initTestContainer.add(initTestLabel);

                optionsContainer.add(aboutContainer);
                    aboutContainer.add(aboutButton);
                    aboutContainer.add(aboutLabel);

                // Message > (...)
                message.setForeground(Color.RED);

                // Insertion
                messageContainer.add(message);

                /* Result Screen */
                    // Set Visible
                    resultScreen.setVisible(false);

                /* Test Screen */
                    // Set Visible
                    testScreen.setVisible(false);

                /* Title Screen */
                    // Insertion
                    titleScreen.add(headerContainer);
                    titleScreen.add(optionsContainer);
                    titleScreen.add(messageContainer);

                /* Window */
                    // Add > (Result, Test, Title) Screen
                    window.add(resultScreen);
                    window.add(testScreen);
                    window.add(titleScreen);

                    // Set Layout
                    window.setLayout(new GridLayout(3, 1));

                    // Set Size
                    window.setSize(400, 600);

                    // Set Visible
                    window.setVisible(true);

                // Event
                    // About Button --- CHECKPOINT ---
                    aboutButton.addActionListener(new ActionListener() {public void actionPerformed(ActionEvent event) {
                        /* Some code here... */
                    }});

                    // Initialize Test Button
                    initTestButton.addActionListener(new ActionListener() {public void actionPerformed(ActionEvent event) {
                        // Prepare Questions
                        prepareQuestions();
                    }});

                    // Window
                    window.addWindowListener(new WindowAdapter() {public void windowClosing(WindowEvent event){
                        // System > Exit
                        System.exit(0);
                    }});

                // Return
                return window;
            }

            /* Prepare Questions*/
            static void prepareQuestions() {
                // (Question, Result, Title) Screen > Set Visible
                QUESTION_SCREEN.setVisible(true);
                RESULT_SCREEN.setVisible(false);
                TITLE_SCREEN.setVisible(false);

                // Display Questions
                displayQuestions(QUESTION_SET_INDEX);
            }

            /* Prepare Results */
            static void prepareResults() {
                // (Question, Result, Title) Screen > Set Visible
                QUESTION_SCREEN.setVisible(false);
                RESULT_SCREEN.setVisible(true);
                TITLE_SCREEN.setVisible(false);

                // Initialization > Result Screen Loading Message
                Label resultScreenLoadingMessage = new Label();

                // Result Screen Loading Message > Set Text
                resultScreenLoadingMessage.setText("Preparing results, please wait...");

                // Insertion
                RESULT_SCREEN.add(resultScreenLoadingMessage);

                // [Timer] > Schedule
                new java.util.Timer().schedule(new java.util.TimerTask() {@Override public void run() {
                    // Deletion
                    RESULT_SCREEN.remove(resultScreenLoadingMessage);

                    // Display Results
                    displayResults();
                }}, 1500);
            }

            /* Main */
            public static void main(String[] args) {
                // Configure Settings
                configureSettings();

                // Prepare GUI --- NOTE (Lapys) -> Prepare the GUI using the application.
                prepareGUI(APP);
            }
    }
