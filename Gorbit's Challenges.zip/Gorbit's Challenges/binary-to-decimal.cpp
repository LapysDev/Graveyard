#include<stdio.h>
main(d,b)char**b;{for(d=0;*b[1];d=d*2+*b[1]++-48);printf("%d",d);}
