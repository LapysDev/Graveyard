#include <cstdarg>
#include <cstddef>
#include <cstdio>

/* ... */
struct Cell {
  enum { EMPTY, FULL, ROW };
  unsigned value;

  // ...
  Cell(unsigned const value = EMPTY) : value(value) {}
  operator unsigned() const { return this -> value; }
};

struct Shape {
  Cell    *cells;
  unsigned column;
  unsigned height;
  unsigned row;
  char     textureMap[2];
  unsigned width;

  protected:
    template <std::size_t height, std::size_t width>
    void setCells(Cell (&cells)[height][width], ...) {
      std::va_list arguments;

      // ...
      this -> cells  = reinterpret_cast<Cell*>(cells);
      this -> height = height;
      this -> width  = width;

      va_start(arguments, cells);

      for (Cell (*row)[width] = cells; height != row - cells; ++row)
      for (Cell *column = *row; width != column - *row; ++column) {
        Cell const cell = va_arg(arguments, Cell);

        // ...
        if (Cell::ROW != cell) { *column = cell; continue; }
        while (width != column - *row) *(column++) = Cell::EMPTY;

        break;
      }

      va_end(arguments);
    }

  public:
    Shape() : cells(NULL), column(0u), height(0u), row(0u), textureMap(), width(0u) { this -> resetTextureMap(); }
    Shape(unsigned const column, unsigned const row) : cells(NULL), column(column), height(0u), row(row), textureMap(), width(0u) { this -> resetTextureMap(); }

    // ...
    Shape clone() const {
      Shape shape = Shape(this -> column, this -> row);

      // ...
      shape.cells  = this -> cells;
      shape.height = this -> height;
      shape.width  = this -> width;
      shape.setTextureMap(this -> textureMap);

      // ...
      return shape;
    }

    void resetTextureMap() {
      this -> textureMap[Cell::EMPTY] = ' ';
      this -> textureMap[Cell::FULL]  = '*';
    }

    void rotate() {
      for (std::size_t row = this -> height; row; )
      for (Cell const *column = this -> cells[--row] + this -> width; this -> cells[row] != column; ) {
        column - (this -> cells[row]), row
      }
      // [0, 0] => [2, 0]
      // [1, 0] => [2, 1]
      // [2, 0] => [2, 2]
      // [3, 0] => [2, 3]

      // [0, 1] => [1, 0]
      // [1, 1] => [1, 1]
      // [2, 1] => [1, 2]
      // [3, 1] => [1, 3]

      // [0, 2] => [0, 0]
      // [1, 2] => [0, 1]
      // [2, 2] => [0, 2]
      // [3, 2] => [0, 3]
    }

    template <std::size_t size>
    void setTextureMap(char const (&map)[size]) {
      for (char *destination = this -> textureMap + ((size < sizeof(Shape::textureMap) ? size : sizeof(Shape::textureMap))), *source = const_cast<char*>(map + ((size < sizeof(Shape::textureMap) ? size : sizeof(Shape::textureMap)))); map != source; )
      *--destination = *--source;
    }
};
  struct T : public Shape {
    union {
      Cell cells[4][3];
      Cell rotatedCells[3][4];
    };

    // ...
    T() : Shape(0u, 0u) { this -> setCells(this -> cells, Cell::FULL, Cell::FULL, Cell::FULL, Cell::EMPTY, Cell::FULL, Cell::ROW, Cell::EMPTY, Cell::FULL, Cell::ROW, Cell::EMPTY, Cell::FULL, Cell::ROW); }
    T(unsigned const column, unsigned const row) : Shape(column, row) { this -> setCells(this -> cells, Cell::FULL, Cell::FULL, Cell::FULL, Cell::EMPTY, Cell::FULL, Cell::ROW, Cell::EMPTY, Cell::FULL, Cell::ROW, Cell::EMPTY, Cell::FULL, Cell::ROW); }

    // ...
    T clone() const {
      Shape const shape = this -> Shape::clone();
      T           t     = T();

      // ...
      t.Shape::cells = reinterpret_cast<Cell*>(t.cells);
      t.column       = shape.column;
      t.height       = shape.height;
      t.row          = shape.row;
      t.width        = shape.width;
      t.setTextureMap(shape.textureMap);

      for (Cell (*destinationRow)[3] = t.cells + 4, (*sourceRow)[3] = const_cast<Cell (*)[3]>(this -> cells) + 4; sourceRow != this -> cells; )
      for (Cell *destinationColumn = *--destinationRow + 3, *sourceColumn = *--sourceRow + 3; sourceColumn != *sourceRow; ) {
        *--destinationColumn = *--sourceColumn;
      }

      // ...
      return t;
    }
  };

// ...
template <std::size_t width, std::size_t height, class Shape, std::size_t count>
void render(Shape const (&shapes)[count]) { return render<width, height>(shapes, 4u); }

template <std::size_t width, std::size_t height, class Shape>
void render(Shape const shapes[], std::size_t const count) {
  for (std::size_t boardRow = 0u; boardRow != height; ++boardRow) {
    for (std::size_t boardColumn = 0u; boardColumn != width; ++boardColumn) {
      std::putchar('[');

      for (Shape const *shape = shapes; count != static_cast<std::size_t>(shape - shapes); ++shape) {
        for (std::size_t shapeRow = shape -> height; shapeRow; ) // ->> pointer-casting here is messy
        for (Cell const *shapeColumn = shape -> cells[--shapeRow] + shape -> width; shape -> cells[shapeRow] != shapeColumn; ) {
          if (boardColumn == shape -> column + static_cast<std::size_t>(--shapeColumn - (shape -> cells[shapeRow])) && boardRow == shape -> row + shapeRow) {
            std::putchar(shape -> textureMap[*shapeColumn]);
            goto empty;
          }
        }
      }

      std::putchar(' ');
      empty: std::putchar(']');
    }

    std::puts("\r");
  }
}

// ...
static T SHAPES[4] = {};

/* Main */
int main(int, char*[]) {
  render<6u, 6u>(SHAPES);
}
